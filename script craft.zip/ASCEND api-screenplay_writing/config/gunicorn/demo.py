"""Gunicorn *demo* config file"""

# Django WSGI application path in pattern MODULE_NAME:VARIABLE_NAME
wsgi_app = "scripts.wsgi:application"
# The granularity of Error log outputs
loglevel = "debug"
# The number of worker processes for handling requests
workers = 2
# The socket to bind
bind = "0.0.0.0:8000"
# Restart workers when code changes (development only!)
#reload = True
# Write access and error info to /var/log
accesslog = errorlog = "/var/log/gunicorn/demo.log"
# Redirect stdout/stderr to log file
capture_output = True
# PID file so you can easily fetch process ID
pidfile = "/var/log/gunicorn/demo.pid"
# Daemonize the Gunicorn process (detach & enter background)
daemon = True
#pythonpath = '/opt/gunicorn/scripts'

# preload means master will load model files into RAM, workers will share the same memory, each wont load files separately and cause memory crash.
# preload and reload cannot work together.
preload_app = True

#worker_class = "sync"
worker_class = "gthread"
threads = 6

timeout = 3 * 60  # 3 minutes
keepalive = 24 * 60 * 60  # 1 day

# workers will auto-restart after processing max_request number of requests. zero means no restart. This is a simple method to help limit the damage of memory leaks.
max_request = 100
