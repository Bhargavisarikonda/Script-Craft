from django.urls import path
from . import views
from rest_framework.decorators import permission_classes, authentication_classes
from rest_framework.permissions import AllowAny

# urlpatterns = [
#     path('upload-file', views.AwsUtils.upload_file.as_view() , name='upload-file')
# ]

urlpatterns = []