from django.apps import AppConfig


class AwsutilsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'awsutils'
