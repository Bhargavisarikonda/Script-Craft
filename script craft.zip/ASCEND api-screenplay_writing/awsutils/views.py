import boto3
import os
import logging
from django.conf import settings
from botocore.exceptions import ClientError
import logging

logger = logging.getLogger("scripts_logger")

bucket_name = os.environ.get('S3_BUCKET_NAME')
region_name = os.environ.get('S3_REGION_NAME')

aws_profile = os.environ.get("AWS_PROFILE", "None")

if aws_profile == "None":
    s3_client = boto3.client('s3', 
                    region_name=region_name
                    )
    logger.info("aws profile is None")
else:
    session = boto3.Session(profile_name="default")
    s3_client = session.client('s3', 
                      region_name=region_name
                      )

logger = logging.getLogger("scripts_logger")

#sts = boto3.client('sts',  region_name=region_name)
#caller_identity = sts.get_caller_identity()
#logger.info(f'caller_identity: {caller_identity}')

file_url_prefix = os.environ.get('S3_URL_PREFIX')



class AwsUtils():
    
    def upload_file(self, file, file_path):
        try:
            #print("S3 details ", bucket_name, file_path )
            uploaded_file = s3_client.put_object(Body = file, Bucket = bucket_name, Key = file_path)
        except Exception as e:
            logger.error(f'S3 upload failed for bucket {bucket_name}; S3 url {file_url_prefix}')
            logger.error(f'Error: {e}')
        uploaded_file_url = file_url_prefix + file_path
        return uploaded_file_url


    def create_presigned_url(self, file_path):

        try:
            find_dotcom = file_path.find(".com")
            if find_dotcom < 0:
                logger.error(f"invalid s3 url: {file_path}")
                return None
            key = file_path[find_dotcom+5:]
            #print('key: ', key)
            resp = s3_client.generate_presigned_url(ClientMethod='get_object',
                                                    Params={'Bucket': bucket_name,
                                                            'Key': key},
                                                    ExpiresIn=settings.PRESIGNED_URL_EXP
                                                    )
        except ClientError as e:
            logger.error(f'S3 client error in create presigned url: {e}')
            return None

        return resp

