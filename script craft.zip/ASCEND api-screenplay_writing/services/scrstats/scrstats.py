from unicodedata import name
from unittest import result
from django.db import models
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
import json
from ..src.utils import get_stop_words
from scripts.messages import Messages
from batch.models import Screenplay, Scene, UserList, ClientUser, Client, FeatureMeta,MetricCharacter, ScriptLevel
from batch.Models.MetricEmotion import MetricEmotion
import pandas as pd
import numpy as np

class Scrstats(viewsets.ViewSet):

    @action(detail=True, methods=['GET'])
    def get_screenplay_stats(self, request):
        screenplayuid = self.request.query_params.get("screenplayuid",None)
        
        try:
            scene_qset = Scene.objects.filter(screenplay_uid=screenplayuid)
        except:
            scene_qset = None

        if not scene_qset.exists():
            message, status = Messages.notFound.value
            
            return Response(message, status)

        scene_df = pd.DataFrame.from_records(scene_qset.values())
        
        scene_id_min = np.min(scene_df['scene_uid'])
        scene_id_max = np.max(scene_df['scene_uid'])
        
        scene_df = scene_df[scene_df['scene_uid']!=scene_id_min]
        
        try:
            CharQset = MetricCharacter.objects.filter(scene_uid__gt=scene_id_min,scene_uid__lte=scene_id_max)
        except:
            CharQset = None
        
        try:
            scrQset = Screenplay.objects.filter(screenplay_uid=screenplayuid)
        except:
            scrQset = None
            
        if not scrQset.exists():
            succ_perc = 1
        else:
            #print(scrQset.values()[0])
            succ_perc = scrQset.values()[0]['success_percentage']
            
            
        if not CharQset.exists():
            no_roles = None
        else:
            char_df = pd.DataFrame.from_records(CharQset.values())
            no_roles = self.get_no_roles(char_df)
        
        no_locations = self.get_no_locations(scene_df)
        no_actions = self.get_no_actions(scene_df)
        no_dialogues = self.get_no_dialogues(scene_df)
        no_scenes = self.get_no_scenes(scene_df)
        
        resp = {'success_perc':succ_perc,
                'roles':no_roles,
                'locations':no_locations,
                'actions':no_actions,
                'dialogues':no_dialogues,
                'scene_count':no_scenes,
                'snippets':no_scenes
               }
        
        return Response({"data": resp})
    
    
    def get_no_locations(self, scene_df):
        
        
        return len(scene_df['location'].dropna().unique())
    
    def get_no_dialogues(self, scene_df):
        
        return np.sum(scene_df['count_dialogues'])
    
    def get_no_actions(self, scene_df):
        
        return np.sum(scene_df['count_action'])
    
    def get_no_scenes(self, df):
        
        no_scenes = len(df[df['scenetype_uid']!=3])
        return no_scenes
    
    def get_no_roles(self, char_Df):
        #print(char_Df.columns)
        return len(np.unique(char_Df['person_uid_id']))

   