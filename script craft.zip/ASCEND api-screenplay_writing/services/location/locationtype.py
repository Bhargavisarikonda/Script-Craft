from rest_framework.response import Response
from rest_framework.views import APIView
from batch.models import Scene
from scripts.messages import Messages
from ..src.utils import location_details
from scripts.enums import SceneAttribute
import logging 

logger = logging.getLogger("scripts_logger")

class LocationType(APIView):
    def get(self, request):
        screenplayuid = self.request.query_params.get("screenplayuid",None)

        #print("screenplayuid " , screenplayuid)
        try:
            scene_qset = Scene.objects.filter(screenplay_uid=screenplayuid) #.exclude(scenetype_uid = SceneAttribute.Both.value)
            #print('set ', scene_qset)

            if not scene_qset.exists():
                message, status = Messages.notFound.value
                #print('not found ', message,status)
                return Response(message, status)

            no_scenes, int_scenes, ext_scenes = location_details(scene_qset)

            message, status = Messages.success.value
            rsp_msg = { 'no_scenes':no_scenes, 'int_scenes':int_scenes, 'ext_scenes':ext_scenes }
            #return Response(json.dumps(rsp_msg), status)
            return Response({"data": rsp_msg}, status)
        except Exception as e:
            message, status = Messages.severeError.value
            logger.error('Exception ', e)
            return Response(message, status)
