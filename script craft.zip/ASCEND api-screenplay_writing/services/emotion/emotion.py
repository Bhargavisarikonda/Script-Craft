from json.encoder import INFINITY
from unicodedata import name
# from unittest import resultfrom django.db import models
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from batch.models import Scene
import json
from ..src.utils import get_stop_words
from scripts.messages import Messages
from batch.models import Screenplay, Scene, UserList, ClientUser, Client, FeatureMeta,MetricCharacter, ScriptLevel
from batch.Models.MetricEmotion import MetricEmotion
from itertools import groupby
import math
import pandas as pd
from django.db import connection
import ast


from scripts.enums import SceneType

def get_emotions_aggregate(emotions):
    emotions_agg = {}
    count_emotions = {}
    for i in emotions:
        if i['label'] not in emotions_agg:
            emotions_agg[i['label']] = i['score']
            count_emotions[i['label']] = 1
        else:
            emotions_agg[i['label']] = (emotions_agg[i['label']] * count_emotions[i['label']]) + i['score']
            count_emotions[i['label']] += 1
        emotions_agg[i['label']] = (emotions_agg[i['label']]) / count_emotions[i['label']]
    return emotions_agg
class Emotion(viewsets.ViewSet):

    @action(detail=True, methods=['GET'])
    def get_emotion_graph(self, request):
        screenplayuid = self.request.query_params.get("screenplayuid",None)
        
        query = f"""select me.emotions, se.scene_number from scene se join metric_emotion 
        me on me.scene_uid = se.scene_uid where se.scenetype_uid <> '3' and 
        se.screenplay_uid={screenplayuid} order by se.scene_number asc
        """
        scene_numbers = Scene.objects.filter(screenplay_uid=screenplayuid).exclude(scenetype_uid=SceneType.Preface.value).values_list("scene_number", flat=True)
        scene_numbers = sorted(scene_numbers)
        with connection.cursor() as cursor:
            cursor.execute(query)
            x = cursor.fetchall()
        
        if len(x) == 0:
            message, status = Messages.emotionsNotFound.value
            return Response(message, status)
        else:
            message,status = Messages.success.value
        df = pd.DataFrame(x, columns=['emotions', 'scene_number'])
        df['emotions'] = df['emotions'].apply(lambda x: json.loads(x))
        e = df.groupby('scene_number').agg({'emotions': 'sum'})
        e['agg'] = e['emotions'].apply(lambda x: get_emotions_aggregate(x))
        m = pd.concat([e.drop(['agg', 'emotions'], axis=1), e['agg'].apply(pd.Series)], axis=1)
        emotion_names = m.columns
        columns = m.columns
        emotions_agg = []
        idx = 1
        for i in sorted(columns):
            emotion = {"emotionName": i,
                        "emotionY":"Factor",
                        "id": idx
                        }
            coordinates = []
            for j in scene_numbers:
                try:
                    coordinates.append({
                        'scene': j,
                        'val': m.loc[j][i] * 100
                    })
                except Exception as e:
                    coordinates.append({
                        'scene': j,
                        'val': 0
                    })
                    pass
            emotion['coordinates'] = coordinates
            emotions_agg.append(emotion)
            idx += 1

        return Response({"data": emotions_agg, 'status': message}, status)
        
    @action(detail=True, methods=['GET'])
    def get_emotion_analytics(self, request):
        screenplayuid = self.request.query_params.get("screenplayuid",None)
        
        emotions_array = self.get_screenplay_emotions(screenplayuid, False)
        if len(emotions_array) == 0:
            message, status = Messages.emotionsNotFound.value
            return Response(message, status)
        else:
            message,status = Messages.success.value
        return Response({"data": emotions_array, 'status': message}, status)
    
    def get_screenplay_emotions(self, screenplayuid, return_all_emotions):
        if return_all_emotions:
            scene_uids = Scene.objects.filter(screenplay_uid=screenplayuid).exclude(scenetype_uid=SceneType.Preface).values_list("scene_uid", flat=True)
            emotions = MetricEmotion.objects.filter(scene_uid__in=scene_uids).all().values()
            emotion_scene_uids = [x['scene_uid'] for x in emotions]
            return emotions, set(scene_uids), set(emotion_scene_uids)
        scene_uids = Scene.objects.filter(screenplay_uid=screenplayuid).values_list("scene_uid", flat=True)
        emotion_qs = MetricEmotion.objects.filter(scene_uid__in=scene_uids).values_list("emotions", flat=True)
        aggregate_result_list = []

        for emotion_obj in emotion_qs:
            for emotion_dict in emotion_obj:
                if not emotion_dict["label"] in aggregate_result_list:
                    aggregate_result_list.append(emotion_dict["label"])

        aggregate_result= {agg:0 for agg in aggregate_result_list}

        for emotion_item in emotion_qs:
            scores_dict = [{ k["label"]: k["score"]} for k in emotion_item]
            scores = [k["score"] for k in emotion_item]
            for s in scores_dict:
                for key, value in s.items():
                    normalized_score = (value - min(scores)) / (max(scores) - min(scores))
                    aggregate_result[key] += normalized_score
        
        result = []
        score_sum = sum(aggregate_result.values())
        for key in aggregate_result:
            if score_sum != 0:
                pv  = float(aggregate_result[key])/score_sum * 100
                emotion_resut_dict = {
                    'name': key,
                    'pv': pv
                }
                result.append(emotion_resut_dict)
        return result
        