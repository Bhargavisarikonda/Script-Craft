from django.db import models

# Create your models here.
# class scene (models.Model):
#     count_words_action = models.CharField(max_length=500)
#     count_words_dialogues = models.CharField(max_length=500)
#     count_dialogues = models.CharField(max_length=500)
#     count_action = models.CharField(max_length=500)

# Create your models here.
class Author(models.Model):
    #author_id = models.BigIntegerField(primary_key=True, auto_created=True )
    author_id = models.AutoField(primary_key=True, auto_created=True)
    name = models.CharField(max_length=20)

    class Meta:
        managed = False
        db_table = "author2"
