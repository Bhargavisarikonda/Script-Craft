from json.encoder import INFINITY
from unicodedata import name
from unittest import result
from django.db import models
from rest_framework import viewsets
from rest_framework import status
from rest_framework.decorators import action
from rest_framework.response import Response
from batch.models import Scene
import json
from ..src.utils import get_stop_words
from scripts.messages import Messages
from batch.models import Screenplay, Scene, UserList, ClientUser, Client, FeatureMeta,MetricCharacter, ScriptLevel
from batch.Models.MetricGenre import MetricGenre
from itertools import groupby
import math
import logging

logger = logging.getLogger("scripts_logger")

class Genre(viewsets.ViewSet):

    @action(detail=True, methods=['GET'])
    def get_emotion_graph(self, request):
        screenplayuid = self.request.query_params.get("screenplayuid",None)
        
        genre_array = self.get_screenplay_genre(screenplayuid, True)

        key_func = lambda x: x["scene_uid"]
        
        genre_array = sorted(genre_array, key=key_func)
        grouped_emotions = {}
        # group emotions based on scene_uid
        min_scene_uid = math.inf
        for key, value in groupby(genre_array, key_func):
            grouped_emotions[str(key)] = list(value)
            if key < min_scene_uid:
                min_scene_uid = key
        emotions_coordinates = {
            'surprise': [],
            'anger': [],
            'sadness': [],
            'happy': [],
            'love': [],
            'fear': [],
            'joy': []
        }
        for key_value in grouped_emotions:
            grouped_emotion = grouped_emotions[key_value]
            aggregate_result = {
                'surprise': 0,
                'anger': 0,
                'sadness': 0,
                'happy': 0,
                'love': 0,
                'fear': 0,
                'joy': 0
            }
            for each_scene in grouped_emotion:
                emotion = each_scene['emotions'][0]
                for e in emotion:
                    aggregate_result[e['label']] += e['score']
            result = []
            scores = [aggregate_result[k] for k in aggregate_result]
            score_sum = sum(scores)
            for key in aggregate_result:
                pv = 0
                if score_sum != 0:
                    pv  = float(aggregate_result[key])/score_sum * 100
                emotion_obj = {
                    'scene': int(key_value) - min_scene_uid + 1,
                    'val': pv
                }
                emotions_coordinates[key].append(emotion_obj)
        emotions_response = [
            {
                "id": 1,
                "emotionName": "joy",
                "emotionY": "Factor",
                "emotionX": "Scenes",
                "coordinates": emotions_coordinates['joy']
            },
            {
                "id": 2,
                "emotionName": "surprise",
                "emotionY": "Factor",
                "emotionX": "Scenes",
                "coordinates": emotions_coordinates['surprise']
            },
            {
                "id": 3,
                "emotionName": "anger",
                "emotionY": "Factor",
                "emotionX": "Scenes",
                "coordinates": emotions_coordinates['anger']
            },
            {
                "id": 4,
                "emotionName": "sadness",
                "emotionY": "Factor",
                "emotionX": "Scenes",
                "coordinates": emotions_coordinates['sadness']
            },
            {
                "id": 5,
                "emotionName": "happy",
                "emotionY": "Factor",
                "emotionX": "Scenes",
                "coordinates": emotions_coordinates['happy']
            },
            {
                "id": 6,
                "emotionName": "love",
                "emotionY": "Factor",
                "emotionX": "Scenes",
                "coordinates": emotions_coordinates['love']
            },
            {
                "id": 7,
                "emotionName": "fear",
                "emotionY": "Factor",
                "emotionX": "Scenes",
                "coordinates": emotions_coordinates['fear']
            }
        ]
        message, status = Messages.success.value
        return Response({"data": emotions_response}, status)
    
    @action(detail=True, methods=['GET'])
    def get_genre_analytics(self, request):
        screenplayuid = self.request.query_params.get("screenplayuid",None)
        logger.info(f"screenplay uid: {screenplayuid}")
        genre_array = self.get_screenplay_genre(screenplayuid, False)
        logger.debug(f"genre_array: {genre_array} for screenplay uid: {screenplayuid}")
        if not genre_array:
            message, status = Messages.genreNotFound.value
            return Response(message, status)
            #return Response({"data": "no data found"}, status=status.HTTP_404_NOT_FOUND)    
        message, status = Messages.success.value
        return Response({"data": genre_array}, status)

    
    def get_screenplay_genre(self, screenplayuid, return_all_genre):
        scene_uids = Scene.objects.filter(screenplay_uid=screenplayuid).values_list("scene_uid", flat=True)
        genre_qs = MetricGenre.objects.filter(scene_uid__in=scene_uids).values_list("genres", flat=True)
        if return_all_genre:
            return list(genre_qs)

        aggregate_result_list = []

        for genre_obj in genre_qs:
            for genre_dict in genre_obj:
                if not genre_dict["label"] in aggregate_result_list:
                    aggregate_result_list.append(genre_dict["label"])

        aggregate_result= {agg:0 for agg in aggregate_result_list}

        for genre_item in genre_qs:
            for genre_dict in genre_item:
                if genre_dict["score"] >= 0.01:
                    aggregate_result[genre_dict["label"]] += genre_dict["score"]
        
        result = []
        score_sum = sum(aggregate_result.values())
        for key in aggregate_result:
            if score_sum != 0:
                pv  = float(aggregate_result[key])/score_sum * 100
                genre_resut_dict = {
                    'name': key,
                    'pv': pv
                }
                result.append(genre_resut_dict)
        return result


