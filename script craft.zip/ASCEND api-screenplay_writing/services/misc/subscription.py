from rest_framework import viewsets, status, generics
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from batch.models import Subscription
from ..serializers import AuthorSerializer2
from django.db.models import Avg, Count, Min, Sum, Max
from rest_framework.decorators import action
from scripts.messages import Messages
from scripts.enums import SceneAttribute

class SubscriptionList(viewsets.ViewSet):
    #permission_classes = [AllowAny]

    @action(detail=True, methods=['GET'])
    def get_subscriptions(self, request):

        subscriptions = Subscription.objects.all().order_by('subscription_uid').values()

        if not subscriptions.exists():
            message, status = Messages.notFound.value
            return Response(message, status)

        message, status = Messages.success.value

        #print('subscr ', subscriptions)

        return Response({"data": subscriptions}, status)
