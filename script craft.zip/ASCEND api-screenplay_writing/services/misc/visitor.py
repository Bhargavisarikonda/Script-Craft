from rest_framework import viewsets, status, generics
from rest_framework.response import Response
from batch.Models.Misc import Visitor
from ..serializers import AuthorSerializer2
from django.db.models import Avg, Count, Min, Sum, Max
from rest_framework.decorators import action
from scripts.messages import Messages
from scripts.enums import SceneAttribute
import json
import logging

logger = logging.getLogger("scripts_logger")

class VisitorClass(viewsets.ViewSet):

    @action(detail=True, methods=['POST'])
    def add_visitor(self, request):
        req = json.loads(request.body)
        screen = req.get("screen", None)
        action = req.get("action", None)
        geo_details = req.get("geoDetails",None)

        visitor = Visitor(
                screen = screen,
                action = action,
                geo_details = geo_details
        )
        try:
            visitor.save()
        except Exception as e:
            logger.error(f"Error in inserting into Visitor: ", e)
            message, status = Messages.visitorAddFailed.value
            return Response({"error": message}, status)

        message, status = Messages.success.value
        return Response({"data": message}, status)
