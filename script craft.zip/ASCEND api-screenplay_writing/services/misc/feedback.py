from django.db import models
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from batch.Models.Misc import Feedback
from wordcloud import WordCloud, STOPWORDS
import json
import logging
from services.src.utils import get_stop_words
from scripts.messages import Messages

logger = logging.getLogger("scripts_logger")


class PostFeedback(viewsets.ViewSet):

    @action(detail=True, methods=['POST'])
    def send_feedback(self, request):
        req = json.loads(request.body)
        #print('self.request ', req)
        fullname = req.get("fullname", None)
        email = req.get("email", None)
        selectedTopicItem = req.get("selectedTopicItem",None)
        comments = req.get("message",None)
        ip = req.get("ip", '0.0.0.0')

        feedback = Feedback(
                        fullname = fullname,
                        email = email,
                        topic = selectedTopicItem,
                        comments = comments,
                        ip = ip
        )

        try:
            feedback.save()
        except Exception as e:
            logger.error(F'SQL error: {e}')
            message, status = Messages.sqlerror.value
            return Response(message, status)

        logger.info(f'SQL status code is {feedback}')

        message, status = Messages.success.value
        return Response({"data":message }, status)
