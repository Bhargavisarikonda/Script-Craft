from rest_framework import viewsets, status, generics
from rest_framework.response import Response
from django.db.models import F
from batch.models import Profile
from ..serializers import AuthorSerializer2
from django.db.models import Avg, Count, Min, Sum, Max
from rest_framework.decorators import action
from scripts.messages import Messages
from scripts.constants import Constants  
from django.contrib.auth.models import User
import json
from abc import ABC, abstractmethod
import re
import logging

logger = logging.getLogger("scripts_logger")

# Strategy design pattern

class ValidationStrategy(ABC):
    @abstractmethod
    def validate(self, type):
        pass

    def response(self):
        return self.message, self.status

class ValidationContext:
    def __init__(self, validation_strategy: ValidationStrategy):
        self.validation_strategy = validation_strategy

    def validate(self, value):
        self.validation_strategy.validate(value)

    def response(self):
        return self.validation_strategy.response()


class validateUsername(ValidationStrategy):
    def validate(self, value):
        try:
            # iexact means case insensitive compare
            _ = User.objects.get(username__iexact = value )
            self.message, self.status = Messages.usernameFail.value
        except User.DoesNotExist:
            self.message, self.status = Messages.success.value

    def response(self):
        return super().response()

class validateEmail(ValidationStrategy):
    
    def validate(self, value):
        if re.fullmatch(Constants.EMAIL_PATTERN, value):
            try:
                # iexact means case insensitive compare
                resp = User.objects.get(email__iexact = value)
                oauth = Profile.objects.get(user__id=resp.id).oauth
                # If oauth true, then allow the user to register. This means user signed in with gmail id via oauth earlier, and now
                #  wants to register with the same gmail id. Allow this.
                if oauth:
                    self.message, self.status = Messages.success.value
                else:    
                    self.message, self.status = Messages.emailFail.value
            except User.DoesNotExist:
                self.message, self.status = Messages.success.value
        else:
            self.message, self.status = Messages.emailFail.value


    def response(self):
        return super().response()



class Validation(viewsets.ViewSet):

    @action(detail=True, methods=['POST'])
    def validate_field(self, request):
        req = json.loads(request.body)['payload']
        #print('self.request ', req)
        value = req.get("text", None)
        type = req.get("type", None)

        if type == "email":
            validation_context = ValidationContext(validateEmail())
            validation_context.validate(value)

        if type == "username":
            validation_context = ValidationContext(validateUsername())
            validation_context.validate(value)
        
        message, status = validation_context.response()

        #print('response  ', message, status)

        return Response(message, status)

