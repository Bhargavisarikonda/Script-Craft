from django.db import models
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from batch.models import Scene
from wordcloud import WordCloud, STOPWORDS
import json
from services.src.utils import get_stop_words
from scripts.messages import Messages

NORMALIZATION_CONSTANT = 5000

class Wordcloud(viewsets.ViewSet):

    @action(detail=True, methods=['GET'])
    def get_wordcloud(self, request):
        screenplayuid = self.request.query_params.get("screenplayuid",None)
        try:
            scenes = Scene.objects.filter(screenplay_uid=screenplayuid).all().values()
        except:
            scenes = None

        if not scenes or not scenes.exists():
            message, status = Messages.notFound.value
            return Response(message, status)

        total_scenes_text = ''
        #print(scenes)
        for scene in scenes:
            scene_text = scene['scene_text']
            #print(scene_text)
            scene_text = json.loads(scene_text)
            for each_text in scene_text:
                total_scenes_text += each_text['Text']
        stopwords = get_stop_words()
        res = WordCloud(stopwords = stopwords).process_text(total_scenes_text)
        maximum = max(v for k, v in res.items())
        res = {k.lower(): round(v / (maximum / NORMALIZATION_CONSTANT), 2) for k, v in res.items()}
        message, status = Messages.success.value
        return Response({"data":res }, status)
