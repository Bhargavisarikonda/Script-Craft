from django.test import TestCase
from batch.models import Address
import os

# Create your tests here.
import base64
import requests
import json

class GetDemoScene(TestCase):
    @classmethod
    def setUpTestData(cls):
        #print("setUpTestData: Run once to set up non-modified data for all class methods.")
        pass

    def setUp(self):
        #print("setUp: Run once for every test method to setup clean data.")
        self.url = "http://127.0.0.1:8000/api/v1/demo/scene?screenplayuid="

    def getWoPerc(self):
        spuid = 5
        output = '{"no_scenes": 219, "int_scenes": 173, "ext_scenes": 46, "perc_day": NaN, "perc_night": NaN}'
        url = f'{self.url}{spuid}'
        #print("%s, %s" %('url ', url))
        r = requests.get(url)
        #print("%s %s " %('response ', r.json()))
        self.assertEqual(r.json(), output)

    def test_trial(self):
        val = False
        self.assertFalse(val)
