from rest_framework import viewsets, status, generics
from rest_framework.response import Response
from ..models import Author
from ..serializers import AuthorSerializer2


# Create your models here.
class DummyAuthor(viewsets.ModelViewSet):
    queryset = Author.objects.all()
    serializer_class = AuthorSerializer2
