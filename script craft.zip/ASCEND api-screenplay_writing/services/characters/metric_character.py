from rest_framework.viewsets import ModelViewSet, ViewSet
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework import status
from django.db.models import Max,Min,Count, Sum
from yaml import serialize
from scripts.enums import SceneAttribute

from services.serializers import EntryExit,CharacterContribution, ListCharacters
from django.db.models import F, Q
import json
from batch.models import MetricCharacter,Screenplay, Scene
from scripts.messages import Messages
from typing import OrderedDict
import pandas as pd

from services.src.utils import get_global_sentiments

class CharacterAnalysis(ModelViewSet):
    @action(detail=False, methods=['GET'])
    def entryexit(self, request):
        screenplayuid = request.query_params.get("screenplayuid",None)
        screenplay_data=Screenplay.objects.filter(screenplay_uid=screenplayuid).count()
        #print("screenplay_data ", screenplay_data)
        if screenplay_data == 0:
            message, status = Messages.screenplayNotFound.value
            return Response(message, status)

        data=MetricCharacter.objects.filter(scene_uid__screenplay_uid=screenplayuid
                                           ).values(character_name=F('person_uid__name'),screenplay_id=F('scene_uid__screenplay_uid')
                                                  ).annotate( entry_scene_no=Min('scene_uid__scene_number')
                                                             , exit_scene_no=Max('scene_uid__scene_number')
                                                            )

        datalist=[i for i in data]
        # empty list
        if not datalist:
            message, status = Messages.charactersNotFound.value
            return Response(message, status)

        serialize=EntryExit(data=datalist,many=True)
        if serialize.is_valid():
            message, status = Messages.success.value
            return Response({'data': serialize.data},
                        status
                      )
        else:
            message, status = Messages.serialize_err.value
            return Response(message, status)


    @action(detail=False, methods=['GET'])
    def character_contribution(self, request):
        screenplayuid = request.query_params.get("screenplayuid",None)
        screenplay_data=Screenplay.objects.filter(screenplay_uid=screenplayuid).count()
        if screenplay_data == 0:
            message, status = Messages.screenplayNotFound.value
            return Response(message, status)

        data=MetricCharacter.objects.filter(scene_uid__screenplay_uid=screenplayuid
                                           ).values(character_name=F('person_uid__name'),screenplay_id=F('scene_uid__screenplay_uid')
                                                  ).annotate( scene_cnt=Count('scene_uid')
                                                            )

        datalist=[i for i in data]
        # empty list
        if not datalist:
            message, status = Messages.charactersNotFound.value
            return Response(message, status)

        #print('datalist ', datalist)
        serialize=CharacterContribution(data=datalist,many=True)
        if serialize.is_valid():
            message, status = Messages.success.value
            return Response({'data': serialize.data},
                        status
                      )
        else:
            #print('error ', serialize.errors)
            message, status = Messages.serialize_err.value
            return Response(message, status)


    @action(detail=False, methods=['GET'])
    def socialrelations(self, request):
        screenplayuid = request.query_params.get("screenplayuid",None)
  
        # SQL group by names and scene id
        queryset = MetricCharacter.objects.raw("select mc.scene_uid, c.name , -1 as character_uid from metric_character mc inner join \
                            scene s on mc.scene_uid = s.scene_uid \
                                inner join characters c on c.person_uid = mc.person_uid \
                                where s.screenplay_uid = %s group by 1, 2, 3", [screenplayuid])
        group_chars  = [(character.scene_uid.scene_uid, character.name) for character in queryset]
        #print("group chars ", group_chars)

        # Transfor queryset to pandas
        q_to_pd = pd.DataFrame(group_chars, columns=['id', 'name'], index=None)

        # Self join
        self_join = pd.merge(q_to_pd, q_to_pd, on="id", how="inner")

        # Remove rows where both names are same
        unique_names = self_join.query("name_x != name_y")

        # Pandas group by on name1, name2 and count
        series_names = unique_names.groupby(['name_x', 'name_y'])['id'].count()

        # PD series to dict
        dict_names = series_names.to_dict(OrderedDict())

        # Logic to generate response
        result = OrderedDict()
        prev_k = None
        for (k1, k2), val in dict_names.items():
            d2 = {k2:val}    
            if prev_k == None:
                result[k1] = d2
                prev_k = k1
                continue
            
            if k1 != prev_k:
                result[k1] = d2    
            else:
                result[k1].update(d2)
            prev_k = k1
            
        #print('Result ', result)
        message, status = Messages.success.value

        if not result:
            message, status = Messages.charactersNotFound.value
            return Response(message, status)
            
        return Response({'data':result}, status)


    @action(detail=False, methods=['GET'])
    def overview(self, request):
        screenplayuid = request.query_params.get("screenplayuid",None)

        # Get characters by scene count
        # Combination of values and annotate has the effect of Group by
        queryset = MetricCharacter.objects.filter(scene_uid__screenplay_uid = screenplayuid).\
                values(character_name=F('person_uid__name'), scene_id=F('scene_uid')).annotate(sum_dialogues=Sum('count_dialogues'))
        #print('explore ', queryset)

        if not queryset:
            message, status = Messages.charactersNotFound.value
            return Response(message, status)

        characters_by_scene = queryset.values('character_name').annotate(count_scenes=Count('scene_id')).order_by('-count_scenes')
        #print('characters_by_scene ', characters_by_scene)

        characters_by_dialogs = MetricCharacter.objects.filter(scene_uid__screenplay_uid = screenplayuid, sceneattribute_uid = SceneAttribute.Dialogue.value).\
                values(character_name=F('person_uid__name')).annotate(count_dialogues=Sum('count_dialogues')).order_by('-count_dialogues')
        #print('characters_by_dialogs ', characters_by_dialogs)

        total_dialogs = characters_by_dialogs.values('count_dialogues').aggregate(sum_dialogs=Sum('count_dialogues'))
        #print('total_dialogs ', total_dialogs)

        total_scenes = Scene.objects.filter(screenplay_uid=screenplayuid).count()
        #print('total_scenes ', total_scenes)

        sentiments = get_global_sentiments()

        queryset = MetricCharacter.objects.filter(scene_uid__screenplay_uid = screenplayuid).\
                values(character_name=F('person_uid__name'), character_gender=F('person_uid__gender'), character_type=F('person_uid__type'), \
                            character_logline=F('person_uid__logline')).annotate(scene_count=Count('scene_uid')).order_by('-scene_count')

        list_of_characters = queryset.values('character_name', 'character_gender', 'character_type', 'character_logline')

        message, status = Messages.success.value
        result =    {'total_scenes': total_scenes,
                    'top_10_by_scene': characters_by_scene[:10],
                    'top_10_by_dialog': characters_by_dialogs[:10],
                    'total_dialogs': total_dialogs['sum_dialogs'],
                    "sentiment": sentiments,
                    'list_of_characters': list_of_characters
                    }
        return Response({'data':result}, status)


        # message, status = Messages.success.value
        # result = { 
        #     "total_scenes": 50,
        #     "top_10_by_scene": [{'Tom': 30}, {'Amit': 22}, {'Rani': 17}, {'Amir': 15}, {'Salman': 10}, {'Sid': 9}, \
        #         {'Kareena': 7}, {'Saif': 6}, {'Tina':4}, {'Akshay': 2} ],
        #     "total_dialogs": 900,        
        #     "top_10_by_dialog": [{'Tom': 300}, {'Amit': 220}, {'Rani': 170}, {'Amir': 150}, {'Salman': 100}, \
        #                         {'Sid': 90}, {'Kareena': 70}, {'Saif': 60}, {'Tina':40}, {'Akshay': 20}],                             
        #     "sentiment": {'positive': 12.6, 'neutral': 26.9, 'negative':'10.5'}
        # }
    # @action(detail=False, methods=['GET'])
    # def socialrelations(self, request):
    #     screenplayuid = request.query_params.get("screenplayuid",None)
    #     scene_count = Scene.objects.raw('select -1 as scene_uid, count(*) as count from scene where screenplay_uid = %s ', [screenplayuid] )
    #     print("scene count ", scene_count[0].count)

    #     queryset = MetricCharacter.objects.raw("select distinct name as name , -1 as character_uid  from metric_character where scene_uid in \
    #                                     (select scene_uid from scene where screenplay_uid = %s)", [screenplayuid])        
    #     unique_characters  = [character.name for character in queryset]
    #     print("unique characters ", unique_characters)
    #     #serializer_class = UniqueCharacters(data=unique_characters, many=True)
    #     #if serializer_class.is_valid():
    #     #    message, status = Messages.success.value
    #         #return Response({'data': serializer_class.data}, status   )
    #     #else:
    #         #print('error')
    #     #    message, status = Messages.serialize_err.value
    #         #return Response(serializer_class.errors, status)

    #     queryset = MetricCharacter.objects.raw("select -1 as character_uid, name, mc.scene_uid from metric_character mc \
    #                             inner join scene s on  mc.scene_uid = s.scene_uid where s.screenplay_uid = %s ", [screenplayuid])
    #     scene_characters = [(character.scene_uid.scene_uid , character.name)  for character in queryset ]
    #     print('scene characters ', scene_characters)

    #     character_dict = OrderedDict()
    #     for character in unique_characters:
    #         character_dict[character] = OrderedDict()

    #     for scene_id, name in scene_characters:
    #         for character in unique_characters:
    #             print(scene_id, name, character, character_dict[character])
    #             if name == character:
    #                 continue
    #             if name in character_dict[character]:
    #                 character_dict[character][name] += 1
    #             else:
    #                 character_dict[character][name] = 1


    #     print('character_dict' , character_dict)
    #     message, status = Messages.success.value

    #     if not character_dict:
    #         message, status = Messages.charactersNotFound.value
    #         return Response(message, status)
            
    #     return Response({'data':character_dict}, status)


class GenderAnalysis(ModelViewSet):
    @action(detail=False, methods=['GET'])
    def genderRatio(self, request):
        screenplayuid = request.query_params.get("screenplayuid", None)
        if Screenplay.objects.filter(screenplay_uid=screenplayuid).exists():
            #print(Screenplay.objects.filter(screenplay_uid=screenplayuid))
            # screenplay_obj = Screenplay.objects.get(screenplay_uid=screenplayuid)
            data = MetricCharacter.objects.filter(scene_uid__screenplay_uid=screenplayuid)

            if not data:
                message, status = Messages.genderNotFound.value
                return Response(message, status)

            # If data found
            male_count = data.filter(person_uid__gender = "Male").distinct('person_uid').count()
            female_count = data.filter(person_uid__gender = "Female").distinct('person_uid').count()

            male_dialogues = data.filter(Q(person_uid__gender = "Male") & ~Q(count_dialogues = -1)).aggregate(sum=Sum('count_dialogues'))['sum']
            if male_dialogues is None:
                male_dialogues = 0
            female_dialogues = data.filter(Q(person_uid__gender = "Female") & ~Q(count_dialogues = -1)).aggregate(sum=Sum('count_dialogues'))['sum']
            if female_dialogues is None:
                female_dialogues = 0
                
            count_males_all_scenes = data.filter(person_uid__gender = "Male").count()
            count_females_all_scenes = data.filter(person_uid__gender = "Female").count()
            
            gender_data = data.filter().values(scene_id=F('scene_uid'), gender=F('person_uid__gender')).annotate(total=Count('gender'))

            male_male, male_female, female_female = 0, 0, 0
            prev_scene = -1
            for each_scene in gender_data:
                curr_scene = each_scene['scene_id']
                if curr_scene != prev_scene:
                    female_is_present = False
                    male_is_present = False
                if each_scene['gender'] == 'Male':
                    male_is_present = True
                    if each_scene['total'] > 1:
                        male_male += 1

                if each_scene['gender'] == 'Female':
                    female_is_present = True
                    if each_scene['total'] > 1:
                        female_female += 1

                if male_is_present and female_is_present:
                    male_female += 1

                prev_scene = curr_scene

            #print(f'scenes  {male_dialogues}, {count_males_all_scenes}, {female_female}')

            result = {"charts": [{"male": round(male_count*100/(male_count + female_count),2),
                    "female": round(female_count*100/(male_count + female_count),2),
                    "description": "Percentage of Characters"},
                    {"male": round(male_dialogues*100/(male_dialogues + female_dialogues),2),
                    "female": round(female_dialogues*100/(male_dialogues + female_dialogues),2),
                    "description": "Percentage of Speaking Lines"},
                    {"male": round(count_males_all_scenes*100/(count_males_all_scenes + count_females_all_scenes),2),
                    "female": round(count_females_all_scenes*100/(count_males_all_scenes + count_females_all_scenes),2),
                    "description": "Percentage of Presence"}
                    ],
                    "interactions": {
                        "maleToMale": round(male_male*100/(male_male + male_female + female_female),2),
                        "maleToFemale": round(male_female*100/(male_male + male_female + female_female),2),
                        "femaleToFemale": round(female_female*100/(male_male + male_female + female_female),2),

                    }}

            message, status = Messages.success.value
            return Response({'data': result}, status)
        else:
            message, status = Messages.screenplayNotFound.value
            return Response(message, status)