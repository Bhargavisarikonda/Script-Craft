from django.db import models
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from batch.models import Scene,MetricCharacter
# from batch.Models.MetricCharacter import
from wordcloud import WordCloud, STOPWORDS
import json
from ..src.utils import get_stop_words
from django.db.models import Sum
from scripts.messages import Messages
from scripts.enums import SceneAttribute

class Characters(viewsets.ViewSet):

    @action(detail=True, methods=['GET'])
    def get_characters_analysis(self, request):
        screenplayuid = self.request.query_params.get("screenplayuid",None)
        try:
            scenes = Scene.objects.filter(screenplay_uid=screenplayuid)
        except:
            scenes = None
        if not scenes or not scenes.exists():
            message, status = Messages.notFound.value
            return Response(message, status)
        scene_uids= []
        for scene in scenes:
            scene_uids.append(scene.scene_uid)
        # initialize a queryset
        characterqueryset = MetricCharacter.objects.filter(scene_uid__in=scene_uids, sceneattribute_uid=SceneAttribute.Dialogue.value)
        # get total characters
        total_characters = characterqueryset.values('character_uid').distinct().count()
        # get male characters count
        male_characters = characterqueryset.filter(gender='M').count()
        # get female characters count
        female_characters = characterqueryset.filter(gender='F').count()
        # get count of each character dialgoues mapping. sort by count in descending order
        characters_dialogues = characterqueryset.values('name').annotate(count=Sum('count_dialogues')).order_by('-count')
        # get the dominant character
        if len(characters_dialogues) > 0:
            dominant_character = characters_dialogues[0]
            total_dialogue_count = 0
            for character in characters_dialogues:
                total_dialogue_count += character['count']
            dominant_percentage = 100 * float(dominant_character['count'])/float(total_dialogue_count)
            message, status = Messages.success.value
            return Response({"data":{"total_characters": total_characters, "male_characters": male_characters, "female_characters": female_characters, "dominant_character": {"name": dominant_character['name'], "perc": round(dominant_percentage, 2)}} }, status)
        else:
            message, status = Messages.notFound.value
            return Response(message, status)
