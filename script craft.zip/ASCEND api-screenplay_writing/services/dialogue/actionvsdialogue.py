from rest_framework.response import Response
from rest_framework.views import APIView
from batch.models import Scene
from scripts.messages import Messages
from scripts.enums import SceneAttribute
import logging

logger = logging.getLogger("scripts_logger")

class ActionvsDialogue(APIView):
    def get(self, request):
        records = []

        screenplayuid = self.request.query_params.get("screenplayuid",None)

        #print("screenplayuid " , screenplayuid)
        try:
            scene_qset = Scene.objects.filter(screenplay_uid=screenplayuid).exclude(scenetype_uid = SceneAttribute.Both.value)
            #print('set ', scene_qset)

            if not scene_qset.exists():
                message, status = Messages.notFound.value
                #print('not found ', message,status)
                return Response(message, status)

            for index in range(len(scene_qset)):
                records.append({'count_action': scene_qset[index].count_action,
                        'count_dialogues': scene_qset[index].count_dialogues,
                        'count_words_action': scene_qset[index].count_words_action,
                        'count_words_dialogues': scene_qset[index].count_words_dialogues,
                        })
            message, status = Messages.success.value
            return Response({"data": records}, status)

        except Exception as e:
            message, status = Messages.severeError.value
            logger.error('exception ', e)
            return Response(message, status)

    #
    # def post(self,request):
    #
    #     try :
    #          new_data = request.data
    #          new_scene = Scene.objects.create(scene_uid = new_data["scene_uid"],
    #          scenetype_uid = new_data["scenetype_uid"],
    #          screenplay_uid = new_data["screenplay_uid"],
    #          count_action = new_data["count_action"],
    #          count_dialogues = new_data["count_dialogues"],
    #          scene_text = new_data["scene_text"],
    #          scene_number = new_data["scene_number"],
    #          count_words_action = new_data["count_words_action"],
    #          count_words_dialogues = new_data["count_words_dialogues"],
    #          time_of_day = new_data["time_of_day"],
    #          location = new_data["location"])
    #
    #          new_scene.save();
    #
    #          return Response(new_scene)
    #
    #     except Exception as e:
    #             return Response({"error":str(e)})
