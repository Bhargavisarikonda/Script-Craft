from rest_framework import viewsets, status, generics
from rest_framework.response import Response
from batch.models import Scene
from ..serializers import AuthorSerializer2
from django.db.models import Avg, Count, Min, Sum, Max
from rest_framework.decorators import action
from scripts.messages import Messages
from scripts.enums import SceneAttribute
import logging

logger = logging.getLogger("scripts_logger")


class DialogueDemo(viewsets.ViewSet):

    @action(detail=True, methods=['GET'])
    def get_dialogue_stats(self, request):
        screenplayuid = self.request.query_params.get("screenplayuid", None)
        #print('screenplayuid ', screenplayuid)
        try:
            scenes = Scene.objects.filter(screenplay_uid=screenplayuid).exclude(scenetype_uid = SceneAttribute.Both.value)
        except Exception as e:
            scenes = None
            logging.error(f'exception: {e} ')

        if not scenes.exists():
            message, status = Messages.notFound.value
            return Response(message, status)

        #print('Scene count  ',  scene)
        action_qset = scenes.aggregate(action_count=Sum('count_action'))
        action = action_qset['action_count']
        #print('Action count  ',  action)
        dialogues_qset = scenes.aggregate(dialogues_count=Sum('count_dialogues'))
        dialogues = dialogues_qset['dialogues_count']

        action_dialogues_count = action + dialogues
        #print('Dialogues count  ',  dialogues)
        maximum_dialogues_qset = scenes.aggregate(max_dialogues=Max('count_dialogues'))
        maximum_dialogues = maximum_dialogues_qset['max_dialogues']
        average_dialogues_qset = scenes.raw(
        #print(' maximum_dialogues count ', maximum_dialogues)
            'select 100 as scene_uid, avg(count_dialogues) as average_dialogues from scene where screenplay_uid = %s \
                and scenetype_uid <> %s', [screenplayuid, SceneAttribute.Both.value]
            )
        average_dialogues = round(average_dialogues_qset[0].average_dialogues, 2)
        #print('average_dialogues count ', average_dialogues)

        message, status = Messages.success.value
        rsp_msg = { 'action_dialogues_count':action_dialogues_count, 'action':action,
            'dialogues':dialogues, 'maximum_dialogues':maximum_dialogues, 'average_dialogues':average_dialogues }
        #return Response(json.dumps(rsp_msg), status)
        return Response({"data": rsp_msg}, status)
