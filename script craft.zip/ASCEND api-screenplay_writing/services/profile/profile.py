from rest_framework import viewsets, status, generics
from rest_framework.response import Response
from batch.Models.KeyValue import KeyValue
from rest_framework.decorators import action
from scripts.messages import Messages
from scripts.constants import Constants
import json
import logging
from datetime import datetime
from django.conf import settings
from batch.models import Profile, ClientUser
from django.contrib.auth.models import User
from scripts.constants import Constants

logger = logging.getLogger("scripts_logger")


class ProfileClass(viewsets.ViewSet):

    @staticmethod
    def get_valid_username(username):
        
        status = Constants.HTTP_SUCCESS
        # When user logs in with oauth (google), username & email are both email ids. Later, when user signs up with same email but
        # different username, the input username is updated in user table. So, when user tries to login with ouath again, the incoming
        # username, which is email id in case of oauth login, is not found in user table. To cater to such cases, below try-block is put.
        # If user tries to login with oauth, find his/her latest username and continue processing with that.
        try:
            user = User.objects.get(username = username)
        except User.DoesNotExist:
            user = User.objects.get(email = username)
        except User.DoesNotExist:
            logger.error(f'Severe error during login')
            message, status = Messages.severeLoginError.value
            return message, status

        return user, status


    @action(detail=True, methods=['POST'])
    def get_subscription(self, request):
        req = json.loads(request.body)
        username = req.get("username", None)

        obj, http_status = ProfileClass.get_valid_username(username)
        if http_status == Constants.HTTP_SUCCESS:
            username = obj.username
        else:
            return Response({'error':obj}, status)

        try:
            profile, client_user = ProfileClass.get_profile_client_user(username)
            result = {
                        'avatar': profile.avatar,
                        'subscription': client_user.subscription_uid.name
                    }
            message, status = Messages.success.value
        except Exception as e:
            logger.error(f'Profile, get subscription error: {e}')
            message, status = Messages.getSubsriptionError.value
            return Response({'error':message}, status)
        
        return Response({'data':result}, status)
        

    @staticmethod
    def get_profile_client_user(username):
        profile = Profile.objects.get(user__username = username)
        client_user = ClientUser.objects.get(id__username = username)
        return profile, client_user


    @action(detail=True, methods=['POST'])
    def get_profile_details(self, request):
        req = json.loads(request.body)
        username = req.get("username", None)

        obj, http_status = ProfileClass.get_valid_username(username)
        if http_status == Constants.HTTP_SUCCESS:
            username = obj.username
        else:
            return Response({'error':obj}, status)

        try:        
            profile, client_user = ProfileClass.get_profile_client_user(username)

            result = {
                        'name': client_user.id.first_name + " " + client_user.id.last_name,
                        'email': obj.email,
                        'subscription_id': client_user.client_user_uid + Constants.SUBSCRIPTION_ID_START,
                        'client': client_user.client_uid.client_name,
                        'contact': profile.mobile_number
            }
            message, status = Messages.success.value
        except Exception as e:
            logger.error(f'Profile, get profile details error: {e}')
            message, status = Messages.getProfileError.value
            return Response({'error':message}, status)

        return Response({'data':result}, status)

  