from django.db import models
from rest_framework import viewsets, status, generics
from rest_framework.decorators import action
from rest_framework.response import Response

class Class2(viewsets.ViewSet):
    @action(detail=True, methods=['GET'])
    def method1(self, request):
        return Response({"data": 'Class2.method1 response'})

    @action(detail=True, methods=['GET'])
    def method2(self, request):
        return Response({"data": 'Class2.method2 response'})
