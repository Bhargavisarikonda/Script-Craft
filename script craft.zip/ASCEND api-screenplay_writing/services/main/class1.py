from django.db import models
from rest_framework import viewsets, status, generics
from rest_framework.decorators import action
from rest_framework.response import Response

class Class1(viewsets.ViewSet):
    # detail=True means return only 1 object
    #@action(detail=True, methods=['GET'])
    def list(self, request):
        return Response({"data": 'Class1.method1 response'})

    @action(detail=True, methods=['GET'])
    def method2(self, request):
        return Response({"data": 'Class1.method2 response'})
