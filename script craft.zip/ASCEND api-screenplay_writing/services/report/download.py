from json.encoder import INFINITY
from unicodedata import name
from unittest import result
from django.db import models
from rest_framework import viewsets
from rest_framework import status
from rest_framework.decorators import action
from rest_framework.response import Response
from batch.models import Scene
import json
from ..src.utils import get_stop_words
from scripts.messages import Messages
from batch.models import Screenplay, Scene, UserList, ClientUser, Client, FeatureMeta,MetricCharacter, ScriptLevel
from batch.Models.MetricGenre import MetricGenre
from itertools import groupby
import math
import logging
from awsutils.views import AwsUtils

logger = logging.getLogger("scripts_logger")

class Download(viewsets.ViewSet):

    @action(detail=True, methods=['GET'])
    def get_download(self, request):
        screenplayuid = self.request.query_params.get("screenplayuid",None)

        try:
            screenplay_obj = Screenplay.objects.get(screenplay_uid = screenplayuid)
        except Screenplay.DoesNotExist:
            logger.critical(f"Screenplay not found: {screenplayuid}")
            message, status = Messages.screenplayNotFound.value
            return Response({"error": message}, status)

        presigned_url = AwsUtils().create_presigned_url(screenplay_obj.file_path )

        if presigned_url is None:
            message, status = Messages.presignedurlGenerationFailed.value
            return Response({"error": message + " - " + " Download failed"}, status)
        
        message, status = Messages.success.value
        return Response({"data": presigned_url}, status)
 

  