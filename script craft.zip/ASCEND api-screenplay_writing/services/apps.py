from django.apps import AppConfig
import os
import smtplib

class ServicesConfig(AppConfig):
    name = 'services'
    
