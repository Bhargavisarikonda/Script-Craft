from rest_framework import viewsets, status, generics
from rest_framework.response import Response
from batch.Models.KeyValue import KeyValue
from rest_framework.decorators import action
from scripts.messages import Messages
import json
import logging
from datetime import datetime
from django.conf import settings
from .utils import generate_random_otp

logger = logging.getLogger("scripts_logger")


class OTP(viewsets.ViewSet):

    @action(detail=True, methods=['POST'])
    def generate_otp(self, request):
        req = json.loads(request.body)
        email = req.get("email", None)

        message, status, _ = OTP.generate_otp_function(email)
        
        return Response(message, status)
        

    @staticmethod
    def generate_otp_function(email):
        now = datetime.now() 
        otp = generate_random_otp()
        value = {   "otp": otp,
                    "ts": str(now)
                }      
        value = json.dumps(value)
        try:
            KeyValue.objects.update_or_create(
                key = email,
                defaults = {"value" : value},
            )
            message, status = Messages.success.value
        except Exception as e:
            logger.error(f'keyvalue table: otp insertion failed; error: {e}')
            message, status = Messages.sqlerror.value

        return message, status, otp


    @action(detail=True, methods=['POST'])
    def validate_otp(self, request):
        req = json.loads(request.body)
        email = req.get("email", None)
        otp = req.get("otp", 0)

        message, status = OTP.validate_otp_funtion(otp, email)

        return Response({"data":message}, status)

    @staticmethod
    def validate_otp_funtion(otp, email):
        try:
            keyvalue = KeyValue.objects.get(key = email )
            #print('keyvalue ', keyvalue.value, email, otp)
            keyvalue = keyvalue.value
            # sometimes this  value appears as str instead of dict . e.g, it happened in prod, but not in dev
            if isinstance(keyvalue, str):
                keyvalue = json.loads(keyvalue)
            str_initial_time = keyvalue['ts']
            # Timestamp is in string format in table. Convert it to datetime format
            initial_time = datetime.strptime(str_initial_time, '%Y-%m-%d %H:%M:%S.%f')
            now = datetime.now()
            time_diff = now - initial_time

            if time_diff.seconds > settings.OTP_EXP:
                message, status = Messages.otpExpire.value
            else:
                if otp == keyvalue["otp"]:
                    message, status = Messages.success.value
                else:
                    message, status = Messages.otpInvalid.value        
                
        except KeyValue.DoesNotExist:
            message, status = Messages.otpInvalid.value
        except KeyValue.MultipleObjectsReturned:
            logger.error(f'keyvalue table: Multiple rows found; email : {email}')
            message, status = Messages.sqlerror.value
        except Exception as e:
            logger.error(f'keyvalue table: SQL error ; email : {email}; error: {e}')
            message, status = Messages.sqlerror.value

        return message, status
        

    