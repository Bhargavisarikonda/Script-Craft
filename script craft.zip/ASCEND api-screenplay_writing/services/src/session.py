

class Session:
    def __init__(self, request):
        self.session = request.session.get('decoded_token', None)
        #print('  self.session ',  self.session)
        
        # session will be None for users who are not logged in, because there's no jwt token.
        # In that case return 0 so that no rows are returned
        if self.session is None:
            self.session = {}
            self.session['tenant_id'] =  0
            self.session['user_id'] = 0

    def get_tenant_id(self):
        return self.session['tenant_id']

    def get_user_id(self):
        return self.session['user_id']

    def is_userid_valid(self):
        return self.session['user_id'] > 0
