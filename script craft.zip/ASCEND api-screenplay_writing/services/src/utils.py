from scripts.enums import DayTime, NightTime, SceneType
import pandas as pd
from wordcloud import STOPWORDS
from django.conf import settings
import random
import string



def get_stop_words():
    STOPWORDS.update({'INT','EXT','INT.','INT ','EXT.','EXT ','CONT','CONT D','CONT’D','INT\n','CONT\'D'})
    stopwords = set(STOPWORDS)
    return stopwords

def location_details(scene_qset):
    scene_df = pd.DataFrame.from_records(scene_qset.values())
    no_scenes = get_no_scenes(scene_df)
    int_scenes = get_int_scenes(scene_df)
    ext_scenes = get_ext_scenes(scene_df)
    int_ext_scenes = get_int_ext_scenes(scene_df)
    return (no_scenes, int_scenes + int_ext_scenes, ext_scenes + int_ext_scenes)

def get_no_scenes(df):
    no_scenes = len(df[df['scenetype_uid'] != SceneType.Preface.value ])
    return no_scenes

def get_int_scenes(df):
    no_scenes = len(df[df['scenetype_uid'] == SceneType.Interior.value ])
    return no_scenes

def get_ext_scenes(df):
    no_scenes = len(df[df['scenetype_uid'] == SceneType.Exterior.value ])
    return no_scenes

def get_int_ext_scenes(df):
    no_scenes = len(df[df['scenetype_uid'] == SceneType.Both.value ])
    return no_scenes

# def get_perc_scenes(df,no_scenes):
#     day_scenes = len(df[df['time_of_day']=='1'])
#     night_scenes = len(df[df['time_of_day']=='2'])
#
#     perc_day = 100*day_scenes/(day_scenes+night_scenes)
#     perc_night = 100*night_scenes/(day_scenes+night_scenes)
#
#     return perc_day, perc_night

def get_count_day_night(scene_qset):
    df = pd.DataFrame.from_records(scene_qset.values())
    day_scenes, night_scenes = 0, 0
    for entry in DayTime:
        day_scenes += len(df[df['time_of_day'] == entry.name])
    for entry in NightTime:
        night_scenes += len(df[df['time_of_day'] == entry.name])

    return day_scenes, night_scenes


def get_global_sentiments():
    return {
            'positive': 0,
            'neutral': 0,
            'negative': 0
            }

def generate_random_otp():
    size = settings.OTP_SIZE

    generatd_otp = ''.join([random.choice( string.ascii_uppercase +
                                        string.ascii_lowercase +
                                        string.digits)
                                        for n in range(size)])

    return generatd_otp

