from django.urls import path
from django.conf.urls import include
from services import views
from services.main import class1, class2
from services.wordcloud import wordcloud
from services.characters import characters, metric_character
from services.emotion import emotion
from services.genre import genre
from services.scrstats import scrstats
from services.misc import validation, feedback, subscription, visitor
from services.src import otp
from services.profile import profile
from services.report import download
from batch.features.genre import Genre
from . import explore

#from .views import sceneApi
from . import views
from rest_framework.routers import DefaultRouter
from rest_framework.decorators import permission_classes, authentication_classes
from rest_framework.permissions import AllowAny

router = DefaultRouter(trailing_slash=False)
#router.register(r'temp/feature1', class1.Class1, basename='feature1')
#router.register(r'test/dummy', views.DummyClass, basename='Dummy' )
#router.register(r'temp/feature3', class2.Class2, basename='feature3')
#router.register(r'temp/feature4', class2.Class2, basename='feature4')


urlpatterns = [
    #path('', include(router.urls)),
    path('explore', explore.Explore.as_view({'get': 'explore'}), name='explore'),
    path('post_explore', explore.Explore.as_view({'post': 'post_explore'}), name='post_explore'),
    path('explore/raiseexception', explore.Explore.as_view({'get': 'raise_exception'}), name='raise_exception'),
    path('explore/innerjoin', explore.Explore.as_view({'get': 'inner_join'}), name='inner_join'),
    path('explore/generic', explore.Explore.as_view({'get': 'check_password'}), name='check_password'),
    path('dashboard', views.DashboardAnalytics.as_view() , name='dashboard'),
    #path('dialogue/actionvsdialogues', views.SceneApi.as_view() , name='action'),
    path('dialogue/wordcloud', wordcloud.Wordcloud.as_view({'get': 'get_wordcloud'}) , name='wordcloud'),
    #path('temp/feature2', class1.Class1.as_view({'get':'method2'}), name='feature2'),
    #path('temp/feature3', class2.Class2.as_view({'get':'method1'}), name='feature3'),
    #path('temp/feature4', class2.Class2.as_view({'get':'method2'}), name='feature4'),
    path('dialogue/actionvsdialogue', views.ActionvsDialogueView.as_view() , name='actionvsdialogues'),
    path('scriptanalysis/location', views.LocationTypeView.as_view() , name='location'),
    path('characteranalysis/entryexit',metric_character.CharacterAnalysis.as_view({'get':'entryexit'}),name='entryexit'),
    path('characteranalysis/scenecount',metric_character.CharacterAnalysis.as_view({'get':'character_contribution'}),name='character_contribution'),
    path('characteranalysis/socialrelations', metric_character.CharacterAnalysis.as_view({'get': 'socialrelations'}),name='socialrelations'),
    path('characteranalysis/overview', metric_character.CharacterAnalysis.as_view({'get': 'overview'}),name='character_overview'),
    path('emotion/emotiongraph',emotion.Emotion.as_view({'get':'get_emotion_graph'}),name='emotionanalysis'),
    path('emotion/emotionanalytics',emotion.Emotion.as_view({'get':'get_emotion_analytics'}),name='emotionanalytics'),
    path('genre/genregraph',genre.Genre.as_view({'get':'get_genre_graph'}),name='genreanalysis'),
    path('genre/genreanalytics',genre.Genre.as_view({'get':'get_genre_analytics'}),name='genreanalytics'),
    path('screenplaystats',scrstats.Scrstats.as_view({'get':'get_screenplay_stats'}),name='screenplaystats'),
    path('scriptanalysis/genderratio',metric_character.GenderAnalysis.as_view({'get':'genderRatio'}),name='gender_ratio'),
    path('profile/subscription',profile.ProfileClass.as_view({'post':'get_subscription'}),name='get_subscription'),
    path('profile/details',profile.ProfileClass.as_view({'post':'get_profile_details'}),name='get_profile_details'),
    path('script/download',download.Download.as_view({'get':'get_download'}),name='get_download'),
    # Below urls dont need auth
    path('demo/scene', authentication_classes([])(permission_classes([AllowAny])(views.SceneStatsDemo)).as_view() , name='scene'),
    #path('demo/scene', authentication_classes([])(permission_classes([AllowAny,])(views.SceneStatsDemo)).as_view() , name='scene'),
    path('demo/characters', authentication_classes([])(permission_classes([AllowAny])(characters.Characters)).as_view({'get': 'get_characters_analysis'}), name='characters'),
    path('demo/dialogue', authentication_classes([])(permission_classes([AllowAny])(views.DialogueDemoView)).as_view({'get': 'get_dialogue_stats'}), name='dialogues'),
    path('home/feedback',authentication_classes([])(permission_classes([AllowAny])(feedback.PostFeedback)).as_view({'post':'send_feedback'}),name='send_feedback'),
    path('home/subscription', authentication_classes([])(permission_classes([AllowAny])(subscription.SubscriptionList)).as_view({'get':'get_subscriptions'}),name='get_subscriptions'),    
    path('home/samplescripts', authentication_classes([])(permission_classes([AllowAny])(views.SampleScripts)).as_view(), name='sample_scripts'),
    path('home/visitor', authentication_classes([])(permission_classes([AllowAny])(visitor.VisitorClass)).as_view({'post':'add_visitor'}),name='add_visitor'),
    path('field/validation', authentication_classes([])(permission_classes([AllowAny])(validation.Validation)).as_view({'post':'validate_field'}),name='validate_field'),
    #path('otp/generate', authentication_classes([])(permission_classes([AllowAny])(otp.OTP)).as_view({'post':'generate_otp'}),name='generate_otp'),
    path('otp/validate', authentication_classes([])(permission_classes([AllowAny])(otp.OTP)).as_view({'post':'validate_otp'}),name='validate_otp'),
]
