from typing import OrderedDict
from rest_framework.viewsets import ModelViewSet, ViewSet
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework import status
from django.db.models import Max,Min,Count, Sum
import logging
from django.db.models import F
import json
from batch.models import MetricCharacter, Scene, Tenant, ClientUser, Client, Subscription
from batch.Models.Misc import Feedback
from scripts.messages import Messages
import pandas as pd
from django.contrib.auth.models import User
from django.contrib.auth import login, hashers
from services.src.utils import get_global_sentiments
from scripts.enums import CompanyType


logger = logging.getLogger("scripts_logger")


class Explore(ViewSet):
    @action(detail=False, methods=['GET'])
    def explore(self, request):
        screenplayuid = request.query_params.get("screenplayuid",None)

        message, status = Messages.success.value
        result = { 
            "total_scenes": 50,
            "top_10_by_scene": [{'Tom': 30}, {'Amit': 22}, {'Rani': 17}, {'Amir': 15}, {'Salman': 10}, {'Sid': 9}, \
                {'Kareena': 7}, {'Saif': 6}, {'Tina':4}, {'Akshay': 2} ],
            "total_dialogs": 900,        
            "top_10_by_dialog": [{'Tom': 300}, {'Amit': 220}, {'Rani': 170}, {'Amir': 150}, {'Salman': 100}, \
                                {'Sid': 90}, {'Kareena': 70}, {'Saif': 60}, {'Tina':40}, {'Akshay': 20}],                             
            "sentiment": {'positive': 12.6, 'neutral': 26.9, 'negative':'10.5'}
        }

        # Get characters by scene count
        # Combination of values and annotate has the effect of Group by
        queryset = MetricCharacter.objects.filter(scene_uid__screenplay_uid__screenplay_uid = screenplayuid).\
                values('name', 'scene_uid').annotate(sum_dialogues=Sum('count_dialogues'))
        #print('explore ', queryset)

        if not queryset:
            message, status = Messages.charactersNotFound.value
            return Response(message, status)

        characters_by_scene = queryset.values('name').annotate(count_scenes=Count('scene_uid')).order_by('-count_scenes')
        logger.debug('characters_by_scene ', characters_by_scene)

        characters_by_dialogs = MetricCharacter.objects.filter(scene_uid__screenplay_uid__screenplay_uid = screenplayuid).\
                values('name').annotate(count_dialogues=Sum('count_dialogues'))
        logger.debug('characters_by_dialogs ', characters_by_dialogs)

        total_dialogs = characters_by_dialogs.values('count_dialogues').aggregate(sum_dialogs=Sum('count_dialogues'))
        logger.debug('total_dialogs ', total_dialogs)

        total_scenes = Scene.objects.filter(screenplay_uid=screenplayuid).count()
        logger.debug('total_scenes ', total_scenes)

        sentiments = get_global_sentiments()

        message, status = Messages.success.value
        result =    {'total_scenes': total_scenes,
                    'top_10_by_scene': characters_by_scene,
                    'top_10_by_dialog': characters_by_dialogs,
                    'total_dialogs': total_dialogs['sum_dialogs'],
                    "sentiment": sentiments,
                    }
        return Response({'data':result}, status)


    @action(detail=False, methods=['POST'])
    def post_explore(self, request):
        req = json.loads(request.body)
        #print('self.request ', req)
        email = req.get("email", None)
        selectedTopicItem = req.get("selectedTopicItem",None)
        comments = req.get("message",None)
        ip = req.get("ip", '0.0.0.0')

        feedback = Feedback(
                        email = email,
                        topic = selectedTopicItem,
                        comments = comments,
                        ip = ip
        )

        try:
            feedback.save()
        except Exception as e:
            logger.error(F'SQL error: {e}')
            message, status = Messages.sqlerror.value
            return Response(message, status)

        logger.info(f'SQL status code is {feedback}')

        message, status = Messages.success.value
        return Response({"data":message }, status)


    @action(detail=False, methods=['GET'])
    def raise_exception(self, request):
        raise Exception('This is for testing exception')

    @action(detail=False, methods=['GET'])
    def dummy_test(self, request):
        try:
            token = request.META.get('HTTP_AUTHORIZATION', " ").split(' ')[1]
            logger.debug('try : ', token)
        except Exception as e:
            logger.debug('token error ', e)
            token = "dummy"
        
        decoded_token = request.session.get('decoded_token')
        logger.debug("Dummy test decoded_data: ", decoded_token)
        message, status = Messages.success.value
        return Response({"data":message }, status)


    @action(detail=False, methods=['GET'])
    def inner_join(self, request):
        logger.debug(f'tenant before:  {CompanyType.individual_type.value}')
        client = Client.objects.get(client_name = CompanyType.individual_type.value)
        logger.debug(f'tenant after: {client.client_uid}')
        #print('tenant after ', tenant)

        #tenant.save()
        message, status = Messages.success.value
        return Response(message, status)


    @action(detail=False, methods=['GET'])
    def check_password(self, request):
        match = hashers.check_password("password1", 
                                "pbkdf2_sha256$216000$1tAQdUExJ37L$MuwK/LqdtMQhcWDSonC4VMm4quXk+QVonOGMflvreNY=")
        #clientuser.save()
        message, status = Messages.success.value
        return Response({"data":match }, status)