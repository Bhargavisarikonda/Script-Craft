import smtplib
import os
from email.message import EmailMessage
from scripts.constants import Constants
from scripts.enums import EmailType
from scripts import settings

def create_smtp_connection():
    smtp_user = os.environ.get('SMTP_USER')
    smtp_password = os.environ.get('SMTP_PASSWORD')
    smtp_host = os.environ.get('SMTP_HOST')
    smtp_port = os.environ.get('SMTP_PORT')
    smtp_module = smtplib.SMTP_SSL(smtp_host, smtp_port)
    smtp_module.set_debuglevel(int(os.environ.get('SMTP_DEBUG_LEVEL') ))
    smtp_module.login(smtp_user, smtp_password)

    return smtp_module

def is_smtp_connection_open(conn):
    try:
        status = conn.noop()[0]
    except:
        status = -1
    return True if status == 250 else False


conn = create_smtp_connection()

def send_smtp_mail(*args, from_address=Constants.SUPPORT_EMAIL):
    global conn
    to_address, _, _, _ = args

    body = build_text_body(*args)

    msg = EmailMessage()
    msg['Subject'] = "Your One-Time Password"
    msg['From'] = Constants.SUPPORT_EMAIL
    msg['To'] = to_address
    msg.set_content(body)
    if not is_smtp_connection_open(conn):
        conn = create_smtp_connection()

    conn.send_message(msg)

def user_forgot_password(*args):
   return build_text_body(*args)
   
   
def user_signup(*args):
   return build_text_body(*(args, EmailType.SignUp.value))


def build_text_body(*args):
   _, otp, username, purpose = args
   purpose = purpose.value

   msg = """
      Dear %s,
      
      This email is to provide you with One Time Password %s.

      Your OTP: %s
      This OTP is valid for %s minutes.

      For any queries, please contact us at %s
      

      Sincerely,

      %s""" % (username, purpose, otp, int(settings.OTP_EXP/60), Constants.SUPPORT_EMAIL, Constants.COMPANY + " Support")

   return msg
