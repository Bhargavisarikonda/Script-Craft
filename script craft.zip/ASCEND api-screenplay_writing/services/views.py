from django.shortcuts import render

# Create your views here.
from os import stat
from django.db.models.query import QuerySet
from django.shortcuts import render
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.views import APIView
from rest_framework.response import Response
from authx2 import serializer
#from ..scripts.messages import Messages
from scripts.messages import Messages
from rest_framework.permissions import BasePermission, IsAuthenticated, AllowAny
from rest_framework.authentication import BaseAuthentication
#from .serializer import TempSerializer
#from .models import Temp
from batch.models import Screenplay, Scene, UserList,MetricCharacter
from batch.Models.Misc import SampleScript
# from batch.Models.MetricCharacter import
from rest_framework import mixins
from rest_framework import generics
from django.db.models import Max,Min,Count
from .src.utils import get_count_day_night, location_details
from .src.session import Session
from .characters.stats import DummyAuthor
from .dialogue.dialoguedemo import DialogueDemo
from .dialogue.actionvsdialogue import ActionvsDialogue
from .location.locationtype import LocationType

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import sys
import re
import io
import json
import base64
import math
import logging


logger = logging.getLogger("scripts_logger")

class DummyClass(DummyAuthor):
    pass

class DialogueDemoView(DialogueDemo):
    pass

class ActionvsDialogueView(ActionvsDialogue):
    pass

class LocationTypeView(LocationType):
    pass

#@api_view(['POST'])
class SceneStatsDemo(APIView):

    #permission_classes = [AllowAny]

    # def home(request):
    #     if request.method == 'POST':
    def get(self,request):
        #print(request.body.decode()[7:])

        screenplayuid = self.request.query_params.get("screenplayuid",None)
        #print("screenplayuid " , screenplayuid)
        try:
            scene_qset = Scene.objects.filter(screenplay_uid=screenplayuid)
            #print('set ', scene_qset)
        except:
            #print('not found')
            scene_qset = None

        if not scene_qset.exists():
            message, status = Messages.notFound.value
            #print('not found ', message,status)
            return Response(message, status)

        no_scenes, int_scenes, ext_scenes = location_details(scene_qset)

        try:
            count_day, count_night = get_count_day_night(scene_qset)
        except:
            #message, status = Messages.notFound.value
            count_day, count_night = 0, 0
            #return Response(message, status)


        message, status = Messages.success.value
        rsp_msg = { 'no_scenes':no_scenes, 'int_scenes':int_scenes, 'ext_scenes':ext_scenes, 'count_day':count_day, 'count_night':count_night }
        #return Response(json.dumps(rsp_msg), status)
        return Response({"data": rsp_msg}, status)

class DashboardAnalytics(APIView):
    def get(self, request):
        #logger.debug("This is a DEBUG message for testing")
        #logger.info("This is a INFO message for testing")
        records = []

        tenant_id = Session(request).get_tenant_id()
        #print('dashboard ', tenant_id)

        try:
            #data = Screenplay.objects.all().order_by('-modified_on')
            data = Screenplay.objects.raw(
                        "select sr.screenplay_uid, sr.title, sr.success_percentage, sr.modified_on, sr.status, \
                            sr.file_path, sr.file_size, count(sc.*) as scene_count \
                            from screenplay sr left outer join scene sc \
                            on sr.screenplay_uid = sc.screenplay_uid \
                            where sr.tenant_uid = %s  \
                            group by 1,2,3,4,5, 6, 7    \
                            order by sr.modified_on desc", [tenant_id]
                        )
            #print('data ', data)
            for index in range(len(data)):
                records.append({'id': data[index].pk,
                        'title': data[index].title,
                        'success_percentage': data[index].success_percentage,
                        'modified_on': data[index].modified_on,
                        'scene_count': data[index].scene_count,
                        'status': data[index].status,
                        'file_path': data[index].file_path,
                        'file_size': data[index].file_size,
                        })
            _, status = Messages.success.value
            return Response({"data": records}, status)
        except Exception as e:
                _, status = Messages.severeError.value
                return Response({"error":str(e)}, status)

class SampleScripts(APIView):
    def get(self, request):
        try:
            data = SampleScript.objects.all().values()
        except Exception as e:
            _, status = Messages.severeError.value
            return Response({"error":str(e)}, status)
        _, status = Messages.success.value
        return Response({"data": data}, status)


# class SceneApi(APIView):
#     def get(self, request):
#         records = []
#         try:
#             data = Scene.objects.all()
#             print ("hello")
#             for index in range(len(data)):
#                 records.append({'count_action': data[index].count_action,
#                         'count_dialogues': data[index].count_dialogues,
#                         'count_words_action': data[index].count_words_action,
#                         'count_words_dialogues': data[index].count_words_dialogues,
#                         })
#             return Response({"data": records})
#         except Exception as e:
#                 return Response({"error":str(e)})
#
#     def post(self,request):
#
#         try :
#              new_data = request.data
#              new_scene = Scene.objects.create(scene_uid = new_data["scene_uid"],
#              scenetype_uid = new_data["scenetype_uid"],
#              screenplay_uid = new_data["screenplay_uid"],
#              count_action = new_data["count_action"],
#              count_dialogues = new_data["count_dialogues"],
#              scene_text = new_data["scene_text"],
#              scene_number = new_data["scene_number"],
#              count_words_action = new_data["count_words_action"],
#              count_words_dialogues = new_data["count_words_dialogues"],
#              time_of_day = new_data["time_of_day"],
#              location = new_data["location"])
#
#              new_scene.save();
#
#              return Response(new_scene)
#
#         except Exception as e:
#                 return Response({"error":str(e)})
