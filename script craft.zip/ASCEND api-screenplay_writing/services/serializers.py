from rest_framework import serializers
from services.models import Author
from batch.models import Scene



class SceneSerializer(serializers.ModelSerializer):
    class Meta:
        model=Scene
        fields = '__all__'
        #feilds=('count_action','count_dialogues','count_words_action','count_words_dialogues')

class AuthorSerializer2(serializers.ModelSerializer):
    class Meta:
        model = Author
        fields = '__all__'

class EntryExit(serializers.Serializer):
    character_name = serializers.CharField()
    screenplay_id = serializers.IntegerField()
    entry_scene_no = serializers.IntegerField()
    exit_scene_no = serializers.IntegerField()

class CharacterContribution(serializers.Serializer):
    character_name = serializers.CharField()
    screenplay_id = serializers.IntegerField()
    scene_cnt = serializers.IntegerField()

class ListCharacters(serializers.Serializer):
    person_name = serializers.CharField()
    person_gender = serializers.CharField()
    person_type = serializers.CharField()
    person_logline = serializers.CharField()
