from django.db import models


class MetricPlotSummary(models.Model):
    plot_summary_uid = models.AutoField(primary_key=True)
    screenplay_uid = models.SmallIntegerField()
    plot_summary = models.JSONField()
    created_on = models.DateTimeField(auto_now_add=True)
    created_by = models.TextField()
    modified_on = models.DateTimeField(auto_now_add=True)
    modified_by = models.TextField()

    class Meta:
        managed = False
        db_table = 'metric_plot_summary'

