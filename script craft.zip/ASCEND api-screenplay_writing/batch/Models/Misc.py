from django.db import models


class Feedback(models.Model):
    feedback_uid = models.AutoField(primary_key=True)
    fullname = models.TextField()
    email = models.TextField()
    topic = models.TextField()
    comments = models.TextField()
    ip = models.TextField()

    class Meta:
        managed = False
        db_table = 'feedback'


class SampleScript(models.Model):
    sample_uid = models.AutoField(primary_key=True)
    title = models.TextField()
    language = models.TextField()
    link = models.TextField()
    type = models.TextField()    # Movie, OTT etc.

    class Meta:
        managed = False
        db_table = 'sample_script'


class Visitor(models.Model):
    visitor_uid = models.AutoField(primary_key=True)
    screen = models.TextField()
    action = models.TextField()
    geo_details = models.TextField()
    created_on = models.DateTimeField(auto_now_add=True)


    class Meta:
        managed = False
        db_table = 'visitor'

