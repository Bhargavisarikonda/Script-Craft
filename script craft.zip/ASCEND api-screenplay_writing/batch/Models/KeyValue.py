from django.db import models


class KeyValue(models.Model):
    key = models.TextField(primary_key=True)
    value = models.TextField()


    class Meta:
        managed = False
        db_table = 'key_value'

