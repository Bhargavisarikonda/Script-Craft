from django.db import models


class MetricGenre(models.Model):
    genre_uid = models.AutoField(primary_key=True)
    scene_uid = models.SmallIntegerField()
    action_id = models.SmallIntegerField()
    genres = models.JSONField()
    created_on = models.DateTimeField(auto_now_add=True)
    created_by = models.TextField()
    modified_on = models.DateTimeField(auto_now_add=True)
    modified_by = models.TextField()

    class Meta:
        managed = False
        db_table = 'metric_genre'

