from django.db import models


class MetricEmotion(models.Model):
    emotion_uid = models.AutoField(primary_key=True)
    scene_uid = models.SmallIntegerField()
    dialogue_id = models.SmallIntegerField()
    emotions = models.JSONField()
    created_on = models.DateTimeField(auto_now_add=True)
    created_by = models.TextField()
    modified_on = models.DateTimeField(auto_now_add=True)
    modified_by = models.TextField()

    class Meta:
        managed = False
        db_table = 'metric_emotion'

