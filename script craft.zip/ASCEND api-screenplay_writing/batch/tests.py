from django.test import TestCase
import os

# Create your tests here.
import base64
import requests
import json


pdf_file_path = os.path.abspath('../batch/media/Prestige.pdf') #insert path
with open(pdf_file_path,'rb') as pdf_file:
    encoded_string = base64.encodebytes(pdf_file.read())


url = 'http://127.0.0.1:8000/api/v1/upload-batch' #change url if needed
r = requests.post(url, json.dumps({'body':encoded_string.decode('utf-8'), 'username':'' }))

print("done")