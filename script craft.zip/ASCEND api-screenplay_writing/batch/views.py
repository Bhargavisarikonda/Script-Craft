from os import stat
from typing import OrderedDict
from xml.dom import ValidationErr
from django.db.models.query import QuerySet, F
from django.shortcuts import render
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.models import User, AnonymousUser
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.views import APIView
from rest_framework.response import Response
from authx2 import serializer
from batch.src.utils import get_ip_address, process_geo
from batch.src.utils import get_wordCounts,cleanup_dialogue,cleanup_action
from django.db.models import Max, Min
#from ..scripts.messages import Messages
from scripts.messages import Messages
from rest_framework.permissions import BasePermission, IsAuthenticated, DjangoModelPermissionsOrAnonReadOnly, AllowAny
#from .serializer import TempSerializer
from authx2.models import Temp
from .models import Screenplay, Scene, UserList, ClientUser, Client, FeatureMeta,MetricCharacter, ScriptLevel, Subscription, \
    Language, Transliteration, Tenant
from rest_framework import mixins
from rest_framework import generics
from scripts.enums import DayTime, NightTime, SystemUsers, SceneAttribute, Level, AIModels, ScreenplayStatus,SceneType, ContTime
from scripts.constants import Constants
from awsutils.views import AwsUtils
from django.conf import settings
import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import sys
import os
import re
import io
import json
import base64
import jwt
import ast
import nltk
from itertools import chain
from datetime import datetime
import time
import logging
from .models import SignupLog
from .src.process_fitz import parse_PDF, get_title, get_scenes_count, get_scene_text_ordered, get_scenetype_uid, get_tod, get_loc
from rest_framework import viewsets
from django.shortcuts import get_object_or_404
from django.http import JsonResponse
from .src.rules import *
from .features.emotion import Emotion
from .features.genre import Genre
from .features.plotsummary import PlotSummary
from .features.character import Character
from services.src.session import Session

#from batch import serializer
# Create your views here.

logger = logging.getLogger("scripts_logger")

#@api_view(['POST'])
class UploadBatch(APIView):

    #permission_classes = [DjangoModelPermissionsOrAnonReadOnly]
    feature_dict = OrderedDict()
    # def home(request):
    #     if request.method == 'POST':
    def __init__(self):
        self.user_uid = 0
        self.script_title = "Title not found"
        self.screenplay_model = None
        self.file_url = None
        self.file_size = 0
        self.language_uid = 0
        self.tenant = None
        self.geo_location = {}
        self.ip_address = ""
        self.process_time = 0
        self.clt_uid = 0
        self.request = None
        self.failure_reason = ""

    
    def upload_pdf(self):
        script_name = f'{self.script_title}_script_{int(time.time())}.pdf'
        script_name = script_name.replace(' ', '')
        file_path = f'{self.clt_uid}/scripts/{script_name}'
        pdf_content = json.loads(self.request.body)['body']
        self.file_url = AwsUtils().upload_file(base64.b64decode(pdf_content), file_path)
        self.file_size = sys.getsizeof(pdf_content)

    def create_screenplay(self, status):
        self.upload_pdf()
        self.screenplay_model = Screenplay(title=self.script_title,created_by=self.user_uid,modified_by=self.user_uid, \
                status=status, user_uid=self.user_uid, file_path=self.file_url, file_size=self.file_size,\
                    language_uid=self.language_uid, tenant_uid=self.tenant, ip_address=self.ip_address, \
                        geo_location= self.geo_location, process_time=self.process_time, failure_reason=self.failure_reason )
        self.screenplay_model.save()

    def update_screenplay(self, pc_flag, start_time):
        screenplay_update = Screenplay.objects.get(screenplay_uid=self.screenplay_model.screenplay_uid)
        if pc_flag==0:
            screenplay_update.status = ScreenplayStatus.Completed.name
        else:
            screenplay_update.status = ScreenplayStatus.PartialComplete.name
        
        screenplay_update.process_time = time.time()-start_time
        screenplay_update.save(update_fields=['status','process_time'])
    
    def post(self, request):
        self.request = request
        session = Session(request)
        tenant_id = session.get_tenant_id()
        session_user_id = session.get_user_id()

        try:
            self.tenant = Tenant.objects.get(pk=tenant_id)
        except Tenant.DoesNotExist:
            # Anonymous user - didnt login
            self.tenant = None

        pc_flag = 0
        anonymous = True
        start_time = time.time()

        if session.is_userid_valid():
            user_uid = session_user_id
        else:
            # Anonymous user - didnt login
            # Get username sent from UI
            uname = request.user.__str__()
            
            if AnonymousUser().__str__() == uname:
                anonymous = True
            else:
                anonymous = False

            try:
                userlist_qset = User.objects.get(username=uname)
            except User.DoesNotExist:
                # In the beginning of time, a row for anonymous user will have to be inserted
                if anonymous:
                    userlist_qset = User.objects.create(username=uname, password=uname, first_name=uname, last_name=uname, is_superuser=False,  \
                                email=uname, is_staff=False, is_active=False)
                else:
                # Strange!!! How did a non-anonymous user pass jwt authentication layer and reach here, just to find there is no row in 
                # user table ?
                    self.user_uid = -1
                    self.process_time = -1
                    self.failure_reason, status = Messages.BA03.value
                    self.create_screenplay(ScreenplayStatus.Failed.name)
                                        
                    #rsp_msg = { 'status':message }
                    return Response(self.failure_reason, status)

            user_uid = userlist_qset.id
        
        #print("******************* ", user_uid )
        logger.debug(f'Upload jwt username: {user_uid} ; {request.user} ; {AnonymousUser().__str__()} ')

        self.user_uid = user_uid

        # If user didnt login then it's an AnonymousUser. Set subscription id to minimum, usually 1.
        if anonymous:
            subscription_uid = Subscription.objects.all().aggregate(Min_sub=Min('subscription_uid'))['Min_sub']
            #user_uid = 0            
        else:
            # Find the subscription id of user by looking into client table
            #uname = json.loads(request.body)['username']
            #if uname=='':
            #    uname='none'

            #userlist_qset = User.objects.get(username=uname)
            #user_uid = userlist_qset.id
            #print(userlist_qset.user_uid)

            cltuser_qset = ClientUser.objects.get(id=user_uid)
            self.clt_uid = cltuser_qset.client_uid
            subscription_uid = cltuser_qset.subscription_uid

            #clt_qset = Client.objects.get(client_uid=clt_uid)
            #subscription_uid = clt_qset.subscription_uid

        # Fetch transliteration details
        #language = os.environ.get('LANGUAGE').title()
        req = json.loads(request.body)
        language = req['language'].title()
        logger.debug(f'Screenplay language {language}')

        self.geo_location, self.ip_address = process_geo(req['geo'])
        logger.debug(f"geo_location: {self.geo_location}")
        logger.debug(f"ip address: {self.ip_address}")

        """
        self.geo_location = json.loads(req['geo'])
        try:
            self.ip_address = get_ip_address(self.geo_location)
        except Exception as e:
            logger.error("Geo details structure is incorrect: ", e)
        logger.info(f'ip addr & geo loc: {self.ip_address}, {self.geo_location}')
        """
        # Django ORM to join two tables and select few columns from both tables
        transliteration_qs = Transliteration.objects.filter(language_uid__language=language).\
            select_related('Language').\
            values('active', 'class_name', 'method_name', language_id=F('language_uid__language_uid'),\
                language=F('language_uid__language'), vernacular=F('language_uid__vernacular'))
            
        logger.debug(f'transliteration_qs: {transliteration_qs}')


        if transliteration_qs.exists():
            transliteration_qs = transliteration_qs[0]
        else:
            self.process_time = -1
            self.failure_reason , status = Messages.BA04.value
            self.create_screenplay(ScreenplayStatus.Failed.name)
            # Invalid language 
            
            #rsp_msg = { 'status':message }
            return Response(self.failure_reason, status)

        self.language_uid = transliteration_qs['language_id']
        #print('self.language_uid ', self.language_uid)

        success_transliteration = False
        # Transliteration for all vernacular, non-English languages
        if transliteration_qs['vernacular']:
            if transliteration_qs['active']:
                try:
                    # placeholder to call the method
                    # If success then success_transliteration = True
                    pass
                except:
                    self.process_time = -1
                    self.failure_reason, status = Messages.BA05.value
                    self.create_screenplay(ScreenplayStatus.Failed.name)
                    # Transliteration failed

                    #rsp_msg = { 'status':message }
                    return Response(self.failure_reason, status)
            else:
                logger.warn(f"Transliteration is not enabled for {language}. Results would be incorrect.")
        else:
            logger.info(f'Transliteration not required for {language}')


        # Reason why the below sql is run in apps.py as well as here is this - In apps.py the actual load of model will happen, so if a 
        # new feature is added, since it'll have a model, server will have to be restarted. So. why dont we use result set from apps.py
        # here, why run the SQL again for every pdf upload? It's because if we change the subscription level of any feature, we dont have
        # to restart server, the next pdf upload will dynamically pick it if we run the sql below.
        # Fetch features from table
        feature_qset = FeatureMeta.objects.filter(subscription_uid__lte=subscription_uid, active=True,
                                level_uid = ScriptLevel.objects.get(level_type = Level.Scene.name).level_uid ) \
                                .values()
        #print('features ', feature_qset)
        scene_rules_list = [x for x in feature_qset]

        fp=io.BytesIO(base64.b64decode(json.loads(request.body)['body']))
        #fp = request.FILES['myfile']
        logger.info(f'Type: {type(fp)}')

        try:
            
            full_script_df = parse_PDF(fp)
            
            # Above module returns a severe error
            if type(full_script_df) == type(Response()):
                self.failure_reason = full_script_df.data
                self.create_screenplay(status=ScreenplayStatus.Failed.name)
                return full_script_df
                            
        except Exception as e:
            self.process_time = time.time()-start_time
            self.failure_reason, status = Messages.BA01.value
            self.create_screenplay(status=ScreenplayStatus.Failed.name)
            logger.error(f'Batch view failed with BA01: {e}')

            #rsp_msg = { 'status':message }
            return Response(self.failure_reason, status)

        #plt_l = script_processor.get_areaPlot_lines()
        #plt_a = script_processor.get_areaPlot_words()
        #print('script_processor.scenes[0] ', script_processor.scenes[0])
        try:
            self.script_title = get_title(full_script_df).strip()
        except Exception as e:
            pc_flag=1
            logger.error(f"Get title error: {e}")
   
        #screenplay_model = Screenplay(title=script_title,created_by=user_uid,modified_by=user_uid,status=ScreenplayStatus.Inprogress.name)
        #screenplay_model.save()
        #print('script name ', self.script_title)
        
        self.create_screenplay(status=ScreenplayStatus.Inprogress.name)
        #screenplay_model = Screenplay(title=script_title,created_by=user_uid,modified_by=user_uid,status=ScreenplayStatus.Inprogress.name, url=file_url)
        #screenplay_model.save()

        total_scene_no = get_scenes_count(full_script_df)
        
        total_action_scenes_txt = ''
        prev_tod = ''
        st11 = 0
        for i in range(total_scene_no+1):
            
            logger.info(f"Scene no. {i}")
            
            try:
                
                scenetype_uid = get_scenetype_uid(full_script_df, i)
                
                screenplay_uid = self.screenplay_model.screenplay_uid
                
                scene_text_ordered = get_scene_text_ordered(full_script_df, i)
                if i == 0:
                    logger.debug(f"Header of screenplay: {scene_text_ordered}\n\n")                 

                st1 = time.time()

                # W/o transliteration dialogue cleanup will mess up non-english dialogues. Hence, check conditions
                # If English, or if non-english and transliteration successful, then do dialogue cleanup.
                if ( (not transliteration_qs['vernacular']) or (transliteration_qs['vernacular'] and success_transliteration )  )  :
                    #print('DIALOGUE cleanup')
                    scene_text_ordered = cleanup_dialogue(scene_text_ordered)
                #else:
                #    print('NO DIALOGUE cleanup')

                st11 += time.time() - st1
                st1 = UploadBatch.log(st1, "Inside scene part11 ", i) 

                scene_text_ordered = cleanup_action(scene_text_ordered)
                count_words_action, count_words_dialogues, count_action, count_dialogues = get_wordCounts(scene_text_ordered)
                
                action_scenes_text = ''
                for text in json.loads(scene_text_ordered):
                    if text['Type'] == SceneAttribute.Action.name:
                        total_action_scenes_txt += text['Text']
                        action_scenes_text += text['Text']
                
                
                scene_number = i
                
                tod, prev_tod = get_tod(full_script_df, i, prev_tod)
                
                loc = get_loc(full_script_df, i, scenetype_uid)
                
                scene_model = Scene(scenetype_uid=scenetype_uid,
                                    screenplay_uid=Screenplay.objects.get(screenplay_uid=screenplay_uid),
                                    count_action=count_action,
                                    count_dialogues=count_dialogues,
                                    scene_text=scene_text_ordered,
                                    scene_number=scene_number,
                                    count_words_action=count_words_action,
                                    count_words_dialogues=count_words_dialogues,
                                    time_of_day=tod,
                                    location=loc)
                scene_model.save()
                # classify the emotions in the scene
    
                #Emotion().classify(scene_model, scene_txt_ordered, user_uid)
    
                #print(rules_list)
    
    
                ##  load metric_character here
    
                # metric_character_model = MetricCharacter
                #                     (
                #                         name =
                #                         gender =
                #                         count_dialogues =
                #                         count_words_dialogues =
                #                         scene_uid = scene_fields.scene_uid
                #                         sceneattribute_uid =
                #                         created_by = SystemUsers.Batch.name
                #                         modified_by = SystemUsers.Batch.name
                #                     )
    
                ## end metric_character
            except Exception as e:
                logger.error(f'BA02; Scene no. {i} has error: {e}')
                #print(i,e)
                pc_flag=1
                self.process_time = time.time()-start_time
                self.failure_reason, status = Messages.BA02.value
                self.create_screenplay(ScreenplayStatus.Failed.name)

                #rsp_msg = { 'status':message }
                return Response(self.failure_reason, status)

            screenplay_model = self.screenplay_model
            args = "(scene_model, screenplay_model, scene_text_ordered, user_uid, action_scenes_text)"

            total_character, total_emotion, total_genre = 0, 0, 0
            # scene number 0 is title, headers etc. So skip it.
            if scene_number > 0:
                for feature in scene_rules_list:
                    #print('feature ', feature)
                    #logger.debug(f'feature: {feature}')
                    try:
                        class_name = feature['class_name']
                        method_name = feature['method_name']
                        invocation = class_name + '(*' + args + ').' + method_name + '()'
                        #print('invocation ', invocation)
                        st = time.time()
                        exec(invocation)
                        # Initialize the dict 
                        if i == 0:
                            self.feature_dict = OrderedDict()                        
                        UploadBatch.measureTime(class_name, st)
                    except Exception as e:
                        logger.error(f"{feature['class_name']}  - Processing failed; error: {e}")
                        #print('e ', e)
                        pc_flag=1
                        continue
                        
        
        ## End of scene level processing

        #feature_screenplaylevel_qset = FeatureMeta.objects.filter(subscription_uid__lte=subscription_uid, active=True,
        #                        level_uid = ScriptLevel.objects.get(level_type = Level.Screenplay.name).level_uid ) \
        #                        .values()
        

        # Following commented code is for Plot summary generation which is on stall now.
        # args = "(total_action_scenes_txt, screenplay_uid, user_uid)"
        # for feature in feature_screenplaylevel_qset:
        #     class_name = feature['class_name']
        #     method_name = feature['method_name']
        #     invocation = class_name + '(*' + args + ').' + method_name + '()'
        #     #print('invocation ', invocation)
        #     exec(invocation)

        # Update the status in screenplay table 
        self.update_screenplay(pc_flag, start_time)      
        
        # Closing processing
        screenplay_uid = self.screenplay_model.screenplay_uid
        message, status = Messages.success.value
        rsp_msg = { 'screenplayuid':screenplay_uid, 'status':message }
        logger.info(f'Features time in secs: {UploadBatch.feature_dict} ')
        logger.info(f'Total split times in secs... st11: {st11} ')
        logger.info(f'Total time in secs: {time.time() - start_time } ')
        return Response(rsp_msg, status)

        #return HttpResponse("Processing done")
        #return HttpResponse(plt_l, content_type="image/png")

    @classmethod
    def measureTime(cls, class_name, st):
        #logger.debug(f'measure time for {class_name}')
        if class_name in cls.feature_dict.keys():
            cls.feature_dict[class_name] += time.time() - st
            #logger.debug(f'If loop"  {cls.feature_dict[class_name]}')
        else:
            cls.feature_dict[class_name] = time.time() - st
            #logger.debug(f'Else loop: {cls.feature_dict[class_name]}')

    @staticmethod
    def log(st, str1, indx=0):
        #if 'indx' in locals():
        #    indx += 1
        #else:
        #    indx = 1
        logger.info("                          ")
        logger.info(f"{indx}. {str1} time = %f ", time.time() - st)
        logger.info("                          ")

        return time.time()

    @staticmethod
    def getTime():
        now = datetime.now()
        current_time = now.strftime("%H:%M:%S")
        return current_time

# class TempView(APIView):

#     queryset = Temp.objects.all()
#     #serializer_class = TempSerializer

#     def post(self, request):
#         serializer = TempSerializer(data=request.data)
#         if serializer.is_valid():
#             serializer.save()
#             message, st = Messages.testPass.value
#             return Response(message, st)
#         message, status = Messages.testFail.value
#         return Response(message, status)


#     def get(self, request):
#         message, st = Messages.testPass.value
#         templist = [(temp.id, temp.value) for temp in Temp.objects.all()]
#         return Response(templist , st)
#         #return self.list(request, st)

class TempView(generics.ListCreateAPIView):

    queryset = Temp.objects.all()
    serializer_class = serializer.TempSerializer
    permission_classes = [AllowAny,]


    def post(self, request):
        message, st = Messages.testFail.value
        return self.create(request, st)


    def get(self, request):
        message, st = Messages.testPass.value
        return self.list(request, st)

