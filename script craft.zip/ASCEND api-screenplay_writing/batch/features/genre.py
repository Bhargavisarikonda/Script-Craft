from batch.apps import MainConfig
from ..Models.MetricGenre import MetricGenre
from .basefeature import BaseFeature
import json

class Genre(BaseFeature):
    def __init__(self, *args):
        super().__init__(*args)
        self.action_number = 0
        self.genre_classifier = MainConfig.genre_classifier
    def action_processing(self):
        self.action_number += 1
        plot = self.action_scenes_text

        result = self.genre_classifier(plot, truncation= True)

        self.results = MetricGenre(scene_uid=self.scene_model.scene_uid,
                        action_id=self.action_number,
                        genres=json.dumps(result),
                        created_by=self.user_uid,
                        modified_by=self.user_uid)

        self.save_results()

        return result
