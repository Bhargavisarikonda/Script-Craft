
from scripts.enums import SceneAttribute
import json

class BaseFeature():
    def __init__(self, *args):
        self.scene_model, self.screenplay_model, self.scene_txt_ordered, self.user_uid, self.action_scenes_text, *_ = args
        self.AImodel = None
        self.text_Text = ""
        self.results = None

    def classify(self):
        self.execute()

    def ner(self):
        self.execute()

    def summarize(self):
        # override this method for summarize
        pass

    def execute(self):
        for text in json.loads(self.scene_txt_ordered):
            self.text_Text = text['Text']
            if text['Type'] == SceneAttribute.Dialogue.name:
                self.dialogue_processing()
            elif text['Type'] == SceneAttribute.Action.name:
                self.action_processing()
        self.post_processing()

    def dialogue_processing(self):
        # override this method for dialogues
        pass

    # override this method for action
    def action_processing(self):
        pass

    def post_processing(self):
        pass

    def save_results(self):
        self.results.save()
