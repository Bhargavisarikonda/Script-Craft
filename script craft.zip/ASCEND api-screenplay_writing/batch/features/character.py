import json
import sys
import flair
import re
from flair.data import Sentence
from batch.apps import MainConfig
from batch.models import MetricCharacter, Characters, Screenplay
from .basefeature import BaseFeature
from typing import OrderedDict
from scripts.constants import Constants
from scripts.enums import SceneAttribute
from batch.src.utils import clean_text, get_gender, clean_text, clean_actor_name

class Character(BaseFeature):
    def __init__(self, *args):
        super().__init__(*args)
        self.model = MainConfig.character_ner_model
        self.dialogue_actor_dict = OrderedDict()
        self.action_actor_list = []

    # override
    def dialogue_processing(self):
        only_dialogue = self.text_Text.split("\n")[1:]
        cleaned_text = clean_text('\n'.join(only_dialogue))
        #print("cleaned text ", cleaned_text)        
        dialogue_word_count = len(cleaned_text.split(" "))
        # dialogue_actor = [{"John": [count_dialogues, count_words_dialogues]}, {}..]
        
        dialogue_actor = self.get_dialogue_character()
        if dialogue_actor == "":
            pass
        else:
            if dialogue_actor in self.dialogue_actor_dict:
                self.dialogue_actor_dict[dialogue_actor][0] += 1
                self.dialogue_actor_dict[dialogue_actor][1] += dialogue_word_count
            else:
                self.dialogue_actor_dict[dialogue_actor] = [1, dialogue_word_count]

    def get_dialogue_character(self):
        #print(text)
        # only consider first line of dialogue for character
        s = Sentence(self.text_Text.split('\n')[0])
        self.model.predict(s)

        actor = self.identify_characters(s)
        #print('DIALOGUE ', actor, self.text_Text)
        # Empty - this happens when dialogues are not cleaned up well and entire dialogue doesnt contain character
        if not actor:
            return ""
        else:
            # In 1st line of dialogue there will be only one person, so take the first entry of list
            actor = actor[0]

        #actor = self.text_Text.split('\n')[0]
        #actor = actor.strip('(V.O.)').strip("(CONT'D)").strip()
        for filler in Constants.NAME_SUFFIXES:
            actor = actor.replace(filler, "")
        start_bracket = actor.find("(")
        actor = actor[:start_bracket] if start_bracket > -1 else actor

        # Below function accepts and returns a list. But here we dont have a list, only one actor
        actor = clean_actor_name([actor])[0]
        # remove leading/trailing space and change to title case
        return actor.strip().title()


    # This logic works for flair 0.10
    @staticmethod
    def logic_for_oldflair(sentence):
        actor_list = []
        persons = sentence.to_dict(tag_type='ner')
        for person in persons['entities']:
            if 'PERSON' in str(person['labels']):
                # change to title case
                actor_list.append(person['text'].title())
        return actor_list

    # This logic works for flair > 0.11
    @staticmethod
    def logic_for_newflair(sentence):
        actor_list = []
        # for entity in sentence.get_spans('ner'):
        #     print(f'entity.text is: "{entity.text}"')
        #     #print(f'entity.start_position is: "{entity.start_position}"')
        #     #print(f'entity.end_position is: "{entity.end_position}"')
        #     print(f'entity "ner"-label value is: "{entity.get_label("ner").value}"')
        #     print(f'entity "ner"-label score is: "{entity.get_label("ner").score}"\n')

        for label in sentence.get_labels('ner'):
            if label.value == 'PERSON':
                actor_list.append(label.data_point.text.title())
            # # print label value and score
            # print(f'label.value is: "{label.value}"')
            # print(f'label.score is: "{label.score}"')
            # # access the data point to which label attaches and print its text
            # print(f'the text of label.data_point is: "{label.data_point.text}"\n')
        return actor_list

    @staticmethod
    def identify_characters(sentence):
        _, version, *_ = flair.__version__.split(".")
        if int(version) < 11:
            actor_list = Character.logic_for_oldflair(sentence)
        else:
            actor_list = Character.logic_for_newflair(sentence)
            
        for ii, actor in enumerate(actor_list):
            # Retain aplhabets, numbers and space, remove others
            clean_actor = re.sub(Constants.ALPHANUM_SPACE, "", actor,0, re.IGNORECASE)
            actor_list[ii] = clean_actor
            
        return actor_list

    # override
    def action_processing(self):
        # action_actors = ["John", "Mary",..]
        action_actors = self.get_action_character()
        self.action_actor_list.extend(action_actors)
    
    def get_action_character(self):
        #without_header = ' '.join(self.text_Text.split('\n')[1:])
        actor_list = []
        s = Sentence(' '.join(self.text_Text.split('\n')))
        self.model.predict(s)
        actor_list = Character.identify_characters(s)
        #print('ACTION ', actor_list, self.text_Text)
        # persons = s.to_dict(tag_type='ner')
        #print('persons ', actor_list, self.text_Text)
        # for person in persons['entities']:
        #     if 'PERSON' in str(person['labels']):
        #         # change to title case
        #         actor_list.append(person['text'].title())

        # Same name may appear as first name, or full name at different places; pick them as single name
        # if list is of size 0 or 1, return
        if len(actor_list) > 1:
            # remove duplicate names
            actor_set = set(actor_list)
            # sort, with shortest names at the start
            sorted_actor_list = sorted(list(actor_set), key=len)
            actor_list = sorted_actor_list
            #print("All names in action ", actor_list)
            # return if size is only 1
            if len(actor_list) > 1:
                # if there are names ['Jake', 'Freddy', 'Jake Scully'], 1st and 3rd names are of same person, so remove 3rd one - longer name
                for ii in range(len(actor_list) - 1):
                    for jj in range(ii+1, len(actor_list)):
                        # As list gets popped, the len reduces and causes index error. Try is to handle that normally
                        try:
                            if actor_list[ii] in actor_list[jj]:
                                actor_list.pop(jj)
                        except:
                            pass
        if actor_list:
            actor_list = clean_actor_name(actor_list)
        #print('Unique actor list ', actor_list)
        return actor_list


    # override
    def post_processing(self):
        action_actor_list = self.action_actor_list
        dialogue_actor_dict = self.dialogue_actor_dict
        dialogue_actor_list = list(dialogue_actor_dict.keys())
        overall_actors_set = set(action_actor_list + dialogue_actor_list)

        #print('overall_actors_set ', overall_actors_set)
        for actor in overall_actors_set:

            if actor in (dialogue_actor_list, action_actor_list):
                sceneattribute_uid = SceneAttribute.Both.value
            elif actor in dialogue_actor_list:
                sceneattribute_uid = SceneAttribute.Dialogue.value
            elif actor in action_actor_list:
                sceneattribute_uid = SceneAttribute.Action.value
            gender = get_gender(actor)
            #name = actor
            if actor in dialogue_actor_dict:
                count_dialogues = dialogue_actor_dict[actor][0]
                count_words_dialogues = dialogue_actor_dict[actor][1]
            else:
                count_dialogues, count_words_dialogues = -1, -1

            # using screenattribute array, get sceneattribute_uid
            #print("\n")
            #self.print_metric_character(*(actor, gender, count_dialogues, count_words_dialogues, sceneattribute_uid ))
            #print('actor ', actor, count_dialogues, count_words_dialogues, gender)
            try:
                person = Characters.objects.get(name=actor, screenplay_uid=self.screenplay_model.screenplay_uid)
            except Characters.DoesNotExist:                    
                ##  load metric_character here
                self.results = Characters \
                                (
                                    name = actor,
                                    gender = gender,
                                    type = "",
                                    logline = "",
                                    screenplay_uid = self.screenplay_model,
                                    created_by = self.user_uid,
                                    modified_by = self.user_uid
                                )
                self.save_results()
                person = self.results

            self.results = MetricCharacter \
                            (
                                person_uid = person,
                                count_dialogues = count_dialogues,
                                count_words_dialogues = count_words_dialogues,
                                scene_uid = self.scene_model,
                                sceneattribute_uid = sceneattribute_uid,
                                created_by = self.user_uid,
                                modified_by = self.user_uid
                            )

            self.save_results()

    #def print_metric_character(self, *args):
    #    print(args)