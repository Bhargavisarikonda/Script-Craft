
import json
from batch.apps import MainConfig
from ..Models.MetricEmotion import MetricEmotion
from .basefeature import BaseFeature


class Emotion(BaseFeature):
    def __init__(self, *args):
        super().__init__(*args)
        self.model = MainConfig.emotion_classifier
        self.dialogue_number = 0

    def dialogue_processing(self):
        self.dialogue_number += 1
        self.text_Text = self.text_Text.strip('\n').strip('\t')
        #print(' self.dialogue_number ', self.dialogue_number)
        result = self.model(self.text_Text)
        self.results = MetricEmotion(scene_uid=self.scene_model.scene_uid,
                        dialogue_id=self.dialogue_number,
                        emotions=json.dumps(result),
                        created_by=self.user_uid,
                        modified_by=self.user_uid)

        self.save_results()

# class Emotion1():
#     def __init__(self):
#         self.emotion_classifier = MainConfig.classifier
#     def classify(self, scene_model, scene_txt_ordered, user_uid):
#         dialogue_number = 0
#         for text in json.loads(scene_txt_ordered):
#             if text['Type'] == 'Dialogue':
#                 dialogue_number += 1
#                 # remove special characters \n and \t if present.
#                 text['Text'] = text['Text'].strip('\n').strip('\t')
#                 # get the emotion metrics from the model
#                 result = self.emotion_classifier(text['Text'])
#                 emotion_results = MetricEmotion(scene_uid=scene_model.scene_uid,
#                                 dialogue_id=dialogue_number,
#                                 emotions=json.dumps(result),
#                                 created_by=user_uid,
#                                 modified_by=user_uid)
#                 emotion_results.save()
