from batch.apps import MainConfig
from ..Models.MetricPlotSummary import MetricPlotSummary
from .basefeature import BaseFeature
import json


class PlotSummary():
    def __init__(self, *args):
        # super().__init__(*args)
        self.total_action_scenes_txt, self.screenplay_uid, self.user_uid, *_ = args
        self.summarizer_model = MainConfig.summarizer_model

    def summarize(self):
        self.total_action_scenes_txt = self.total_action_scenes_txt.replace('\n', ' ')
        #print(self.total_action_scenes_txt, 'plot summary', len(self.total_action_scenes_txt))
        plot = self.summarizer_model(self.total_action_scenes_txt, max_length=512)
        
        self.results = MetricPlotSummary(screenplay_uid=self.screenplay_uid,
                        plot_summary=json.dumps(plot),
                        created_by=self.user_uid,
                        modified_by=self.user_uid)

        self.results.save()

