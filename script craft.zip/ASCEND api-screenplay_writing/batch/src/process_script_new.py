# -*- coding: utf-8 -*-
"""
Created on Thu Oct  6 18:53:28 2022

@author: Pranay
"""

import fitz

from io import StringIO
from wordcloud import WordCloud, STOPWORDS
import re
import os
import pandas as pd
import json
from scripts.enums import SceneAttribute


class Processor:

    def __init__(self, fp):
        
        self.fp = fp

        STOPWORDS.update({'INT','EXT','INT.','INT ','EXT.','EXT ','CONT','CONT D','CONT’D','INT\n','CONT\'D'})
        self.stopwords = set(STOPWORDS)
    
    
    def extract_blocks(self):
        
        self.doc = fitz.open(stream=self.fp, filetype="pdf")
        
        pg_n = 0
        st = 0
        self.script_df = pd.DataFrame(columns=['x0','y0','x1','y1','text','bl_no','type','page_no'])
        for page in self.doc:
            
            page_df = pd.DataFrame(page.get_text('blocks',sort=True),columns=['x0','y0','x1','y1','text','bl_no','type'])
            page_df['page_no']=[pg_n]*len(page_df)
            #print(page_df)
            #self.script_df=self.script_df.append(page_df,ignore_index=True)
            self.script_df = pd.concat([self.script_df, page_df])
            
            pg_n+=1
            st=len(self.script_df)
         
        self.script_df['empt_or_n'] = self.script_df['text'].apply(lambda x:len(x.strip())) 
        self.script_df = self.script_df[self.script_df['empt_or_n']!=0].reset_index()
        #return self.script_df
    
    def check_img(self):
        
        if 1 in set(self.script_df['type']):
            return 1
        else:
            return 0
    
    def double_check(self, x):
        first_word = x.split(' ')[0]
        alph_only = ''.join([m for m in first_word if m.isalpha()])
        if alph_only=='INT' or alph_only=='EXT' or alph_only=='INTEXT' or alph_only=='EXTINT':
            return True
        else:
            return False
    
    def clean_scene_header(self, text):
        split_text = text.replace("\n", " ").strip().split(' ')
        if len(set(split_text[-2:]))==1:
            return ' '.join(split_text[:-2])+'\n'
        else:
            return ' '.join(split_text)+'\n'
        
        
    def split_scenes(self):
        
        p = re.compile('^INT\.|^EXT\.|\nINT\.|\nEXT\.|^SC-|\nSC-')
        self.script_df['scene_splitter']=self.script_df['text'].apply(lambda x:bool(p.match(x.strip())))  
        
        scene_no=[0]*len(self.script_df)
        indices = list(self.script_df[self.script_df['scene_splitter']==True].index)
        if len(indices)==0:
            self.script_df['scene_splitter']=self.script_df['text'].apply(lambda x:self.double_check(x))
            indices = list(self.script_df[self.script_df['scene_splitter']==True].index)
        st_sc = 0
        st_ind = 0
        for ind in indices:
            
            #print(ind,st_ind,st_sc)
            scene_no[st_ind:ind] = [st_sc]*(ind-st_ind)
            st_sc+=1
            st_ind=ind
        
        scene_no[st_ind:] = [st_sc]*(len(scene_no)-st_ind)
        
        self.script_df['scene_no']=scene_no
    
    def split_dial_desc_char(self):
        
        sc_head_st_list = list(self.script_df[self.script_df['scene_splitter']==True]['x0'])
        sc_head_st = max(set(sc_head_st_list), key=sc_head_st_list.count)
        
        sc_header_lst = self.script_df[(self.script_df['scene_splitter']==True) & (self.script_df['x0']==sc_head_st)].iloc[0]['text'].split('\n')
        temp_lst = [x for x in sc_header_lst if x!='']
        sc_header_len = len(temp_lst)
        ignore = []
        
        if sc_header_len>1:
            indices = list(self.script_df[self.script_df['x0']==sc_head_st].index)
            
            prev_header_end = ''
            for i in indices:
                txt = self.script_df.loc[i]['text']
                cur_header_end = ' '.join([x for x in txt.split('\n') if x!=''][1:])
                if prev_header_end == cur_header_end:
                    ignore.append(i)
                else:
                    prev_header_end = cur_header_end
                    
            self.script_df['text'] = self.script_df.apply(lambda x:self.clean_scene_header(x.text) if x.x0==sc_head_st else x.text,axis=1)
        #sc_head_st = self.script_df[self.script_df['scene_splitter']==True]['x0'].max()
        
        if len(self.script_df[(self.script_df['x0']>=sc_head_st-1) & (self.script_df['x0']<=sc_head_st+1)])-len(ignore) < 2*len(self.script_df[self.script_df['scene_splitter']==True]):
            
            counts = list(self.script_df[self.script_df['x0']>=sc_head_st]['x0'].value_counts().keys())
            idx = counts.index(sc_head_st)
            desc_st = min(counts[:idx])
        else:
            desc_st = sc_head_st
        descs_ = self.script_df[(self.script_df['x0']>=desc_st) & (self.script_df['x0']<=desc_st+1)]
        desc_end = desc_st + int(descs_['x1'].max())
        self.script_df['desc']=self.script_df['x0'].apply(lambda x:1 if (x>=desc_st-1 and x<=desc_st+1) or (x>=sc_head_st-1 and x<=sc_head_st+1) else 0)
        self.script_df['dial']=self.script_df['x0'].apply(lambda x:1 if x>desc_st and x<desc_end else 0)
        
        top_2_ = list(self.script_df[self.script_df['dial']==1]['x0'].value_counts().keys()[:2])
        char_st = max(top_2_)
        dial_st = min(top_2_)
        
        self.script_df['char_name']=self.script_df['x0'].apply(lambda x:1 if x==char_st else 0)
        
        return self.script_df
