# -*- coding: utf-8 -*-
"""
Created on Fri Oct 21 15:01:16 2022

@author: Pranay
"""

from .process_script_new import Processor as Processor2
from scripts.enums import DayTime, NightTime, SystemUsers, SceneAttribute, Level, AIModels, ScreenplayStatus,SceneType, ContTime
from itertools import chain
import re, json
from scripts.messages import Messages
from rest_framework.response import Response

def parse_PDF(fp):
    
    script_processor = Processor2(fp)
    script_processor.extract_blocks()
            
    if script_processor.check_img()==1:
        message, status = Messages.BA00.value
        #rsp_msg = { 'status':message }
        return Response(message, status)
    
    script_processor.split_scenes()
    full_script_df = script_processor.split_dial_desc_char()
    
    return full_script_df

def get_title(full_script_df):
    return ''.join(full_script_df['text'][0])

def get_scenes_count(full_script_df):
    return full_script_df['scene_no'].max()

def get_scene_text_ordered(full_script_df, scene_no):
    scene_df = full_script_df[full_script_df['scene_no']==scene_no]
    dial_text = ''
    scene_text_ordered = []
    for j in scene_df.iterrows():
        row = j[1]
        #print(row['text'],print(scene_text_ordered))
        #input()
        
        if row['desc']==1:
            if dial_text!='':
                scene_text_ordered.append({'Text':dial_text,'Type':SceneAttribute.Dialogue.name})
                dial_text=''
                #count_dialogues+=1
            scene_text_ordered.append({'Text':row['text'],'Type':SceneAttribute.Action.name})
            #count_action+=1
        else:
            if row['dial']==1:
                if row['char_name']==1:
                    if row['text'][-1]=='\n':
                        dial_text+=row['text']
                    else:
                        dial_text+=row['text']+'\n'
                else:
                    scene_text_ordered.append({'Text':dial_text+row['text'],'Type':SceneAttribute.Dialogue.name})
                    dial_text=''
                    #count_dialogues+=1
    
    if dial_text!='':
        scene_text_ordered.append({'Text':dial_text,'Type':SceneAttribute.Dialogue.name})
        dial_text=''
        #count_dialogues+=1
        
    
    #print('1')
    scene_text_ordered = json.dumps(scene_text_ordered)

    return scene_text_ordered

def get_scenetype_uid(full_script_df, scene_no):
    scene_df = full_script_df[full_script_df['scene_no']==scene_no]
    
    if scene_no!=0:
        scene_header = list(scene_df[scene_df['scene_splitter']==True]['text'])[0]
    else:
        scene_header = 'Preface'
        
    if 'INT./EXT.' in scene_header or 'EXT./INT.' in scene_header:
        scenetype_uid = SceneType.Both.value
    elif 'INT.' in scene_header:
        scenetype_uid = SceneType.Interior.value
    elif 'EXT.' in scene_header:
        scenetype_uid = SceneType.Exterior.value
    else:
        scenetype_uid = SceneType.Preface.value 
    return scenetype_uid

def get_tod(full_script_df, scene_no, prev_tod):
    scene_df = full_script_df[full_script_df['scene_no']==scene_no]
    
    if scene_no!=0:
        scene_header = list(scene_df[scene_df['scene_splitter']==True]['text'])[0]
    else:
        scene_header = 'Preface'
    frst_line = scene_header.upper()
    tod = None
    for entry in chain(list(DayTime), list(NightTime), list(ContTime)):
        if entry.name in frst_line:
            tod = entry.name
            break
    if tod == 'LATER' or tod == 'CONTINUOUS':
        tod = prev_tod
    else:
        prev_tod = tod
    
    return tod, prev_tod
    

def get_loc(full_script_df, scene_no, scenetype_uid):
    
    scene_df = full_script_df[full_script_df['scene_no']==scene_no]
    
    if scene_no!=0:
        scene_header = list(scene_df[scene_df['scene_splitter']==True]['text'])[0]
    else:
        scene_header = 'Preface'
    frst_line = scene_header.upper()
    
    if scenetype_uid != 3:
        split_line = re.split('^INT. |^EXT. |\nINT. |\nEXT. |INT./EXT. |EXT./INT. | INT.| EXT.',frst_line)
        loc = re.split('-',split_line[-1])[0]
    else:
        loc = None
        
    return loc