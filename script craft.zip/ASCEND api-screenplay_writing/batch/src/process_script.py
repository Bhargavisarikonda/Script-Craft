from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.converter import TextConverter, HTMLConverter
from pdfminer.layout import LAParams
from pdfminer.pdfpage import PDFPage
from io import StringIO,BytesIO
from bs4 import BeautifulSoup
from wordcloud import WordCloud, STOPWORDS
import matplotlib.pyplot as plt
import re
import os
import pandas as pd
import json
from scripts.enums import SceneAttribute


class Processor:

    def __init__(self, fp):
        self.rsrcmgr = PDFResourceManager()
        self.retstr = StringIO()
        self.codec = 'utf-8'
        self.laparams = LAParams(char_margin=2.0, line_margin=1, word_margin=0.1, all_texts=False)
        self.device = HTMLConverter(self.rsrcmgr, self.retstr, scale=1,
                                   layoutmode='normal', laparams=self.laparams,
                                   imagewriter=None)
        self.interpreter = PDFPageInterpreter(self.rsrcmgr, self.device)

        self.password = ""
        self.maxpages = 0
        self.caching = True
        self.pagenos=set()
        self.fp = fp

        STOPWORDS.update({'INT','EXT','INT.','INT ','EXT.','EXT ','CONT','CONT D','CONT’D','INT\n','CONT\'D'})
        self.stopwords = set(STOPWORDS)

    def get_pdfHTML(self):

        for page in PDFPage.get_pages(self.fp, self.pagenos, maxpages=self.maxpages, password=self.password,caching=self.caching,
                                      check_extractable=True):
            self.interpreter.process_page(page)

        text = self.retstr.getvalue()
        soup = BeautifulSoup(text, 'html.parser')
        return soup

    def convert(self,string):
        if string:
            return int(''.join([dig for dig in string if dig.isdigit()]))

    def split_scenes_helper(self,soup):
        self.full_dict = {}
        self.serial_dict = {}
        self.divs = soup.find_all('div')
        self.right_max = -1
        self.increment=0.1
        p = re.compile('^INT\.|^EXT\.|\nINT\.|\nEXT\.')
        for idx,x in enumerate(self.divs):
            dic={}
            for m in x['style'].split('; '):
                split = m.split(':')
                dic[split[0]]=split[1]
            self.full_dict[idx]=dic
            if self.serial_dict.get(self.convert(dic['top'])):
                self.serial_dict[self.convert(dic['top'])+self.increment]=idx
                self.increment+=0.1
            else:
                self.serial_dict[self.convert(dic['top'])]=idx
            #self.serial_dict[self.convert(dic['top'])]=idx
            matches_list = [oo for oo in p.finditer(x.text)]
            if len(matches_list)>0:
                self.left_min = self.convert(dic.get('left'))
                #print(left_min,dic)
            if dic.get('left') and self.convert(dic.get('left'))>self.right_max:
                self.right_max = self.convert(dic.get('left'))


    def split_scenes_dial_desc(self):
        self.scenes=[]
        self.scenes_ordered=[]
        self.prev_min=0
        self.dialogues = [] #(scene number, div idx, )
        self.description = [] #(scene number, div idx)
        p = re.compile('^INT\.|^EXT\.|\nINT\.|\nEXT\.')
        scene_text = ''
        scene_text_ordered = []
        for key in sorted(self.serial_dict):
            txt = self.divs[self.serial_dict[key]].text
            style = self.full_dict[self.serial_dict[key]]
            left = self.convert(style.get('left'))
            width = self.convert(style.get('width'))
            height = self.convert(style.get('height'))
            if left:

                matches_list = [oo for oo in p.finditer(txt)]
                if len(matches_list)>0:
                    st=0
                    for m in matches_list:
                        scene_text += txt[st:m.start()]
                        if txt[st:m.start()]!='':
                            scene_text_ordered.append({'Text':txt[st:m.start()],'Type':SceneAttribute.Action.name})
                        #print(m.start(),scene_text)
                        self.scenes.append(scene_text)
                        self.scenes_ordered.append(json.dumps(scene_text_ordered))
                        self.description.append((len(self.scenes),self.serial_dict[key], left))
                        st=m.start()
                        #print('-----')
                        #print(scene_text)
                        scene_text=''
                        scene_text_ordered=[]
                    if txt[st:]:
                        scene_text += txt[st:]
                        scene_text_ordered.append({'Text':txt[st:],'Type':SceneAttribute.Action.name})
                    #scenes.append(scene_text)
                    #scene_text=''
                else:
                    if txt!='':
                        scene_text += txt
                        #print(txt)
                        if left>self.left_min and left<self.right_max:

                            if self.prev_min-5>left:
                                prev_text = scene_text_ordered[-1]['Text']
                                scene_text_ordered[-1]={'Text':prev_text+txt,'Type':SceneAttribute.Dialogue.name}
                            else:
                                scene_text_ordered.append({'Text':txt,'Type':SceneAttribute.Dialogue.name})
                            self.dialogues.append((len(self.scenes), self.serial_dict[key], left))
                        else:
                            scene_text_ordered.append({'Text':txt,'Type':SceneAttribute.Action.name})
                            self.description.append((len(self.scenes),self.serial_dict[key], left))
                self.prev_min=left
        self.scenes.append(scene_text)
        self.scenes_ordered.append(json.dumps(scene_text_ordered))

    def sep_sceneDescription(self):
        self.scene_description={}
        for x in self.description:
            if self.scene_description.get(x[0]):
                self.scene_description[x[0]]+=self.divs[x[1]].text
            else:
                self.scene_description[x[0]]=self.divs[x[1]].text

    def sep_sceneDialogue(self):
        self.scene_dialogue={}
        for x in self.dialogues:
            if self.scene_dialogue.get(x[0]):
                self.scene_dialogue[x[0]]+=self.divs[x[1]].text
            else:
                self.scene_dialogue[x[0]]=self.divs[x[1]].text


