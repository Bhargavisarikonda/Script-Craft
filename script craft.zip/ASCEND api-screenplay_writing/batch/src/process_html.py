# -*- coding: utf-8 -*-
"""
Created on Fri Oct 21 13:00:40 2022

@author: Pranay
"""
from .process_script import Processor as Processor1
from scripts.enums import DayTime, NightTime, SystemUsers, SceneAttribute, Level, AIModels, ScreenplayStatus,SceneType, ContTime
from itertools import chain
import re

def parse_PDF(fp):
    
    script_processor = Processor1(fp)
    soup = script_processor.get_pdfHTML()
    script_processor.split_scenes_helper(soup)
    script_processor.split_scenes_dial_desc()
    script_processor.sep_sceneDescription()
    script_processor.sep_sceneDialogue()
    
    if len(script_processor.scenes)<=1 and script_processor.scenes[0]=='':
        raise Exception("failed processing - check PDF")
        
    return script_processor

def get_title(script_processor):
    return [x for x in script_processor.scenes[0].split('\n') if x!=''][0]

def get_scenes_count(script_processor):
    return len(script_processor.scenes)-1

def get_scene_text_ordered(script_processor, scene_no):
    return script_processor.scenes_ordered[scene_no]

def get_scenetype_uid(script_processor, scene_no):
    check_string = script_processor.scenes[scene_no]
    if 'INT./EXT.' in check_string or 'EXT./INT.' in check_string:
        scenetype_uid = SceneType.Both.value
    elif 'INT.' in check_string:
        scenetype_uid = SceneType.Interior.value
    elif 'EXT.' in check_string:
        scenetype_uid = SceneType.Exterior.value
    else:
        scenetype_uid = SceneType.Preface.value
        
    return scenetype_uid

def get_tod(script_processor, scene_no, prev_tod):
    scene_text = script_processor.scenes[scene_no]
    frst_line = [st for st in scene_text.split('\n') if st!=''][0].upper()
    tod = None
    for entry in chain(list(DayTime), list(NightTime), list(ContTime)):
        if entry.name in frst_line:
            tod = entry.name
            break
    if tod == 'LATER' or tod == 'CONTINUOUS':
        tod = prev_tod
    else:
        prev_tod = tod
        
    return tod, prev_tod

def get_loc(script_processor, scene_no, scenetype_uid):
    scene_text = script_processor.scenes[scene_no]
    frst_line = [st for st in scene_text.split('\n') if st!=''][0].upper()
    if scenetype_uid != 3:
        split_line = re.split('^INT. |^EXT. |\nINT. |\nEXT. |INT./EXT. |EXT./INT. ',frst_line)
        loc = re.split('-',split_line[-1])[0]
    else:
        loc = None
        
    return loc