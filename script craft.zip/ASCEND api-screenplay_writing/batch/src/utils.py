import json
from batch.apps import MainConfig
import re
import spacy
from typing import OrderedDict
from enum import Enum
from scripts.constants import Constants
import nltk
from nltk.tokenize import word_tokenize
import requests

# from genderize import Genderize
from gender import GenderDetector as gd
import gender_guesser.detector as gender

from scripts.enums import SceneAttribute
import logging 


logger = logging.getLogger("scripts_logger")

# tokenizer = MainConfig.nlpDriver.tokenizer
tokenizer = spacy.load("en_core_web_trf")
genderDet = gender.Detector()

# def ner(scene_text_list):
#     # load sceneattribute into an screenattribute array
#     for scene_text in scene_text_list:
#         # parse scene_text to separate action and dialogue
#         # if action:
#         #    action_characters = get_action_characters(action_text)
#         #   action_characters = [{"name":"John"}, {"name": "Mary"}, {}..]
#         # if dialogue:
#         #    dialogue_characters = get_dialogue_character(dialogue_text)
#         #   dialogue_characters = [{"name": "John", "count_dialogues": 3, "count_words_dialogues": 25}, {}..]
#         # using screenattribute array, get sceneattribute_uid
#         persist_scene_characters(dialogue_characters, scene_uid, sceneattribute_uid)

# def persist_scene_characters(dialogue_characters, scene_uid, sceneattribute_uid):
#     for actor in dialogue_characters:
#         gender = get_gender(actor['name'])
#         insert(...)

# def get_dialogue_character(dialogue_text):
#     # get first row
#     pass

# def get_action_characters(action_text):
#     # ner model
#     pass


def get_gender(name):
    if name == Constants.Unknown:
        return Constants.Unknown

    try:
        if len(name.split(" ")) == 1:
            name = name + " " + "none"
        # g1 = Genderize().get([name.split(' ')[0]])
        #print("name ", name)
        g2 = gd().get_gender(name)
        # return g1[0]['gender'].title()
        return "Male" if g2[4].upper() == "M" else "Female"
    except:
        g = genderDet.get_gender(name.split(" ")[0])
        return g.title()


def get_wordCounts(scene_text):
    # scene,descr,dial
    action_word_count, dialogue_word_count = 0, 0
    action_count, dialogue_count = 0, 0
    # for sc_no in range(len(self.scenes)):
    for entry in json.loads(scene_text):
        if entry["Type"] == SceneAttribute.Action.name:
            only_action = entry["Text"].split("\n")[1:]
            cleaned_text = clean_text("\n".join(only_action))
            # print('action cleaned text ', cleaned_text)
            action_word_count += len(cleaned_text.split(" "))

            action_count += 1

        if entry["Type"] == SceneAttribute.Dialogue.name:
            only_dialogue = entry["Text"].split("\n")[1:]
            cleaned_text = clean_text("\n".join(only_dialogue))
            # print("cleaned text ", cleaned_text)
            dialogue_word_count += len(cleaned_text.split(" "))
            dialogue_count += 1

    # print('counts ', action_word_count, dialogue_word_count , scene_text)
    return action_word_count, dialogue_word_count, action_count, dialogue_count

# remove words that are fully special chars
def filter_special_chars(word_tokens):
    filtered_sentence = []
    for word in word_tokens:
        found = Constants.SPECIAL_CHARS.search(word)
        if found == None:
            filtered_sentence.append(word)
        elif found.span()[0] > 0:
            filtered_sentence.append(word)
        else:
            for letter in word:
                if Constants.SPECIAL_CHARS.search(letter) == None:
                    filtered_sentence.append(word)
                    break
                
    return filtered_sentence  


# Remove numbers and special chars
def clean_text(txt):
    wo_numbers_text = remove_number(txt)

    if Constants.DIALOGUE_CLEANUP_LIB == "spacy":
        spacy_word_tokens = tokenizer(wo_numbers_text)
        word_tokens = [token.text for token in spacy_word_tokens]
    elif Constants.DIALOGUE_CLEANUP_LIB == "nltk":
        word_tokens = word_tokenize(wo_numbers_text)

    filtered_sentence = filter_special_chars(word_tokens)
    #[
    #    w for w in word_tokens if Constants.SPECIAL_CHARS.search(w) == None
    #]

    return " ".join(filtered_sentence)


def remove_number(txt):
    return re.sub(r"[0-9]", "", txt)


def remove_special_chars(txt):
    # print(txt)
    for filler in Constants.PAGE_FILLERS:
        filler_pos = txt.find(filler)
        if filler_pos > -1:
            txt = txt.replace(filler, '')
            #return ''

    if Constants.DIALOGUE_CLEANUP_LIB == "spacy":
        spacy_word_tokens = tokenizer(txt)
        word_tokens = [token.text for token in spacy_word_tokens]
    elif Constants.DIALOGUE_CLEANUP_LIB == "nltk":
        word_tokens = word_tokenize(txt)

    # print('nltk word tokens ', word_tokens)

    # print('spacy word tokens ', word_tokens)
    # filtered_sentence = [w for w in word_tokens if not w.lower().strip() in Constants.SPECIAL_CHARS]

    # Remove special chars
    filtered_sentence = filter_special_chars(word_tokens)
    #[
    #    w for w in word_tokens if Constants.SPECIAL_CHARS.search(w) == None
    #]
    # print('filtered_sentence ', filtered_sentence)
    if not filtered_sentence:
        return ""
    string_it = " ".join(filtered_sentence)
    wo_number_text = remove_number(string_it)
    # if removing number empties the text, then it means a page-number line
    if wo_number_text == "":
        return wo_number_text
    # else, return the text with number, since number may be significant, so retain it
    else:
        return txt


def is_firstline_correct(txt):
    start_bracket = txt.find("(")
    if start_bracket > -1:
        end_bracket = txt.find(")")
        if end_bracket > start_bracket:
            before = txt[0:start_bracket]
            after = txt[end_bracket + 1 :]
            txt = before + after

    if Constants.DIALOGUE_CLEANUP_LIB_2 == "spacy":
        # print('SPACY')
        spacy_word_tokens = tokenizer(txt)
        word_tokens = [token.text for token in spacy_word_tokens]
        doc = MainConfig.nlpDriver(txt)
        # ans returns a list of tuple
        ans = [(token.text, token.tag_) for token in doc]
    elif Constants.DIALOGUE_CLEANUP_LIB_2 == "nltk":
        # print('NLTK')
        word_tokens = word_tokenize(txt)
        ans = nltk.pos_tag(word_tokens)
    # print('word tokens ', word_tokens)

    if not word_tokens:
        return False

    # string_list = [tup[0] for tup in ans]

    # Assumption is that first line in dialogue would be one word - name, and anything else would be a V.O.
    # If there is more than one word and the extra word is not V.O then it is not the correct first line of dialogue
    # if len(ans) > 1:
    #    for vo in NAME_SUFFIXES:
    #        if vo in string_list:
    #            vo_found = True
    #            break
    #    if  not vo_found:
    #        return False

    its_a_name = True
    for (strng, val) in ans:
        if val == "NN" or val == "NNS" or val == "NNPS" or val == "NNP"or val == '$':
            continue
        vo_found = False
        for vo in Constants.NAME_SUFFIXES:
            if vo.lower() == strng.lower():
                vo_found = True
                break
        if vo_found:
            continue
        # If a character name is 'AGENT 1', then AGENT is noun, but 1 is not. But ignore this point to determine that it's a person
        try:
            if isinstance(int(strng), int):
                continue
        except ValueError:
            pass
        its_a_name = False
        break

    # Get pos of first string, and check if it is a noun
    # val = ans[0][1]
    # if(val == 'NN' or val == 'NNS' or val == 'NNPS' or val == 'NNP'):
    #    return True
    if its_a_name:
        return True
    return False


def check_for_multiple_dialogues(txt, cache):
    temp_cache = OrderedDict()
    ind = -1
    for line in txt.split("\n"):
        if line == "":
            continue
        if is_firstline_correct(line):
            ind += 1
        if ind in temp_cache:
            temp_cache[ind].append(line)
        else:
            temp_cache[ind] = [line]
    for key, val_list in temp_cache.items():
        # print('line ', key, val_list )
        cache.append("\n".join(val_list) + "\n")

    return cache


def cache_dialogue(txt, cache):
    list_of_lines = txt.split("\n")
    first_line = list_of_lines[0]
    # print('first_line ' , first_line)
    prev_index = len(cache) - 1
    if prev_index < 0:
        prev_index = 0

    # A text line such as '(into his headset)' comes immediately below character name. Check for that
    strip_txt = first_line.strip()
    # This happens when title of script is classified as Dialogue. So, first line can be empty
    if strip_txt == "":
        if cache:
            cache[prev_index] = cache[prev_index] + txt
        else:
            cache.append(txt)
        return cache

    # print('prev_index ', prev_index)
    # print ('cache ', cache, txt)
    if strip_txt[0] == "(" and strip_txt[-1] == ")":
        try:
            cache[prev_index] = cache[prev_index] + txt
        except:
            # Orphan dialogue because the start of dialogue is classified as Action. So, handle this orphan dialoue as unknown,
            # or else below logic fill fail with index out of range error
            cache.append(Constants.Unknown + "\n")
            cache[prev_index] = cache[prev_index] + txt
    elif is_firstline_correct(first_line):
        cache = check_for_multiple_dialogues(txt, cache)
        # cache[prev_ind] = txt
    else:
        try:
            cache[prev_index] = cache[prev_index] + txt
        except:
            # Sometimes character name gets included in previous Action. It's very complex to extract that, so assign
            # an unknown character for such dialogues, or else below logic fill fail with index out of range error
            cache.append(Constants.Unknown + "\n")
            cache[prev_index] = cache[prev_index] + txt

    # print('cache after ', cache)
    return cache


def clean_actor_name(actor_list):
    actor2_list = []
    for actor in actor_list:
        actor = actor.lower()
        # Remove 's suffix from name
        for suffix in Constants.SUFFIXES:
            if actor.find(suffix) > -1:
                actor = actor.replace(suffix, "")
                break
        # Replace ’ by ' for consistency
        if actor.find("’") > -1:
            actor = actor.replace("’", "'")
        actor2_list.append(actor.title())
    return actor2_list


def cleanup_action(scene_text):
    prev_type, prev_text = "", ""
    scene_list = []
    concat_action = ""
    for entry in json.loads(scene_text):
        curr_type = entry["Type"]
        curr_text = entry["Text"]
        if curr_type == SceneAttribute.Dialogue.name:
            # first entry in list is a dialogue
            if prev_text == "":
                pass
            else:
                # write action text only if it has not been written previously, in case of successive dialogues
                if len(concat_action) > 0:
                    scene_list.append(
                        {"Text": concat_action, "Type": SceneAttribute.Action.name}
                    )
                    concat_action = ""
            scene_list.append(entry)
            prev_type = curr_type
            continue
        # consecutive actions, so concatenate them, but first check whether action is a number (page#)
        if curr_type == prev_type:
            clean_text = curr_text.replace("\n", "").replace(".", "")
            try:
                # page#, so ignore
                if isinstance(int(clean_text), int):
                    pass
            except:
                # valid text
                concat_action += curr_text
        else:
            concat_action = curr_text
        prev_text = curr_text
        prev_type = curr_type

    # Last entry was an action, which will not get added to scene_list in FOR loop
    if prev_type == SceneAttribute.Action.name:
        scene_list.append({"Text": concat_action, "Type": SceneAttribute.Action.name})

    return json.dumps(scene_list)


def cleanup_dialogue(scene_text):
    # print(scene)
    clean_scene_list = []
    prev_ready_to_write = False
    prev_type = ""
    cache = []
    cache_empty = True
    # one row of scene table
    for entry in json.loads(scene_text):

        # New type is action and prev was dialgoue, so set flag so that prev dialogue is saved down the line
        if (
            prev_type == SceneAttribute.Dialogue.name
            and entry["Type"] == SceneAttribute.Action.name
        ):
            prev_ready_to_write = True

        # If condition says that prev dialogue has been constructed and so save it
        if prev_ready_to_write and not cache_empty:
            for row in cache:
                clean_scene_list.append(
                    {"Text": row, "Type": SceneAttribute.Dialogue.name}
                )
            cache = []
            cache_empty = True
            prev_ready_to_write = False

        # print('entry ', entry)
        prev_type = entry["Type"]

        # Ignore action type
        if entry["Type"] == SceneAttribute.Action.name:
            clean_scene_list.append(entry)
            prev_ready_to_write = False
            continue

        # print('original entry ', entry['Text'])
        # remove special chars, numbers etc. After removing these if text is empty, then exclude it
        clean_txt = remove_special_chars(entry["Text"])
        if clean_txt == "":
            # print('clean_txt ', clean_txt, "\n")
            # cache_empty = True
            continue

        # Below function is the intelligence where dialgoues are constructed properly based on rules
        # print('clean_txt ', clean_txt, "\n")
        cache = cache_dialogue(clean_txt, cache)
        cache_empty = False

    # last type was dialogue, and we haven't saved it yet, so save it
    if prev_type == SceneAttribute.Dialogue.name and not cache_empty:
        for row in cache:
            clean_scene_list.append({"Text": row, "Type": SceneAttribute.Dialogue.name})
        # clean_scene_list.append({"Text":cache, "Type":SceneAttribute.Dialogue.name})
        prev_ready_to_write = False

    # assert_func(clean_scene_list)

    return json.dumps(clean_scene_list)



# Get ip address from geo location
def get_ip_address(geo_location):
    # geo_location can come in dict format or list format --> {} or [{}]
    if isinstance(geo_location, list):
        return geo_location[0]['ip']
    elif isinstance(geo_location, dict):
        return geo_location['ip']
    else:
        return ""

def process_geo(geo_location):
    if isinstance(geo_location, list):
        # UI is not able to fetch geo details, it will send ["", Null]; call another geo api
        if geo_location[0] == "":
            '''
            r = requests.get(Constants.geo_api2)
            geo_location = json.loads(r.content)
            #print('r ', geo_location)
            ip_address = geo_location["IPv4"]
            return geo_location, ip_address
            '''
            return "", ""

    # UI will send geo as string, dict or list. If it's string then convert to dict
    # When UI saves geo in recoil and sends from there, it's a list. When UI calls geo api and sends that data, it is dict.
    # When UI sends without geo data, it'll be ["", Null]. From signup, UI sends geo as string (of json).
    if isinstance(geo_location, str):
        geo_location = json.loads(geo_location)

    try:
        ip_address = get_ip_address(geo_location)
    except Exception as e:
        logger.error("Geo details structure is incorrect: ", e)
        geo_location, ip_address = "", ""


    return geo_location, ip_address