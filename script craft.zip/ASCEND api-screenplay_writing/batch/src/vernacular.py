import json
from batch.apps import MainConfig
import re
import spacy
from typing import OrderedDict
from enum import Enum
from scripts.constants import Constants

from scripts.enums import SceneAttribute, Languages


def is_vernacular(language):
    if language.title() == Languages.English.name:
        return False
    
    return True


