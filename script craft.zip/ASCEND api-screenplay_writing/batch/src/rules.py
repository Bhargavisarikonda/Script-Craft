from abc import ABC, abstractmethod

class Rules():
    def __init__(self, num):
        self.num = num
        #print(f'Rule %s initialized' %self.num)

    @classmethod
    @abstractmethod
    def action(cls):
        pass

    
class Rule1(Rules):
    def __init__(self):
        super().__init__(1)

    @classmethod
    def action(cls):
        pass
        #print('Rule 1 executed')

class Rule2(Rules):
    def __init__(self):
        super().__init__(2)

    @classmethod
    def action(cls):
        pass
        #print('Rule 2 executed')

class Rule3(Rules):
    def __init__(self):
        super().__init__(3)

    @classmethod
    def action(cls):
        pass
        #print('Rule 3 executed')