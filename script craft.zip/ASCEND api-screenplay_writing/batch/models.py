# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models
from django.contrib.auth.models import User
import datetime

class Address(models.Model):
    address_uid = models.BigAutoField(primary_key=True)
    line_1 = models.TextField()
    line_2 = models.TextField(blank=True, null=True)
    line_3 = models.TextField(blank=True, null=True)
    city = models.TextField()
    state = models.TextField()
    country = models.TextField()
    zipcode = models.TextField()

    class Meta:
        managed = False
        db_table = 'address'


class BaselineScreenplay(models.Model):
    baseline_screenplay_uid = models.AutoField(primary_key=True)
    title = models.TextField()
    created_on = models.DateTimeField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    created_by = models.IntegerField(blank=True, null=True)
    modified_by = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'baseline_screenplay'


class Subscription(models.Model):
    subscription_uid = models.BigAutoField(primary_key=True)
    name = models.TextField()
    price = models.FloatField()
    paid = models.BooleanField()
    currency = models.TextField()

    class Meta:
        managed = False
        db_table = 'subscription'

class Tenant(models.Model):
    tenant_uid = models.BigAutoField(primary_key=True)
    created_on = models.DateTimeField(auto_now_add=True)
    created_by = models.TextField()

    class Meta:
        managed = False
        db_table = 'tenant'

class Client(models.Model):
    client_uid = models.BigAutoField(primary_key=True)
    client_name = models.TextField()
    address_uid = models.ForeignKey(Address, on_delete=models.RESTRICT, to_field='address_uid', db_column='address_uid' )
    batch_size = models.SmallIntegerField()
    weblink = models.TextField()
    phone_number = models.BigIntegerField()
    country_code = models.SmallIntegerField()
    fax = models.TextField()

    class Meta:
        managed = False
        db_table = 'client'


class ClientUser(models.Model):
    client_user_uid = models.BigAutoField(primary_key=True)
    id = models.ForeignKey(User, on_delete=models.RESTRICT, to_field='id', db_column='id')
    client_uid = models.ForeignKey(Client, on_delete=models.RESTRICT, to_field='client_uid', db_column='client_uid')
    subscription_uid = models.ForeignKey(Subscription, on_delete=models.RESTRICT, to_field='subscription_uid', db_column='subscription_uid')
    payment_pending = models.BooleanField()
    tenant_uid = models.ForeignKey(Tenant, on_delete=models.RESTRICT, to_field='tenant_uid', db_column='tenant_uid')

    class Meta:
        managed = False
        db_table = 'client_user'
# Unable to inspect table 'emotion_meta'
# The error was: permission denied for table emotion_meta


class FeatureMeta(models.Model):
    feature_uid = models.BigAutoField(primary_key=True)
    feature_name = models.TextField()
    class_name = models.TextField()
    method_name = models.TextField()
    active = models.BooleanField()
    subscription_uid = models.ForeignKey(Subscription, on_delete=models.RESTRICT, to_field='subscription_uid', db_column='subscription_uid')
    level_uid = models.SmallIntegerField()
    load_function = models.TextField()

    class Meta:
        managed = False
        db_table = 'feature_meta'


class GenreMeta(models.Model):
    genre_uid = models.SmallAutoField(primary_key=True)
    genre_type = models.TextField()

    class Meta:
        managed = False
        db_table = 'genre_meta'

# Unable to inspect table 'scene_emotion'
# The error was: permission denied for table scene_emotion


class Language(models.Model):
    language_uid = models.SmallAutoField(primary_key=True)
    vernacular = models.BooleanField()
    language = models.TextField()

    class Meta:
        managed = False
        db_table = 'language'


class SceneGenre(models.Model):
    scene_genre_uid = models.BigIntegerField(primary_key=True)
    scene_uid = models.BigIntegerField()
    genre_uid = models.SmallIntegerField()
    probability = models.FloatField()

    class Meta:
        managed = False
        db_table = 'scene_genre'


class ScenetypeMeta(models.Model):
    scenetype_uid = models.BigAutoField(primary_key=True)
    type = models.TextField()

    class Meta:
        managed = False
        db_table = 'scenetype_meta'


class Screenplay(models.Model):
    screenplay_uid = models.BigAutoField(primary_key=True)
    title = models.TextField()
    success_percentage = models.FloatField()
    ip_address = models.TextField()
    geo_location = models.TextField()
    status = models.TextField()
    file_path = models.TextField()
    file_size = models.IntegerField()
    user_uid = models.BigIntegerField()
    created_on = models.DateTimeField(auto_now_add=True)
    modified_on = models.DateTimeField(auto_now_add=True)
    created_by = models.BigIntegerField()
    modified_by = models.BigIntegerField()
    language_uid = models.SmallIntegerField()
    tenant_uid = models.ForeignKey(Tenant, on_delete=models.RESTRICT, to_field='tenant_uid', db_column='tenant_uid')
    process_time = models.BigIntegerField()
    failure_reason = models.TextField()

    class Meta:
        managed = False
        db_table = 'screenplay'

class Scene(models.Model):
    scene_uid = models.BigAutoField(primary_key=True)
    scenetype_uid = models.SmallIntegerField()
    screenplay_uid = models.ForeignKey(Screenplay, on_delete=models.RESTRICT, db_column="screenplay_uid")
    count_action = models.SmallIntegerField()
    count_dialogues = models.SmallIntegerField()
    scene_text = models.TextField()
    scene_number = models.SmallIntegerField()
    count_words_action = models.SmallIntegerField()
    count_words_dialogues = models.SmallIntegerField()
    time_of_day = models.TextField()
    location = models.TextField()
    created_on = models.DateTimeField(auto_now_add=True)
    created_by = models.BigIntegerField() 
    modified_on = models.DateTimeField(auto_now_add=True)
    modified_by = models.BigIntegerField() 

    class Meta:
        managed = False
        db_table = 'scene'

class Characters(models.Model):
    person_uid = models.BigAutoField(primary_key=True)
    name = models.TextField()
    gender = models.TextField()
    type = models.TextField()
    logline = models.TextField()
    screenplay_uid = models.ForeignKey(Screenplay, on_delete=models.RESTRICT, db_column='screenplay_uid')
    created_on = models.DateTimeField(auto_now_add=True)
    created_by = models.TextField()
    modified_on = models.DateTimeField(auto_now_add=True)
    modified_by = models.TextField()

    class Meta:
        managed = False
        db_table = 'characters'


class MetricCharacter(models.Model):
    character_uid = models.BigAutoField(primary_key=True)
    person_uid = models.ForeignKey(Characters, on_delete=models.RESTRICT,db_column='person_uid')
    count_dialogues = models.SmallIntegerField()
    scene_uid = models.ForeignKey(Scene,on_delete=models.RESTRICT,db_column='scene_uid')
    count_words_dialogues = models.SmallIntegerField()
    sceneattribute_uid = models.SmallIntegerField()
    created_on = models.DateTimeField(auto_now_add=True)
    created_by = models.TextField()
    modified_on = models.DateTimeField(auto_now_add=True)
    modified_by = models.TextField()

    class Meta:
        managed = False
        db_table = 'metric_character'

class ScreenplayComparison(models.Model):
    screenplay_comparison_uid = models.BigAutoField(primary_key=True)
    screenplay_uid = models.BigIntegerField()
    baseline_screenplay_uid = models.BigIntegerField()
    similarity = models.FloatField()
    created_on = models.DateTimeField(auto_now_add=True)
    created_by = models.BigIntegerField() 
    modified_on = models.DateTimeField(auto_now_add=True)
    modified_by = models.BigIntegerField() 

    class Meta:
        managed = False
        db_table = 'screenplay_comparison'


class UserList(models.Model):
    user_uid = models.BigAutoField(primary_key=True)
    username = models.TextField()
    first_name = models.TextField()
    last_name = models.TextField()
    email_id = models.TextField()
    country_code = models.SmallIntegerField()
    contact_number = models.BigIntegerField()
    fax_number = models.TextField()
    created_on = models.DateTimeField(auto_now_add=True)
    created_by = models.IntegerField()
    modified_on = models.DateTimeField(auto_now_add=True)
    modified_by = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'userlist'

class ScriptLevel(models.Model):
    level_uid = models.SmallAutoField(primary_key=True)
    level_type = models.TextField()
    description = models.TextField()

    class Meta:
        managed = False
        db_table = 'script_level'

class Profile(models.Model):
    profile_uid = models.BigAutoField(primary_key=True)
    user = models.OneToOneField(User, on_delete=models.RESTRICT, db_column='user_uid')
    avatar = models.TextField()
    modified_on = models.DateTimeField(auto_now_add=True)
    modified_by = models.IntegerField()
    mobile_number = models.BigIntegerField()
    country_code = models.SmallIntegerField()
    oauth = models.BooleanField()
    source = models.TextField()
    external_userid = models.TextField()

    class Meta:
        managed = False
        db_table = 'profile'


class SignupLog(models.Model):
    signup_uid = models.BigAutoField(primary_key=True)
    username = models.TextField()
    email_id = models.TextField()
    first_name =  models.TextField()
    last_name = models.TextField()
    mobile = models.BigIntegerField()
    mobile_code = models.SmallIntegerField()
    type = models.TextField()
    company_name = models.TextField(blank=True)
    weblink = models.TextField(blank=True)
    company_phone_number = models.BigIntegerField(blank=True)
    company_phone_number_code = models.SmallIntegerField(blank=True)
    fax = models.TextField(blank=True)
    line_1 = models.TextField(blank=True)
    line_2 = models.TextField(blank=True)
    city = models.TextField(blank=True)
    state = models.TextField(blank=True)
    country = models.TextField(blank=True)
    zipcode = models.TextField(blank=True)
    ip_address = models.TextField(blank=True)
    geo_location = models.TextField(blank=True)
    created_on = models.DateTimeField(auto_now_add=True)
    created_by = models.TextField(blank=True)
    subscription_uid = models.SmallIntegerField()
    password = models.TextField()

    class Meta:
        managed = False
        db_table = 'signup_log'


class Transliteration(models.Model):
    transliteration_uid = models.SmallAutoField(primary_key=True)
    language_uid = models.ForeignKey(Language, on_delete=models.RESTRICT, to_field='language_uid', db_column='language_uid')
    active = models.BooleanField()
    class_name = models.TextField()
    method_name = models.TextField()
    load_function = models.TextField()

    class Meta:
        managed = False
        db_table = 'transliteration'