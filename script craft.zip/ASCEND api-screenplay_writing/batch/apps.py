from asyncio import constants
from flair.models import SequenceTagger
from django.apps import AppConfig
from transformers import pipeline, AutoTokenizer, AutoModelForSequenceClassification
from scripts.constants import Constants
import os
import spacy
import logging
#from .models import FeatureMeta

logger = logging.getLogger("scripts_logger")

class MainConfig(AppConfig):

    name = 'batch'

    #print('os pid ' , os.getpid())

    @classmethod
    def load_plot_summary(cls):
        # Load plot summary model
        try:
            cls.summarizer_model = pipeline("summarization",model = Constants.SUMMARY_MODEL_PATH)
            
            #print(genre_tokenizer)
            logger.info('-------------')
            logger.info('Successfully loaded the summary model.')
            logger.info('-------------')
        except Exception as e:
            logger.error('-------------')
            logger.error('Could not load the summary model.')
            logger.error('-------------')
            logger.error(e)

    @classmethod
    def load_genre(cls):
        # Load genre model and tokenizer
        try:
            genre_tokenizer = AutoTokenizer.from_pretrained(Constants.GENRE_MODEL_PATH, max_length=50000)
            genre_model = AutoModelForSequenceClassification.from_pretrained(Constants.GENRE_MODEL_PATH)
            cls.genre_classifier = pipeline(model = genre_model,tokenizer=genre_tokenizer, task='text-classification',top_k=-1)
            logger.info('-------------')
            logger.info('Successfully loaded the genre model.')
            logger.info('-------------')
        except Exception as e:
            logger.error('-------------')
            logger.error('Could not load the genre predictor model and tokenizer.')
            logger.error('-------------')
            logger.error(e)

    # load emotion classification AI model
    @classmethod
    def load_emotion(cls):
        # Load emotion classification model
        try:
            # load the model when the server starts to prevent the load time
            cls.emotion_classifier = pipeline("text-classification",model = Constants.EMOTION_MODEL_PATH, return_all_scores=True)
            logger.info('-------------')
            logger.info('Successfully loaded the emotion recognition model.')
            logger.info('-------------')
        except Exception as e:
            logger.error('-------------')
            logger.error('Could not load the emotion recognition model.')
            logger.error('-------------')
            logger.error(e)
                
    # load character ner AI model
    @classmethod
    def load_character_ner(cls):
        # Load NER model for characters
        try:
            # load the model when the server starts to prevent the load time
            cls.character_ner_model = SequenceTagger.load(Constants.CHARACTER_NER_MODEL_PATH)
            logger.info('-------------')
            logger.info('Successfully loaded the character ner model.')
            logger.info('-------------')
        except Exception as e:
            logger.errorint('-------------')
            logger.error('Could not load the character ner model.')
            logger.error('-------------')
            logger.error(e)

    def start(self):
        logger.info('******** READY ********')
        from .models import FeatureMeta

        # load active rules from feature meta
        feature_qset = FeatureMeta.objects.filter(active=True).order_by('feature_uid').values()
        scene_rules_list = [x for x in feature_qset]
        logger.debug(f'scene_rules_list: {scene_rules_list}')

        MainConfig.nlpDriver = spacy.load("en_core_web_trf")

        # load AI models only for active rules
        for rule in feature_qset:
            #statement = "MainConfig." + rule['load_function'] + "." + "__func__()"
            statement = "self." + rule['load_function'] + "()"
            #print('statement ', statement)
            exec(statement)

        return

    def ready(self):

        #print('ready method')
        run_once = os.environ.get('RUN_MAIN')
        #print('run once ', run_once)
        # Django creates two pids during startup. One, to start dev server, other, to reload code changes (hot reload).
        # This causes the AI models to be loaded twice on unix machines, surprisingly not on windows.
        # Below code restricts it to just one-time load        
        if run_once == 'None':
            os.environ['RUN_MAIN'] = 'True'
            #return
        else:
            #os.environ['RUN_MAIN'] = 'true'
            #return
            self.start()


    # run_once = os.environ.get('RUN_MAIN')
    # print('inside run only once' , run_once)
    # if run_once is None:
    #     emotion_classifier = None
    #     character_ner_model = None
    #     genre_classifier = None
    #     genre_tokenizer = None
    #     summarizer_model = None 
    #     print("Final ", emotion_classifier)
    # else:
    #     quit

    
    
    #print('emotion_classifier 2', MainConfig.emotion_classifier)