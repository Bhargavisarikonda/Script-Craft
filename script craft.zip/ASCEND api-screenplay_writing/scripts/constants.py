import os
import re
from pathlib import Path
from rest_framework import status

class Constants:
    NAME_SUFFIXES = ["V.O", "(V.O.)", "(CONT'D)"]
    SPECIAL_CHARS = re.compile('[@_!#$%^&*()<>?/\|}{~:“;”,.\n"\' -]')
    ALPHANUM_SPACE = "[^A-Z,^0-9 '\"]"
    DIALOGUE_CLEANUP_LIB = 'nltk'  # spacy or nltk
    DIALOGUE_CLEANUP_LIB_2 = 'nltk'  # spacy or nltk
    PAGE_FILLERS = ["CUT TO:", "CUT TO BLACK", "CUT TO", "SLOW DISSOLVE TO", "DISSOLVE TO:"]
    Unknown = "Unknown"
    SUFFIXES = ["'s","’s" ]
    EMAIL_PATTERN = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,7}\b'
    SUPPORT_EMAIL = "support@scriptcraft.ai"
    COMPANY = "ScriptCraft AI"
    REGISTERUSER = "RegisterUser"
    SUBSCRIPTION_ID_START = 10200
    geo_api2 = "https://geolocation-db.com/json/"
    HTTP_SUCCESS = status.HTTP_200_OK
    SCREENPLAY_PUBLISH_FOLDER = "published"

    model_path = str(Path("..", "models"))
    #abs_path = os.path.abspath(r"..")
    #EMOTION_MODEL_PATH = r'Z:\Apps\screenplay\code\models\bert-base-uncased-emotion'
    #EMOTION_MODEL_PATH = r"..\models\bert-base-uncased-emotion"
    EMOTION_MODEL_PATH = os.path.join(model_path, "bert-base-uncased-emotion")
    #print('EMOTION_MODEL_PATH ', EMOTION_MODEL_PATH)
    #GENRE_MODEL_PATH=r"..\models\genre"
    GENRE_MODEL_PATH = os.path.join(model_path, 'genre')
    SUMMARY_MODEL_PATH = os.path.join(model_path, "summary")

#     CHARACTER_NER_MODEL_PATH = os.path.join(
#             r"..\models\ner\characters\ner-english-ontonotes-large",
#             r"2da6c2cdd76e59113033adf670340bfd820f0301ae2e39204d67ba2dc276cc28.ec1bdb304b6c66111532c3b1fc6e522460ae73f1901848a4d0362cdf9760edb1"
#             )
    
    CHARACTER_NER_MODEL_PATH = os.path.join(
        model_path, 'ner', 'characters', 'ner-english-ontonotes-large' ,
        r"2da6c2cdd76e59113033adf670340bfd820f0301ae2e39204d67ba2dc276cc28.ec1bdb304b6c66111532c3b1fc6e522460ae73f1901848a4d0362cdf9760edb1"
        )
    CHARACTER_NER_FAST_MODEL_PATH = os.path.join(
        model_path, 'ner', 'characters', 'ner-english-ontonotes-fast' ,
        r"0d55dd3b912da9cf26e003035a0c269a0e9ab222f0be1e48a3bbba3a58c0fed0.c9907cd5fde3ce84b71a4172e7ca03841cd81ab71d13eb68aa08b259f57c00b6"
        )
    #print('CHARACTER_NER_MODEL_PATH ', CHARACTER_NER_MODEL_PATH)
#     CHARACTER_NER_FAST_MODEL_PATH = os.path.join(
#             r"..\models\ner\characters\ner-english-ontonotes-fast",
#             r"0d55dd3b912da9cf26e003035a0c269a0e9ab222f0be1e48a3bbba3a58c0fed0.c9907cd5fde3ce84b71a4172e7ca03841cd81ab71d13eb68aa08b259f57c00b6"
#             )