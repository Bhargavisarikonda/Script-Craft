"""scripts URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include, re_path
from authx2 import views as auth_views
from authx2.authenticate import register
from authx2.src.passmodule import PasswordModule
from batch import views as batch_views
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import (TokenObtainPairView, TokenRefreshView, TokenVerifyView )
from rest_framework import permissions
from rest_framework.decorators import permission_classes, authentication_classes
from rest_framework.permissions import AllowAny, IsAuthenticated


#from rest_framework_swagger.views import get_swagger_view
from drf_yasg.views import get_schema_view
from drf_yasg import openapi
from services import views as services_views

schema_view = get_schema_view(
   openapi.Info(
      title="Script Craft AI API",
      default_version='v1',
      description="API Request-Response handover tool",
    #   terms_of_service="https://www.google.com/policies/terms/",
    #   contact=openapi.Contact(email="contact@snippets.local"),
    #   license=openapi.License(name="BSD License"),
   ),
   public=True,
   permission_classes=[AllowAny],
   authentication_classes=[],
)

router = DefaultRouter(trailing_slash=False)
router.register(r'author', auth_views.AuthorViewSet)
router.register('books', auth_views.BookViewSet)
router.register('authordetail', auth_views.AuthorDetailViewSet)

endpoint_prefix = 'api/v1/'
urlpatterns = [
    #url(r'^$', schema_view'),
    path('kurkan/admin', admin.site.urls),
    path('swagger(?P<format>\.json|\.yaml)$', schema_view.without_ui(cache_timeout=0), name='schema-json'),
    path('swagger/', schema_view.with_ui('swagger', cache_timeout=0), name='schema-swagger-ui'),
    # path('redoc/', schema_view.with_ui('redoc', cache_timeout=0), name='schema-redoc'),
    path(endpoint_prefix, include(router.urls)),
    path(endpoint_prefix + 'auth/signin', auth_views.customJwt.as_view() ),
    #path(endpoint_prefix + 'token/refresh', TokenRefreshView.as_view()),
    #path(endpoint_prefix + 'token/verify', TokenVerifyView.as_view()),
    #path(endpoint_prefix + 'auth/signup', authentication_classes([])(permission_classes([AllowAny])(auth_views.RegisterView)).as_view()),
    path(endpoint_prefix + 'auth/signup', authentication_classes([])(permission_classes([AllowAny])(register.AuthRegister)).as_view({'post':'create'}),name='create_user_entry'),
    path(endpoint_prefix + 'auth/signuplog', authentication_classes([])(permission_classes([AllowAny])(auth_views.SignupLogView)).as_view({'post': 'create', 'put': 'update'})),
    #path(endpoint_prefix + 'auth/login_user', auth_views.login_user),
    path(endpoint_prefix + 'auth/changepassword', PasswordModule.as_view({'post':'change_password'}),name='change_password'),
    path(endpoint_prefix + 'auth/forgotpassword', authentication_classes([])(permission_classes([AllowAny])(PasswordModule)).as_view({'post':'forgot_password'}),name='forgot_password'),
    path(endpoint_prefix + 'auth/resetpassword', authentication_classes([])(permission_classes([AllowAny])(PasswordModule)).as_view({'post':'reset_password'}),name='reset_password'),
    path(endpoint_prefix + 'auth/generateotp', authentication_classes([])(permission_classes([AllowAny])(PasswordModule)).as_view({'post':'generate_otp_for_signup'}),name='generate_otp_for_signup'),
    # AllowAny for below is done inside the view code. Since it's a function & not class, permission here was not working
    path(endpoint_prefix + 'authcode_to_token', auth_views.google_authenticate),
    path(endpoint_prefix, include('batch.urls')),
    path(endpoint_prefix, include('services.urls')),
    path(endpoint_prefix, include('screenwriting.urls')),
    path(endpoint_prefix + 'prometheus/', include('django_prometheus.urls')),
    re_path(endpoint_prefix + r'hc', include('health_check.urls')),
]

