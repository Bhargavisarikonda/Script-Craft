from enum import Enum

class DayTime(Enum):
    DAY = 'DAY'
    DAWN = 'DAWN'
    MORNING = 'MORNING'
    SUNRISE = 'SUNRISE'
    AFTERNOON = 'AFTERNOON'

class NightTime(Enum):
    DUSK = 'DUSK'
    NIGHT = 'NIGHT'
    EVENING = 'EVENING'
    SUNSET = 'SUNSET'

class ContTime(Enum):
    CONTINUOUS = 'CONTINUOUS'
    LATER = 'LATER'
    
class SystemUsers(Enum):
    Batch = 1
    Services = 2
    Payment = 3

class SceneAttribute(Enum):
    Action = 1
    Dialogue = 2
    Both = 3

class Level(Enum):
    Screenplay = 1
    Scene = 2

class AIModels(Enum):
    Emotion = 1
    Character = 2
    Genre = 3
    Summary = 4
    MPAA = 5

class ScreenplayStatus(Enum):
    Inprogress = 10
    Completed = 30
    Failed = 50
    PartialComplete = 40
    
class SceneType(Enum):
    Interior = 1
    Exterior = 2
    Preface = 3
    Both = 4

class CompanyType(Enum):
    company_type = 'Company'
    individual_type = 'Individual'

class Languages(Enum):
    English = 1
    Hindi = 2
    Telugu = 3
    Tamil = 4

class OauthSource(Enum):
    Gmail = "gmail"
    Facebook = "facebook"
    Twitter = "twitter"
    Linkedin = "linkedin"

class EmailType(Enum):
    ForgotPassword = "to reset your password"
    SignUp = "for sign-up"


class DbSchema(Enum):
    default = "default"
    screenwriting = "screenwriting_schema"

class SearchCategory(Enum):
    title = 1
    genre = 2
    plot_summary = 3
    writer = 4