# README

This README would normally document whatever steps are necessary to get your application up and running.

### Install
conda env create -f requirements/environment.yml
OR
pip install -r requirements/requirements.txt 

### What is this repository for?

- Quick summary
- Version
- [Learn Markdown](https://bitbucket.org/tutorials/markdowndemo)

### Add .env file in root directory

## THIS IS HOW DEBUG IN .ENV FILE WORKS - 
## In lower env, set DEBUG="True". Automatically, all django & system DEBUG messages will be shown on console and log file. To avoid this spam, set SCRIPTS_DJANGO_LOG_LEVEL="INFO", so that only INFO system/django messages are shown.
## For higher env, comment out DEBUG, so that invalid url on browser/postman does not expose all valid endpoints. This automatically sets SCRIPTS_DJANGO_LOG_LEVEL to INFO level.
## For appl level messages on console and log, play around with SCRIPTS_APPL_LOG_LEVEL.


#### Content of the file are:

    ```
    DEBUG="True"   # In prod, comment this line, or else invalid url on browser will expose all valid urls
    DB_NAME='scriptdb'  # replace in prod
    DB_USER='dbuser' # replace in prod
    DB_PASSWORD='Pls ask...' # replace in prod
    DB_HOST='localhost' # replace
    SCRIPTS_APPL_LOG_LEVEL="DEBUG" # this is log level for application logs 
    SCRIPTS_DJANGO_LOG_LEVEL="INFO"  # controls level of django system logs
    RUN_MAIN='None'   # 'None' when running using runserver; any other value (say 'Yes') when using gunicorn
    S3_BUCKET_NAME=dev-aimovies  # demo-aimovies ; aimovies
    S3_REGION_NAME=ap-south-1
    # DEMO - https://demo-aimovies.s3.ap-south-1.amazonaws.com/
    # DEV - https://dev-aimovies.s3.ap-south-1.amazonaws.com/
    # PROD - https://aimovies.s3.ap-south-1.amazonaws.com/
    S3_URL_PREFIX=https://dev-aimovies.s3.ap-south-1.amazonaws.com/
    AWS_ACCESS_KEY_ID=     # --> keep it empty, use IAM role on aws
    AWS_SECRET_ACCESS_KEY=  # --> keep it empty, use IAM role on aws
    SMTP_USER=    # smpt user
    SMTP_PASSWORD=   # smtp password
    SMTP_HOST=   # smpt server
    SMTP_PORT=465
    SMTP_DEBUG_LEVEL=2  # 1 for debug, 2 otherwise
    #AWS_PROFILE="default"   # "default" for local: will use creds in .aws; comment out for higher envs, because IAM role will take over
    ALLOWED_ADMIN_IPS = ["202.133.55.215", "127.0.0.1"]   # for prod remove 127.0.0.1
    ALLOWED_HOSTS = "127.0.0.1,localhost"   # ensure no space in between urls ; for prod "api.scriptcraft.ai,172.31.12.218"  ; demo 
                "127.0.0.1,localhost,api-demo.scriptcraft.ai,172.31.22.4"   
    CORS_ALLOWED_ORIGINS="http://localhost:3000"  # ensure no space in between urls ; for prod "https://www.scriptcraft.ai,https://home.scriptcraft.ai"  ; demo "http://localhost:3000,http://demo-screenplay.ai-movies.com.s3-website.ap-south-1.amazonaws.com,http://demo.scriptcraft.ai"
    OPENAI_API_KEY='Pls ask...' # replace in prod
    ```

### How do I get set up?

- Summary of set up
- Configuration
- Dependencies
- Database configuration
- How to run tests
- Deployment instructions
In prod - activate aiMovies
    gunicorn -c config/gunicorn/prod.py    --> runs on port 8000
In demo -    activate aiMovies
    gunicorn -c config/gunicorn/demo.py    --> runs on port 8000
Local -  activate ai_movies
    python manage.py runserver   --> runs on port 8000

### Contribution guidelines

- Writing tests
- Code review
- Other guidelines

### Who do I talk to?

- Repo owner or admin
- Other community or team contact

### One-time DB configuration

- Add a row in client table with client_name as 'Individual', to map all individual users (who are not part of an Org)

### Additional lines should go below
