from .models import Author, Books, Temp
from rest_framework import serializers
from batch.models import SignupLog


class SignupLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = SignupLog
        fields = "__all__"


class BookSerializer(serializers.ModelSerializer):
    class Meta:
        model = Books
        fields = '__all__'


class AuthorSerializer(serializers.ModelSerializer):
    class Meta:
        model = Author
        fields = '__all__'


class AuthorDetailSerializer(serializers.ModelSerializer):
    author_books = BookSerializer(read_only=True, many=True)
    # books = serializers.PrimaryKeyRelatedField(read_only=True, many=True)

    class Meta:
        model = Author
        fields = '__all__'


class TempSerializer(serializers.ModelSerializer):
    class Meta:
        model = Temp
        fields = '__all__'
