from django.db import models
from rest_framework import viewsets, status, generics
from rest_framework.response import Response
from .models import Author, Books
from django.contrib.auth.models import User
from .serializer import AuthorSerializer, BookSerializer, AuthorDetailSerializer
from rest_framework.permissions import IsAuthenticated, DjangoModelPermissions, AllowAny
from rest_framework_simplejwt.views import (
    TokenObtainPairView, TokenRefreshView, TokenVerifyView)
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from rest_framework_simplejwt.tokens import AccessToken, RefreshToken
from .authenticate.tokens import MyTokenObtainPairSerializer
from .authenticate.register import RegisterSerializer
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth import authenticate
from django.http.response import JsonResponse
from rest_framework.response import Response
from scripts.messages import Messages
from scripts.enums import OauthSource
from batch.models import SignupLog, Profile
from batch.src.utils import get_ip_address
from authx2.src.utils import NewGoogleUser
from authx2.DTO.SignupLogDto import SignupLogDto
from .serializer import SignupLogSerializer
from google.auth import jwt
from django.contrib.auth import login, hashers
from django.conf import settings
from google_auth_oauthlib.flow import Flow
# from oauth2client import client
import json
import logging
import google.auth.transport.requests
from rest_framework.decorators import api_view, renderer_classes, permission_classes
import re
from scripts import settings
#import jwt

# Create your models here.

logger = logging.getLogger("scripts_logger")

class AuthorViewSet(viewsets.ModelViewSet):
    queryset = Author.objects.all()
    serializer_class = AuthorSerializer
    # permission_classes = [IsAuthenticated]


class BookViewSet(viewsets.ModelViewSet):
    queryset = Books.objects.all()
    serializer_class = BookSerializer


class AuthorDetailViewSet(viewsets.ModelViewSet):
    queryset = Author.objects.all()
    serializer_class = AuthorDetailSerializer


class customJwt(TokenObtainPairView):
    serializer_class = MyTokenObtainPairSerializer


class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    # permission_classes = (AllowAny,)
    serializer_class = RegisterSerializer

# class customJwt(TokenObtainPairView):

#     def post(self, request, *args, **kwargs):
#         serializer = self.serializer_class(data=request.data,
#                                            context={'request': request})
#         serializer.is_valid(raise_exception=True)
#         user = serializer.validated_data['user']
#         token = AccessToken.for_user(user)
#         refresh = RefreshToken.for_user(user)
#         print('access ', token)
#         return Response({
#             'token': token,
#             'refresh': refresh,
#             'user_id': user.pk,
#             'name': user.username
#         })
def get_tokens_for_user(user):
    refresh = RefreshToken.for_user(user)

    return {
        'refresh': str(refresh),
        'access': str(refresh.access_token),
    }

@csrf_exempt
def login_user(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        #if user wants to login with contact number or email
        user = authenticate(username=username, password=password)
        if user is not None:
            result = {}
            tokens = get_tokens_for_user(user)
            result['username'] = username
            result['access'] = tokens['access']
            result['refresh'] = tokens['refresh']

            message, status = Messages.success.value
            return Response(result, status)
            #return Response(result, safe=False)
        else:
            message, status = Messages.notAuthenticated.value
            #return Response({"message":"User or password doesnt authenticate"}, status=401)
            return Response(message, status)


class SignupLogView(viewsets.ViewSet):

    serializer_class = SignupLogSerializer
    queryset = SignupLog.objects.all()

    def extract_numbers(self, code):
        # Only take numbers from mobile code. If it is '+91', it becomes just 91
        num_mobile_code = re.findall('\d+', code) 
        # Above returns list. Convert to string
        num_mobile_code = ''.join(num_mobile_code)
        return int(num_mobile_code)

    def create(self, request, id=None):
        req = json.loads(request.body)['payload']
        #req['mobile_code'] = self.extract_numbers(req['mobile_code'])
        req['mobile_code'] = req['mobile_code']
        #req['company_phone_number_code'] = self.extract_numbers(req['company_phone_number_code'])
        req['company_phone_number_code'] = req['company_phone_number_code']
        req['ip_address'] = get_ip_address(req['geo_location'])
        req['password'] = hashers.make_password(req['password'])
        
        serializer = SignupLogSerializer(data=req)
        #print('serializer ', serializer)
        if serializer.is_valid():
            ser = serializer.save()
            #print("ser ", ser, ser.signup_uid, ser.email_id)
            message, status = Messages.insertSuccess.value
            return Response({"signup_uid": ser.signup_uid}, status)
        else:
            logger.error(f'Serializer error: {serializer.errors}')
            message, status = Messages.sqlerror.value
            return Response(message, status)

    def update(self, request, *args, **kwargs):
        try:
            req = json.loads(request.body)['payload']
            #data = request.data
            signupLog = SignupLog.objects.get(pk= req['signup_uid'])
            signupLog.subscription_uid = req['subscription_uid']
            signupLog.save(update_fields=['subscription_uid'])
            message, status = Messages.updateSuccess.value
            return Response(message, status)
        except Exception as e:
            logger.error(f'Update subscription failed: {e}')
            message, status = Messages.sqlerror.value
            return Response(e, status)


@api_view(('POST',))
@permission_classes([AllowAny])
@csrf_exempt
def google_authenticate(request):
    try:
        access_token = request.body
        message, status = Messages.success.value

        if access_token:
            access_token = json.loads(access_token)
            auth_code = access_token['authcode']['code']
            flow = Flow.from_client_secrets_file(
                settings.CLIENT_SECRET_FILE,
                scopes=['openid', "https://www.googleapis.com/auth/userinfo.email",
                        "https://www.googleapis.com/auth/userinfo.profile"],
                redirect_uri='postmessage'
            )
            credentials = flow.fetch_token(code=auth_code)
            request1 = google.auth.transport.requests.Request()
            #print('token ', credentials['id_token'])
            id_token = jwt.decode(credentials['id_token'], verify=False)

            userid = id_token['sub']
            username = id_token['email']
            email = id_token['email']
            fullname = id_token['name']
            first_name = id_token['given_name']
            last_name = id_token['family_name']
            user_pic = id_token['picture']
  
            # Check if user already exists in database, and login or register accordingly
            user = User.objects.filter(email=email).first()
            if not user:
                signupLogDto = SignupLogDto(username=username, email_id=email, password="", first_name=first_name, last_name=last_name,
                           oauth=True, source=OauthSource.Gmail.value, external_userid=userid,  avatar=user_pic, subscription_uid=1 )
                
                payment_pending = True             

                args = (signupLogDto, payment_pending)
                newGoogleUser = NewGoogleUser(*args)    
                newGoogleUser.signup()
                message, status = newGoogleUser.response()
                #user = User.objects.create_user(
                #    username=username, email=email, password=None, first_name=first_name, last_name=last_name)
                #profile = Profile.objects.create(user=user, external_userid=userid, oauth=True,
                #                source=OauthSource.Gmail.value, avatar=user_pic )

                user = newGoogleUser.get_user()

            if status == Messages.success.value[1]:
                login(request, user)                
                result = {}
                #tokens = get_tokens_for_user(user)
                tokens = customJwt.serializer_class.get_token(user)
 
                result['username'] = username
                result['access'] = str(tokens.access_token)
                result['refresh'] = str(tokens)
                result['firstName'] = first_name
                message, status = Messages.success.value
                return Response(result , status)
            else:
                logger.error(f"Google authentication error")
                return Response(message, status)                
            
    except Exception as e:
        logger.error(f'Error in google_authenticate: {e} ')
        message, status = Messages.gmailSigninFail.value
        return Response(message, status)
