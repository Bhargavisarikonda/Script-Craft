from django.db import models
from rest_framework import viewsets


# Create your models here.
class Author(models.Model):
    #author_id = models.BigIntegerField(primary_key=True, auto_created=True )
    author_id = models.AutoField(primary_key=True, auto_created=True)
    name = models.CharField(max_length=20)
    class Meta:
        db_table = "author"

class Books(models.Model):
    #book_id = models.BigIntegerField(primary_key=True, auto_created=True)
    book_id = models.AutoField(primary_key=True, auto_created=True)
    title = models.CharField(max_length=100)
    genre = models.CharField(max_length=20)
    fk_author_id = models.ForeignKey(Author, related_name="author_books", on_delete=models.RESTRICT)
    class Meta:
        db_table = "books"

    def __str__(self):
        return " %s " %(self.title)

class Temp(models.Model):
    id = models.AutoField(primary_key=True, auto_created=True)
    value = models.CharField(max_length=20)

    class Meta:
        db_table = "temp"
