
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from batch.models import ClientUser

class MyTokenObtainPairSerializer(TokenObtainPairSerializer):
    @classmethod
    def get_token(cls, user):
        #print('user ', user)
        token = super().get_token(user)
        # Add custom claims - if you uncomment below 2 lines, these fields will get added to cliams
        #token['username'] = user.username

        # Get tenant id corresponding to user and add in jwt claims
        clientuser = ClientUser.objects.filter(id = token['user_id']).first()
        #print('clientuser ', clientuser)
        token['tenant_id'] = clientuser.tenant_uid.tenant_uid
        #token['firstName'] = user.first_name

        #print('token ', token)
        return token

    def validate(self, attrs):
        data = super().validate(attrs)
        #print('data  ' , data)
        #refresh = self.get_token(self.user)
        data['username'] = self.user.username
        data['firstName'] = self.user.first_name
        # below fields get updated in 'super' statement above
        #data['access'] = str(refresh.access_token)
        #data['refresh'] = str(refresh)
        #print('data 2 ', data)
        return data
