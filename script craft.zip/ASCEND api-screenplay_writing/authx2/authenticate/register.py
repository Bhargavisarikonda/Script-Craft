from rest_framework import serializers
from django.contrib.auth.models import User
from rest_framework.validators import UniqueValidator
from django.contrib.auth.password_validation import validate_password
from batch.models import Profile, Client, ClientUser, Address, SignupLog, Tenant
import datetime
import psycopg2
from django.db import connection
from django.http.response import JsonResponse
import json
from django.core import serializers as sl
from rest_framework.response import Response
from scripts.enums import CompanyType
from django.contrib.auth.models import User
from authx2.src.utils import NewIndvUserFree, NewIndvUserPaid, NewClientUserFree, NewClientUserPaid
from authx2.DTO.UserDto import UserDto
from authx2.DTO.SignupLogDto import SignupLogDto
from authx2.DTO.SignupModelToDTO import signupModelToDTO
import logging
from scripts.messages import Messages
from rest_framework import viewsets, status, generics


logger = logging.getLogger("scripts_logger")


def create_profile(user, mobile_number=55555, country_code=91):
    try:
        profile_object = Profile.objects.create(
            user_uid=user, mobile_number=mobile_number, country_code=country_code)
        return profile_object
    except:
        return False


def create_client(client_name, address_uid, batch_size=1, weblink="google.com", phone_number=55555, country_code=91, fax=55555):
    try:
        client_object = Client.objects.create(client_name=client_name, address_uid=address_uid, batch_size=batch_size,
                                              weblink=weblink, phone_number=phone_number, country_code=country_code, fax=fax)
        return client_object
    except:
        return False


def create_client_user(user_filter, client_filter, subscription_uid, payment_pending):
    try:
        client_object = ClientUser.objects.create(
            id=user_filter, client_uid=client_filter, subscription_uid=subscription_uid, payment_pending=payment_pending)
        return client_object
    except:
        return False


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'username', 'email', 'first_name', 'last_name')


# def create_intermediate_user(username, email, firstname, lastname, usertype, mobile_number=55555, country_code=91):
#     try:
#         intermediate_user = IntermediateRegisterUser.objects.create(username=username,email=email, firstname=firstname, lastname=lastname,
#                     mobile_number=mobile_number, country_code=country_code, usertype=usertype)

#         return intermediate_user
#     except:
#         return False

# def create_intermediate_client(intermediate_register_user, company_name, address_line_1=None, address_line_2=None, city=None, state=None, zip_code=None, country=None, company_website=None, fax_number=None):
#     try:
#         intermediate_client = InterMediateClient.objects.create(intermediate_register_user_uid=intermediate_register_user, company_name=company_name, address_line_1=address_line_1,
#                     address_line_2=address_line_2,city=city, state=state, zip_code=zip_code, country=country, company_website=company_website,
#                     fax_number=fax_number)
#         IntermediateClientUser.objects.create(intermediate_register_user.intermediate_register_user_uid, client_uid=intermediate_client.intermediate_client_uid)
#         return intermediate_client
#     except:
#         return False

class ClientUserSerializer(serializers.ModelSerializer):
    class Meta:
        fields = '__all__'
        model = ClientUser


class CombinedSerializer(ClientUserSerializer, UserSerializer):
    pass


class RegisterSerializer(serializers.ModelSerializer):
    # client_items = serializers.SerializerMethodField('get_extra_field')
    #password = serializers.CharField(write_only=True, required=True, validators=[validate_password])
    #password2 = serializers.CharField(write_only=True, required=True)
    # user_signup = serializers.SerializerMethodField('user_field')

    
    class Meta:
        model = User
        fields = ('client_items', 'user_signup')
        fields = '__all__'

    def validate(self, attrs):
        #     if attrs['password'] != attrs['password2']:
        #         raise serializers.ValidationError({"password": "Password fields didn't match."})

        return attrs

class AuthRegister(viewsets.ViewSet):
    def create(self, request):
        req = json.loads(request.body)['payload']
        signuplog_id = req.get('signup_uid', None)
        #print("signup log ", signuplog_id, req)
        signuplog = SignupLog.objects.get(pk = signuplog_id)

        try:
            payment_pending = self.initial_data['payment_pending']
        except Exception as e:
            payment_pending = True


        SignupLogDto = signupModelToDTO(signuplog)
        # Sign up by company
        if signuplog.type == CompanyType.company_type.value:
            #print("company")
            # Checking if Company already exists
            existing_client = Client.objects.filter(client_name=signuplog.company_name).values()
            # This happens when a user registers with his org name without realizing that someone else has registered with the same org 
            # name. Ideally, the users within an org should be coordinated, meaning if one user registers then that user should be able
            # to add more users after logging in. However, sometimes users may not know, e.g. different departments; hence, this 
            # scenario is accepted - the client table will have multiple rows with same client name.
            if existing_client:
                logger.warn(f"Duplicate client: {existing_client.client_name} for user email: {signuplog.email_id }")
            
            # 'Individual' is a reserved client name for all registered, free users. Nobody should be allowed to register a company with 
            # name 'Individual'. UI blocks it, however, due to some reason UI did not block it, edit the company name as below.
            if signuplog.company_name == CompanyType.individual_type.value:
                logger.error(f"Severe error - 'Individual' is a reserved client name; UI should not have allowed it. User \
                            email: {signuplog.email_id}")
                signuplog.company_name = signuplog.company_name + ' - ' + str(signuplog.signup_uid)

            try:
                # Free subscriber
                if payment_pending:
                    args = (SignupLogDto, payment_pending)
                    newClientUserFree = NewClientUserFree(*args)
                    newClientUserFree.signup()
                    message, status = newClientUserFree.response()
                else:
                    # Paid subscriber
                    args = (SignupLogDto, payment_pending)
                    newClientUserPaid = NewClientUserPaid(*args)
                    newClientUserPaid.signup()
                    message, status = newClientUserPaid.response()
            except Exception as e:
                logger.error(f"Signup failed for client user: {e}")
                message, status = Messages.signupFail.value
        else:
            #print("individual")
            # Sign up by individual
            try:
                # Free subscriber, assign them to a generic, common client id
                if payment_pending:
                    #client = Client.objects.get(client_name = CompanyType.individual_type.value)
                    #tenant = Tenant.objects.raw("select t.* from tenant as t inner join client_user as cu on t.tenant_uid = cu.tenant_uid \
                    #        where cu.client_uid = %s " , [client.client_uid])[0]

                    args = (SignupLogDto, payment_pending)
                    newIndvUserFree = NewIndvUserFree(*args)
                    newIndvUserFree.signup()
                    message, status = newIndvUserFree.response()
                else:
                    # Paid individual. Create a separate client id
                    args = (SignupLogDto, payment_pending)
                    newIndvUserPaid = NewIndvUserPaid(*args)
                    newIndvUserPaid.signup()
                    message, status = newIndvUserPaid.response()
            except Exception as e:
                logger.error(f"Signup failed for individual user: {e}")
                message, status = Messages.signupFail.value

        
        #SignupLog.objects.filter(signup_uid=validated_data['user_signup']).delete()
        
        return Response(message, status)

    # def get_extra_field(self, instance):
    #     client_obj = ClientUser.objects.filter(id=instance.id).first()
    #     serializer = ClientUserSerializer(client_obj)
    #     return serializer.data

    # def user_field(self, instance):
    #     serializer1 = UserSerializer(instance)
    #     return serializer1.data
