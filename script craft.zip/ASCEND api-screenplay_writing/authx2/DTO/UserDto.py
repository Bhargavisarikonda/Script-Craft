from typing import NamedTuple

class UserDto(NamedTuple):
    id: int
    password: str
    username: str
    first_name: str
    last_name: str
    email: str

