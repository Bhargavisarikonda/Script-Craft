from typing import TypedDict
from scripts.constants import Constants
from dataclasses import dataclass

@dataclass
class SignupLogDto:
    signup_uid: int = 0
    password: str = ""
    username: str = ""
    first_name: str = ""
    last_name: str = ""
    email_id: str = ""
    mobile_number: int = 0
    mobile_code: int = 0
    type: str = ""
    company_name: str = ""
    weblink: str = ""
    line_1: str = ""
    line_2: int = 0
    city: str = ""
    state: str = ""
    country: str = ""
    zipcode: str = ""
    company_phone_number: int = 0
    company_phone_number_code: int = 0
    fax: str = ""
    ip_address: str  = ""
    geo_location: str = ""
    subscription_uid: int = 0
    created_on: str = ""
    created_by: str = ""
    oauth: bool = False
    source: str = Constants.REGISTERUSER
    external_userid: str =""
    avatar: str =""
    
