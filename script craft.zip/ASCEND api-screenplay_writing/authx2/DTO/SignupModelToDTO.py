
from authx2.DTO.SignupLogDto import SignupLogDto

def signupModelToDTO(data_model):
    SignupLogDto.signup_uid = data_model.signup_uid
    SignupLogDto.password = data_model.password
    SignupLogDto.username = data_model.username
    SignupLogDto.first_name = data_model.first_name
    SignupLogDto.last_name = data_model.last_name
    SignupLogDto.email_id = data_model.email_id
    SignupLogDto.mobile_number = data_model.mobile
    SignupLogDto.mobile_code = data_model.mobile_code
    SignupLogDto.type = data_model.type
    SignupLogDto.company_name = data_model.company_name
    SignupLogDto.weblink = data_model.weblink
    SignupLogDto.line_1 = data_model.line_1
    SignupLogDto.line_2 = data_model.line_2
    SignupLogDto.city = data_model.city
    SignupLogDto.state = data_model.state
    SignupLogDto.country = data_model.country
    SignupLogDto.zipcode = data_model.zipcode
    SignupLogDto.company_phone_number = data_model.company_phone_number
    SignupLogDto.company_phone_number_code = data_model.company_phone_number_code
    SignupLogDto.fax = data_model.fax
    SignupLogDto.ip_address = data_model.ip_address
    SignupLogDto.geo_location = data_model.geo_location
    SignupLogDto.subscription_uid = data_model.subscription_uid
    SignupLogDto.created_on = data_model.created_on
    SignupLogDto.created_by = data_model.created_by
    try:
        SignupLogDto.oauth = data_model.oauth
    except:
        SignupLogDto.oauth = False
    try:
        SignupLogDto.source = data_model.source
    except:
        SignupLogDto.source = ""
    try:
        SignupLogDto.external_userid = data_model.external_userid
    except:
        SignupLogDto.external_userid = ""
    try:
        SignupLogDto.avatar = data_model.avatar
    except:
        SignupLogDto.avatar = ""


    return SignupLogDto