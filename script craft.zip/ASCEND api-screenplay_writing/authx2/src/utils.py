from django.contrib.auth.models import User
from batch.models import Profile, Client, ClientUser, Tenant, SignupLog, Address, Subscription, Tenant
from scripts.constants import Constants
from scripts.enums import CompanyType
from scripts.messages import Messages
from django.db import transaction
import logging

logger = logging.getLogger("scripts_logger")


class RegisterUser:

    def __init__(self, userDetails, payment_pending=True) -> None:
        self.userDetails = userDetails
        self.address = None
        self.client = None
        self.client_user = None
        self.user = None
        self.profile = None
        self.tenant = None
        self.payment_pending = payment_pending
        self.message, self.status = Messages.success.value
        self._error = False
        self._user_existing = False
    
    def create_user(self):
        self.userDetails.email_id = self.userDetails.email_id.lower()
        self.userDetails.username = self.userDetails.username.lower()

        try:
            user = User.objects.get(email__iexact = self.userDetails.email_id)
            self._user_existing = True
        except User.DoesNotExist:
            self._user_existing = False

        
        # If user logs in via oauth using a certain gmail, and later registers with the same gmail, we'll have to UPDATE user table
        # with registration details. If user directly registers, then INSERT row in user table
        update_values = {'username': self.userDetails.username ,
                        'first_name': self.userDetails.first_name,
                        'last_name':  self.userDetails.last_name,
                        'password': self.userDetails.password
                    }
        User.objects.update_or_create(                
                email = self.userDetails.email_id,
                defaults=update_values
        )

        self.user = User.objects.get(email=self.userDetails.email_id)
     
        #self.user.set_password(self.userDetails.password)
        #self.user.save()

    def create_profile(self):
        
        insert = False
        try:
            profile = Profile.objects.get(user__id = self.user.id)
        except Profile.DoesNotExist:
            insert = True

        try:
            profile_oauth = self.userDetails.oauth
        except:
            profile_oauth = False
        try:
            profile_avatar = self.userDetails.avatar
        except:
            profile_avatar = ""
        try:
            profile_source = self.userDetails.source
        except:
            profile_source = ""
        try:
            profile_external_userid = self.userDetails.external_userid
        except:
            profile_external_userid = ""
        # If gmail oauth user is registering with same gmail id, profile should be updated only with new fields. If totally new user then
        # just insert
        if insert:
            self.profile = Profile.objects.create(
                user = self.user,
                avatar = profile_avatar,
                mobile_number = self.userDetails.mobile_number,
                country_code = self.userDetails.mobile_code,
                oauth = profile_oauth,
                source = profile_source,
                external_userid = profile_external_userid
            )
            self.profile.save()
        else:
            profile.mobile_number = self.userDetails.mobile_number
            profile.country_code = self.userDetails.mobile_code
            profile.oauth = profile_oauth
            profile.source = profile_source
            self.profile = profile.save(update_fields=['country_code', 'oauth', 'source', 'mobile_number'])
        

    def create_client(self):

        # Below is a failsafe mechanism to prevent creation of client if user (based on email id) is already existing in user table
        if self._user_existing:
            pass
        else:
            self.create_address()

            self.client = Client.objects.create(
                client_name = self.userDetails.client_name,
                address_uid = self.address,
                weblink = self.userDetails.weblink,
                phone_number = self.userDetails.company_phone_number,
                country_code = self.userDetails.company_phone_number_code,
                fax = self.userDetails.fax
            )

            self.client.save()


    def create_client_user(self):

        # Below is a failsafe mechanism to prevent creation of client_user if user (based on email id) is already existing in user table
        if self._user_existing:
            pass
        else:
            subscription = Subscription.objects.get(pk = self.userDetails.subscription_uid)
            
            self.client_user = ClientUser.objects.create(
                    id = self.user,
                    client_uid = self.client,
                    subscription_uid = subscription,
                    payment_pending = self.payment_pending,
                    tenant_uid = self.tenant
            )

            self.client_user.save()


    def create_tenant(self): 

        # Below is a failsafe mechanism to prevent creation of tenant if user (based on email id) is already existing in user table
        if  self._user_existing:
            pass
        else:
            self.tenant = Tenant.objects.create(
                    created_by = Constants.REGISTERUSER
            )

            self.tenant.save()
        
    
    def create_address(self):
        self.address = Address.objects.create(
                line_1 = self.userDetails.line_1,
                line_2 = self.userDetails.line_2,
                city = self.userDetails.city,
                state = self.userDetails.state,
                country = self.userDetails.country,
                zipcode = self.userDetails.zipcode
        )

        self.address.save

    # User, Profile and Tenant tables are populated in all scenarios
    def execute(self):
        self.create_user()
        self.create_profile()
        self.create_tenant()

    @transaction.atomic
    def signup(self):
        try:
            self.execute()
        except Exception as e:
            logger.error(f"RegisterUser error: {e}")
            self._error = True
            self.assign_error()

    def assign_error(self):
        self.message, self.status = Messages.signupFail.value

    def response(self):
        return self.message, self.status

    def get_user(self):
        return self.user




class NewClientUserFree(RegisterUser):    
    def __init__(self, *args) -> None:
        userDetails, payment_pending = args
        super().__init__(userDetails, payment_pending)

    def execute(self) -> None:
        super().execute()

        #self.create_address()
        self.create_client()
        self.create_client_user()

class NewClientUserPaid(NewClientUserFree):
    def __init__(self, *args) -> None:
        userDetails, payment_pending = args
        super().__init__(userDetails, payment_pending)



class NewIndvUserPaid(RegisterUser):
    def __init__(self, *args) -> None:
        userDetails, payment_pending = args
        super().__init__(userDetails, payment_pending)

    def execute(self) -> None:
        super().execute()

        # Create a new client id in client table since it's a paid user
        self.userDetails.client_name = "Client-" + str(self.user.id)
        self.create_client()
        self.create_client_user()

class NewIndvUserFree(RegisterUser):
    def __init__(self, *args) -> None:
        userDetails, payment_pending = args
        super().__init__(userDetails, payment_pending)

    def get_client(self):
        self.client = Client.objects.get(client_name = CompanyType.individual_type.value)

    def execute(self) -> None:
        super().execute()

        self.get_client()
        self.create_client_user()
        


class NewUserExistingClient(RegisterUser):
    def __init__(self, *args) -> None:
        userDetails, payment_pending, client = args
        super().__init__(userDetails, payment_pending)
        self.client = client
        self.tenant = None

    def get_tenant(self):
        # Fetch only the first row, as all rows will have same tenant id
        self.tenant = Tenant.objects.raw("select t.* from tenant as t inner join client_user as cu on t.tenant_uid = cu.tenant_uid \
                where cu.client_uid = %s " , [self.client.client_uid])[0] 


    def execute(self) -> None:
        self.create_user()
        self.create_profile()
        self.get_tenant()
        self.create_client_user()


class NewGoogleUser(NewIndvUserFree):
    def __init__(self, *args) -> None:
        userDetails, payment_pending = args
        super().__init__(userDetails, payment_pending)

    def assign_error(self):
        self.message, self.status = Messages.gmailSigninFail.value