from rest_framework import viewsets, status, generics
from rest_framework.response import Response
from batch.models import Scene
from django.db.models import Avg, Count, Min, Sum, Max
from django.contrib.auth.models import User
from rest_framework.decorators import action
from scripts.messages import Messages
from services.src.otp import OTP
from scripts.enums import EmailType
from services.mail.mail import send_smtp_mail
#src.otp.OTP import generate_otp, validate_otp
import logging
import json
from rest_framework import status as http_status

logger = logging.getLogger("scripts_logger")


class PasswordModule(viewsets.ViewSet):

    def __init__(self):
        self.new_password = ""
        self.user = None

    def update_password(self):
        # Update new password in user table
        self.user.set_password(self.new_password)
        self.user.save()

    @action(detail=True, methods=['POST'])
    def generate_otp_for_signup(self, request):
        req = json.loads(request.body)
        email = req.get("email", None)
        username = req.get("username", None)

        # Generate otp and email
        message, status, otp = OTP.generate_otp_function(email)
        if status != Messages.success.value[1]:
            return Response({"data": message}, status)

        # Send email
        try:
            send_smtp_mail(*(email, otp, username, EmailType.SignUp ))
            logger.info(f"Successfully sent email during signup: {email}")
        except Exception as e:
            logger.error(f'Email ({email}) send failed during signup: {e}')
            message, status = Messages.emailSendFail.value[0].format(email), Messages.emailSendFail.value[1]

        #return Response(json.dumps(rsp_msg), status)
        return Response({"data": message}, status)



    @action(detail=True, methods=['POST'])
    def forgot_password(self, request):
        req = json.loads(request.body)
        email = req.get("email", None)
        username = req.get("username", None)

        # Verify email id
        try:
            user = User.objects.get(email = email)
        except User.DoesNotExist:
            message, status = Messages.emailNotFound.value
            return Response({"data": message}, status)

        # Generate otp and email
        message, status, otp = OTP.generate_otp_function(email)
        if status != Messages.success.value[1]:
            return Response({"data": message}, status)

        # Send email
        try:
            send_smtp_mail(*(email, otp, username, EmailType.ForgotPassword))
            logger.info(f"Successfully sent email to reset password : {email}")
        except Exception as e:
            logger.error(f'Email ({email}) send failed durong reset password: {e}')
            message, status = Messages.emailSendFail.value[0].format(email), Messages.emailSendFail.value[1]

        #return Response(json.dumps(rsp_msg), status)
        return Response({"data": message}, status)

    # This module will receive either otp or old_password, depending on whether user is changing password due to forgotpassword or changepassword
    @action(detail=True, methods=['POST'])
    def reset_password(self, request):
        req = json.loads(request.body)

        email = req.get("email", None)
        self.user = User.objects.get(email=email)
        email = self.user.email

        otp = req.get("otp", None)
        if otp is None:
            message, status = Messages.severeError.value
            logger.error("Severe error in reset password module")
            return Response({"data": message}, status)
        else:
            match, message, status = PasswordModule.otp_processing(otp, email)            
    
        self.new_password = req.get("newPassword", None)

        if match:
            self.update_password()
        else:
            return Response({"data": message}, status)        
        
        message, status = Messages.success.value
        return Response({"data": message}, status)

    # This module will be called during change password from profile screen
    @action(detail=True, methods=['POST'])
    def change_password(self, request):
        req = json.loads(request.body)

        username = req.get("username", None)
        self.user = User.objects.get(username=username)
        email = self.user.email

        old_password = req.get("oldPassword", None)         
        if old_password is None:
            message, status = Messages.severeError.value
            logger.error("Severe error in change password module")
            return Response({"data": message}, status)
        else:
            match, message, status = PasswordModule.old_password_processing(old_password, self.user)   
    
        self.new_password = req.get("newPassword", None)

        if match:
            self.update_password()
        else:
            return Response({"data": message}, status)
        
        
        message, status = Messages.success.value
        return Response({"data": message}, status)



    @staticmethod
    def otp_processing(otp, email):
        message, status = OTP.validate_otp_funtion(otp, email)
        if status == Messages.success.value[1]:
            return True, message, status
        else:
            return False, message, status

    @staticmethod
    def old_password_processing(old_password, user):
        # Verify old password
        match = user.check_password(old_password)
        
        if match:
            return match, "", ""
        else:
            message, status = Messages.passwordInvalid.value
            return False, message, status 







