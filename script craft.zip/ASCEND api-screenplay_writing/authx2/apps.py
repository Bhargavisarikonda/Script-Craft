from django.apps import AppConfig


class Authx2Config(AppConfig):
    name = 'authx2'
