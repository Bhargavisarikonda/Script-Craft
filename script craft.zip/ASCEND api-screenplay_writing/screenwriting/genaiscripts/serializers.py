from rest_framework import serializers
from ..models import GeneratedScene

class ScriptSerializer(serializers.ModelSerializer):
    
    
    screenplay_version_uid = serializers.IntegerField() #
    scenetype_uid = serializers.IntegerField() #
    count_action=serializers.IntegerField()
    count_dialogues = serializers.IntegerField() #
    generated_scene_text = serializers.CharField() #
    scene_number = serializers.IntegerField() #
    count_words_action = serializers.IntegerField() #
    count_words_dialogues = serializers.IntegerField() #
    prompt_time_of_day = serializers.CharField(allow_blank=True) #
    prompt_location = serializers.CharField() #
    created_on = serializers.DateTimeField() #
    created_by = serializers.IntegerField() #
    modified_on = serializers.DateTimeField() #
    modified_by = serializers.IntegerField() #
    generation_time = serializers.IntegerField() #
    prompt_action = serializers.CharField(allow_blank=True) #
    prompt_props = serializers.CharField() # 
    prompt_mode = serializers.CharField() #
    prompt_plot_details = serializers.CharField() #


    class Meta:
        model=GeneratedScene
        fields="__all__"

        