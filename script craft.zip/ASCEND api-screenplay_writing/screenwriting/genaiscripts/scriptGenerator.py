from rest_framework import viewsets,status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.authentication import SessionAuthentication
from rest_framework.decorators import permission_classes, authentication_classes
from rest_framework.permissions import AllowAny
from ..models import GeneratedScene
from .serializers import ScriptSerializer
from services.src.session import Session
from datetime import datetime
import time
from django.db.models import Max
from scripts.messages import Messages
from scripts.enums import SceneType
import logging
logger = logging.getLogger("scripts_logger")


from .scene_generator import generate_scene

def get_next_scene_number():
        max_scene = GeneratedScene.objects.all().aggregate(max=Max('scene_number'))
        next_scene_number = max_scene['max'] + 1 if max_scene['max'] else 1
        return next_scene_number


class SceneGeneratorViewSet(viewsets.ViewSet):

    

    @action(detail=False, methods=['POST'])
    def generate(self, request):
 
        session = Session(request)
        tenant_id = session.get_tenant_id()
        user = session.get_user_id()
        characters = request.data.get('characters')
        location = request.data.get('location')
        scene_desc = request.data.get('scene_desc')
        props = request.data.get('props')
        mode_tone = request.data.get('mode_tone')
        key_details= request.data.get('key_details')
        dialogue_set = request.data.get('dialogue_set')
        
        scene_type=location["location_type"].title()
        scenetype_uid=SceneType[scene_type].value
        #print(scenetype_uid)

        
    
        start_time=time.time()

        try:   
            scene,dialogue_word_count,prompt_action,prompt_props,prompt_mode,prompt_key_details,scene_word_count,location_prompt = generate_scene(
                characters=characters,
                location=location,
                scene_desc=scene_desc,
                props=props,
                mode_tone=mode_tone,
                key_details=key_details,
                dialogue_set=dialogue_set
            )
        except Exception as e:
            logger.error(f'Unable to generate script: {e}')
            message, status = Messages.llmError.value
            return Response(e, status)

        end_time=time.time()
        next_scene_number=get_next_scene_number()

        data = {
        'scenetype_uid': scenetype_uid,
        'screenplay_version_uid': request.data.get('screenplay_version_uid'),
        'count_action': 0,
        'count_dialogues': len(dialogue_set),
        'generated_scene_text': scene,
        'scene_number': next_scene_number,
        'count_words_action': scene_word_count,
        'count_words_dialogues': dialogue_word_count,
        'prompt_time_of_day': "",  # You may need to set the actual value for this variable
        'prompt_location': location_prompt,
        'created_on': datetime.now(),
        'created_by': user,
        'modified_on': datetime.now(),
        'modified_by': user,
        'generation_time': int(end_time - start_time),
        'prompt_action': prompt_action,
        'prompt_props': prompt_props,
        'prompt_mode': prompt_mode,
        'prompt_plot_details': prompt_key_details
        }


        serializer = ScriptSerializer(data=data)

        if serializer.is_valid():
            instance=serializer.save()
            scene_uid=instance.scene_uid
            #message, status_code = "Script added successfully.", status.HTTP_200_OK
            #response_data = {"data": serializer.data}
            message, status = Messages.success.value
            return Response({"data": {"scene_uid":scene_uid, "scene_text":scene}}, status)
        else:
            #message, status_code = "Invalid data provided.", status.HTTP_400_BAD_REQUEST
            #response_data = {"errors": serializer.errors}
            logger.error(f'Unable to  insert data: {serializer.errors}')
            message, status = Messages.serialize_err.value
            return Response(message, status)





