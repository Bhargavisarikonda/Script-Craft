
import os
from langchain.chat_models import ChatOpenAI
import openai
from langchain.prompts import ChatPromptTemplate
from dotenv import load_dotenv, find_dotenv
_ = load_dotenv(find_dotenv()) # read local .env file
OPENAI_API_KEY = os.environ['OPENAI_API_KEY']

openai.api_key = OPENAI_API_KEY


def get_completion(prompt, model="gpt-3.5-turbo",  temperature=1):
    messages = [{"role": "user", "content": prompt}]
    response = openai.ChatCompletion.create(
        model=model,
        messages=messages,
        temperature=temperature, # this is the degree of randomness of the model's output
    )
    return response.choices[0].message["content"]

def get_completion_from_messages(messages, model="gpt-3.5-turbo", temperature=1):
    response = openai.ChatCompletion.create(
        model=model,
        messages=messages,
        temperature=temperature, # this is the degree of randomness of the model's output
    )
#     print(str(response.choices[0].message))
    return response.choices[0].message["content"]

def generate_scene(characters, location, scene_desc, props, mode_tone, dialogue_set,key_details):
    
    prompt,dialogue_word_count,prompt_action,prompt_props,prompt_mode,prompt_key_details,scene_word_count,location_prompt= construct_prompt(
        characters=characters,
        location=location,
        scene_desc=scene_desc,
        props=props,
        mode_tone=mode_tone,
        key_details=key_details, 
        dialogue_set=dialogue_set
    )
    
    #print("prompt ---------------------------------------")
    #print(prompt)
    #print("prompt ---------------------------------------")
    prompt_template = ChatPromptTemplate.from_template(prompt)
    #print("prompt template ---------------------------------------")
    #print(prompt_template)
    #print("prompt template ---------------------------------------")

    #scene = get_completion(prompt)

    prompt_message = prompt_template.format_messages(
                    location = location,
                    mode_tone = mode_tone,
                    characters = characters,
                    dialogue_set = dialogue_set,
                    props = props,
                    key_details=key_details,
                    scene_desc=scene_desc)
    messages=[
        {"role": "system", "content": "You are an expert screenplay writer in India"}
    ]

    #print("prompt message ---------------------------------------")
    #print(prompt_message)
    #print("prompt message ---------------------------------------")



    #response = chat(message)
    messages.append({'role':'user','content':f"{prompt_message}"})
    #print("message before result---------------------------------------")
    #print(messages)
    #print("message before result ---------------------------------------")

    response = get_completion_from_messages(messages)

    #print("response ---------------------------------------")
    #print(response)
    #print("response ---------------------------------------")

    messages.append({'role':'assistant', 'content':f"{response}"})

    #print("message after result---------------------------------------")
    #print(messages)
    #print("message after result ---------------------------------------")
    
    return response,dialogue_word_count,prompt_action,prompt_props,prompt_mode,prompt_key_details,scene_word_count,location_prompt

def get_char_string(characters):
    # This string is populated from "Character list" 
    
    char_list=[]
    for character in characters:
        char_list.append(character["name"])
    count_characters=len(characters)
    character_count_list = ", ".join(char_list)
    character_count_str =character_count_list
    #print(character_count_str)
    # This is populated from "Character Appearance/Features" under Action/Scene Description
    character_details_str = ""
    for i,char in enumerate(characters):
        character_details_str+=str(i+1)+". "+str(char['name'])+" - "+str(char['description'])+",\n"
    character_details_prompt = f"The following characters should be present in the scene -\n{character_count_str}\n" 
    if count_characters>0:
        character_details_prompt += f"Here are some additional details of the characters - \n{character_details_str}\n"
        
    return character_details_prompt


def get_diaolog_string(dialogue_set):
    
    dialogue_count = len(dialogue_set)
    dialogue_word_count=0
    # This is iteratively populated using "Dialogue Set" details.
    dialogue_details_list=[]
    for dialogue in dialogue_set:
        dialogue_details_list.append(dialogue["active"]+" and "+dialogue["passive"]+" - "+dialogue["details"])
        dialogue_word_count+=len(dialogue["details"].split())

    #dialogue_details_list = ["Pavan and Vinay - Pavan is Confronting Vinay", "Ajay and Pavan - Ajay is asking for mercy"]

    dialogue_details_str = "\n".join(dialogue_details_list)

    dialogue_details_prompt = f"There should be atleast {dialogue_count} dialogues. "

    if len(dialogue_details_str)>0:
        dialogue_details_prompt += f"Dialogues should be between the following:\n{dialogue_details_str}\n"

    #print(dialogue_details_prompt)

    return dialogue_details_prompt,dialogue_word_count

def get_location_prompt(location):
    location_info = location["location_type"]+" - "+location["location_description"]

    location_prompt = f"Here is the location for the scene: {location_info}.\n"
    #print(location_prompt)

    return location_prompt

def get_mode_tone_prompt(mode_tone):
    mode_tone_type=mode_tone["type"]
    if mode_tone_type.lower()=="auto":
        mode_tone_prompt=f"Select the best mode and tone for this scene. \n"
    else:
        mode_tone_prompt = f"Mode and Tone of scene - {mode_tone['description']}.\n"
    #print(mode_tone_prompt)
    return mode_tone_prompt

def get_props_prompt(props):
    #props = "20 feet standing fan and a helicopter"
    props_type=props["type"]
    if props_type.lower()=='auto':
        props_prompt=f"Select the best props for these characters and scene. \n\n"
    else:
        props_prompt = f"Use the following props in the scene only where necessary: {props['description']}.\n\n"

    #print(props_prompt)
    return props_prompt

def get_scene_description(scene_desc):
    scene_setting_type=scene_desc["type"]
    if scene_setting_type.lower()=="auto":
        scene_desc_prompt=f"Select the best scence description for these characters. \n"
    else:
        scene_desc_prompt = f"A brief description is given in the text that is delimited by triple backticks.\n\
                            text: ```{scene_desc['description']}```\n"
    scene_word_count=len(scene_desc_prompt.split())
    #print(scene_desc_prompt)

    return scene_desc_prompt,scene_word_count

def get_key_details_prompt(key_details):
    key_details_prompt = f"Here is the key details for the scene: {key_details}.\n"

    return key_details_prompt 




def construct_prompt(characters, location, scene_desc, props, mode_tone,key_details, dialogue_set):
   # prompt construction code

   character_details_prompt=get_char_string(characters)
   dialogue_details_prompt,dialogue_word_count=get_diaolog_string(dialogue_set)
   location_prompt=get_location_prompt(location)
   mode_tone_prompt=get_mode_tone_prompt(mode_tone)
   props_prompt=get_props_prompt(props)
   scene_desc_prompt,scene_word_count=get_scene_description(scene_desc)
   key_details_prompt=get_key_details_prompt(key_details)
   #print(scene_desc_prompt)

   prompt = """Write a scene, in a standard film script format that has a 3 act structure, containing all the necessary dialogues and actions, with the following details mentioned -\n\n"""\
        + location_prompt\
        + mode_tone_prompt\
        + character_details_prompt\
        + dialogue_details_prompt\
        + props_prompt\
        + scene_desc_prompt\
        + key_details_prompt\

   #print(prompt)

   return prompt,dialogue_word_count,scene_desc_prompt,props_prompt,mode_tone_prompt,key_details_prompt,scene_word_count,location_prompt
 


if __name__=="__main__":
    char=[{"name": "Ravi", "description":"Is a policemen"},{"name":"pooja","description":"she is a poor girl"}]
    dialogue_set=[{"active":"ravi","passive":"pooja","details":"ravi is proposing to pooja"},{"active":"pooja","passive":"ravi","details":"pooja is rejecting the proposal"}]
    location={"location_type":"outdoor", "location_description":"A garden with lot of trees"}
    mode_tone="intense drama"
    props="a red colour rose"
    scene_details="this scene is about proposing a girl"
    #char_des_check=construct_prompt(char,location,scene_details,props,mode_tone,dialogue_set)
    scene=generate_scene(char,location,scene_details,props,mode_tone,dialogue_set)
    print(scene)

