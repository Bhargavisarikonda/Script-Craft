from django.shortcuts import render
from rest_framework import viewsets,status
from rest_framework.decorators import action
from rest_framework.response import Response
from scripts.messages import Messages
from django.db import connections, transaction
from rest_framework.views import APIView
from rest_framework.response import Response
from .models import Test, Screenplay,ScreenplayVersion,Scene,Characters
from services.src.session import Session
from django.http import HttpResponseForbidden
from datetime import datetime
from .serializers import CharactersCreateSerializer,CharactersSerializer,SceneSerializer,SceneupdateSerializer,ScreenplaySerializer,ScreenplaySerializers
from django.http import Http404
from rest_framework.permissions import IsAuthenticated
from rest_framework.exceptions import AuthenticationFailed
from django.conf import settings
from scripts.enums import DbSchema
import base64
import logging
from scripts.enums import DbSchema
from .serializers import CreateScreenplayVersionSerializer
from django.db import transaction,IntegrityError
import random
from django.db import models
from django.utils import timezone

logger = logging.getLogger("scripts_logger")

# Create your views here.

class GetSecondSchema(viewsets.ViewSet):

    @action(detail=True, methods=["GET"])
    def getTest(self, request):
        uid = self.request.query_params.get("uid", 0)
        try:
            test = Test.objects.get(test_uid = uid )
            #print('test object ', test)
            message, status = Messages.success.value
            data = test.data
        except Test.DoesNotExist:
            #print('Test not found')
            message, status = Messages.notFound.value
            data = message
        
        return Response({"data": data},  status )


    @action(detail=True, methods=["GET"])
    def getScreenplay(self, request):
        screenplayuid = self.request.query_params.get("screenplayuid", 0)
        try:
            screenplay = Screenplay.objects.get(screenplay_uid = screenplayuid )
            logger.debug(f'Screenplay object: {screenplay}')
            message, status = Messages.success.value
            data = screenplay.title
        except Test.DoesNotExist:
            logger.error(f'screenplay not found: {screenplayuid}')
            message, status = Messages.notFound.value
            data = message
        
        return Response({"data": data}, status )
    


class ScreenplayViewSet(viewsets.ViewSet):

##  it will create a screenplay & screenplay version in the respective tables

    @action(detail=False, methods=["POST"])
    def create_screenplay(self, request):
        session = Session(request)
        user_id = session.get_user_id()
        if not session.is_userid_valid():
            return HttpResponseForbidden("User ID is not valid")
        data = request.data
        #logger.debug(f"request data: {data}")
        
        title = data['title']
            
        if data.get('language')==None:
            lang=1
        else:
            lang = data.get('language')
        
        try:
            with transaction.atomic(DbSchema.screenwriting.value):
                if data.get('avatar')==None:
                    sc_model = Screenplay(title=title, created_on=datetime.now(), created_by=user_id, \
                         modified_on=datetime.now(), user_uid=user_id, published=False)
                else:
                    avatar = data.get('avatar')
                    avatar_decoded = base64.b64decode(avatar)
                    sc_model = Screenplay(title=title, created_on=datetime.now(), created_by=user_id,  modified_on=datetime.now(),\
                        user_uid=user_id, published=False, avatar=avatar_decoded)
                sc_model.save()
                sc_ver_model = ScreenplayVersion(screenplay_uid=sc_model,version_id=1,created_by=user_id,created_on=datetime.now(),\
                    modified_on=datetime.now(), main_version=True,language_uid=lang)
                sc_ver_model.save()
                
        except Exception as e:
            return Response({"message": "An error occurred while creating screenplay: " + str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        message, status = Messages.screenplayCreated.value
        return Response({"message": message, "screenplay_uid":sc_model.screenplay_uid,"screenplay_version_uid":sc_ver_model.screenplay_version_uid}, status)

##  it will fetch the data from screenplay & screenplay version table based on the user id


    @action(detail=True, methods=['GET'])
    def get_screenplay_by_user(self, request):
        
        # Create a Session instance using the request
        session = Session(request)

        # Get the user ID from the session
        user_id = session.get_user_id()

        # Check if the user ID is valid
        if not session.is_userid_valid():
            return HttpResponseForbidden("User ID is not valid")

        queryset = Screenplay.objects.raw("""
            SELECT sc.screenplay_uid, sc.published, sv.screenplay_version_uid, sv.version_id, sv.main_version as main, sc.avatar as image, sc.title, sv.created_on
            FROM screenplay AS sc
            INNER JOIN screenplay_version AS sv
            ON sc.screenplay_uid = sv.screenplay_uid
            WHERE sc.user_uid = %s
            ORDER BY sv.screenplay_uid DESC, sv.main_version DESC;
        """, [user_id])

        screenplay_data = {}
        for row in queryset:
            # print(f"Avatar Data for screenplay_uid {row.screenplay_uid}: {row.image}")
            
            screenplay_uid = row.screenplay_uid
            if screenplay_uid not in screenplay_data:
                screenplay_data[screenplay_uid] = {
                    "screenplay_uid": screenplay_uid,
                    "public": row.published,
                    "versions": []
                }
            version_data = {
                "screenplay_version_uid": row.screenplay_version_uid,
                "version_id": row.version_id,
                "main": row.main,
                "image": row.image,  # Make sure 'image' is passed to the serializer
                "title": row.title,
                "created_on": row.created_on.strftime('%Y-%m-%d %H:%M:%S.%f')
            }
            screenplay_data[screenplay_uid]["versions"].append(version_data)

        formatted_data = list(screenplay_data.values())

        # print(f"Data for formatted_data before serialization: {formatted_data}")
        
        serializer = ScreenplaySerializer(formatted_data, many=True)
        
        # print(f"Serialized Data: {serializer.data}")
        message, status = Messages.success.value
        return Response({'data':serializer.data},status)
    




## it will fetch the data from screenplay & screenplay version table based on the screenplay_uid

    @action(detail=False, methods=['GET'])
    def get_screenplay_uid(self, request):
        screenplay_uid = self.request.query_params.get("screenplay_uid",None)
        

        if screenplay_uid is None:
            message, status = Messages.screenplayuidNotFound.value
            return Response(message, status)

        # Query both tables and check if screenplay_uid exists in each
        exists_in_screenplay = Screenplay.objects.filter(screenplay_uid=screenplay_uid).exists()
        exists_in_screenplay_version = ScreenplayVersion.objects.filter(screenplay_uid=screenplay_uid).exists()

        if not exists_in_screenplay and not exists_in_screenplay_version:
            message, status = Messages.screenplayNotFound.value
            return Response(message, status)
        
        elif exists_in_screenplay != exists_in_screenplay_version:
            message, status = Messages.sqlerror.value
            return Response({"message": "The screenplay_uid is not matched"}, status)

        queryset = Screenplay.objects.raw("""
            select sc.screenplay_uid, sc.published, sv.screenplay_version_uid, sv.version_id, sv.main_version as main, sc.avatar as image, sc.title, sv.created_on
            from screenplay as sc
            inner join screenplay_version as sv
            on sc.screenplay_uid = sv.screenplay_uid
            where sc.screenplay_uid = %s
            order by sv.screenplay_uid desc, sv.main_version desc;
        """, [screenplay_uid])

        screenplay_data = {}
        for row in queryset:
            screenplay_uid = row.screenplay_uid
            if screenplay_uid not in screenplay_data:
                screenplay_data[screenplay_uid] = {
                    "screenplay_uid": screenplay_uid,
                    "public": row.published,
                    "versions": []
                }
            version_data = {
                "screenplay_version_uid": row.screenplay_version_uid,
                "version_id": row.version_id,
                "main": row.main,
                "image": row.image,
                "title": row.title,
                "created_on": row.created_on.strftime('%Y-%m-%d %H:%M:%S.%f')
            }
            screenplay_data[screenplay_uid]["versions"].append(version_data)

        formatted_data = list(screenplay_data.values())

        serializer = ScreenplaySerializer(formatted_data, many=True)

        if not formatted_data:
            message, status = Messages.screenplayNotFound.value
            return Response(message, status)
        else:
            message, status = Messages.success.value
            return Response(serializer.data,status)



##  It will delete the data in a screenplay_version table based on screenplay_version_uid. If its the last screenplay version,
##  then delete screenplay as well.

    @action(detail=True, methods=["DELETE"])
    def destroy_screenplay_version(self, request):
        screenplay_version_uid = request.data.get('screenplay_version_uid', None)
        if screenplay_version_uid is None:
            message, status = Messages.screenplayversionuidNotFound.value
            return Response(message, status)

        try:
            Screenplay_version = ScreenplayVersion.objects.get(screenplay_version_uid=screenplay_version_uid)
            scenes = Scene.objects.filter(screenplay_version_uid=screenplay_version_uid)
            screenplay_uid = Screenplay_version.screenplay_uid.screenplay_uid
            logger.debug(f"screenplay uid : {screenplay_uid}")
        except Exception as e:
            logger.error(f"Error in delete version: {e}")
            message, status = Messages.versionDeleteFailed.value
            return Response(message, status)

        # Check whether it is the last screenplay version. If so, delete the parent row in screenplay table as well.
        #count = Screenplay.objects.filter(screenplay_uid=screenplay_uid).filter(ScreenplayVersion.screenplay_uid).count()
        count = ScreenplayVersion.objects.select_related('screenplay_uid').filter(screenplay_uid=screenplay_uid).count()
        logger.debug(f"count : {count}")

        # Only screenplay version for the screenplay uid
        
        with transaction.atomic(DbSchema.screenwriting.value):
            if count == 1:
                scenes.delete()
                Screenplay_version.delete()
                screenplay = Screenplay.objects.filter(screenplay_uid=screenplay_uid)
                #raise Exception("forced error")
                screenplay.delete()
            else:
                scenes.delete()
                Screenplay_version.delete()
        
        
        message, status = Messages.versionDeleted.value
        logger.debug(f"delete success : {message}")
        return Response({"message":message}, status) 



##  It will delete screenplay and all its versions.

    @action(detail=True, methods=["DELETE"])
    def delete_screenplay(self, request):
        screenplay_version_uid = request.data.get('screenplay_version_uid', None)
        if screenplay_version_uid is None:
            message, status = Messages.screenplayversionuidNotFound.value
            return Response(message, status)

        try:
            Screenplay_version = ScreenplayVersion.objects.get(screenplay_version_uid=screenplay_version_uid)
            screenplay_uid = Screenplay_version.screenplay_uid.screenplay_uid
            logger.debug(f"screenplay uid : {screenplay_uid}")
        except ScreenplayVersion.DoesNotExist:
            message, status = Messages.screenplayVersionNotFound.value
            return Response(message, status)

        # Check whether it is the last screenplay version. If so, delete the parent row in screenplay table as well.
        #count = Screenplay.objects.filter(screenplay_uid=screenplay_uid).filter(ScreenplayVersion.screenplay_uid).count()
        count = ScreenplayVersion.objects.select_related('screenplay_uid').filter(screenplay_uid=screenplay_uid).count()
        logger.debug(f"count : {count}")

        # Only screenplay version for the screenplay uid
        if count == 1:
            with transaction.atomic(DbSchema.screenwriting.value):
                Screenplay_version.delete()
                screenplay = Screenplay.objects.filter(screenplay_uid=screenplay_uid)
                #raise Exception("forced error")
                screenplay.delete()
        else:
            Screenplay_version.delete()
        
        
        message, status = Messages.deleteSuccess.value
        return Response(message, status) 


## It will update the published column in screenplay table based on screenplay_uid and screenplay_version_uid 

    @action(detail=True, methods=["PUT"])
    def update_published_status(self, request):
        screenplay_uid = request.data.get('screenplay_uid')
        screenplay_version_uid = request.data.get('screenplay_version_uid')
        published = request.data.get('published')

        # Check if screenplay_uid exists
        try:
            screenplay = Screenplay.objects.get(screenplay_uid=screenplay_uid)
        except Screenplay.DoesNotExist:
            message, status = Messages.notFound.value
            return Response({'message': 'Screenplay_uid does not exist'}, status)

        # Check if screenplay_version_uid exists for the provided screenplay_uid
        try:
            screenplay_version_uid = ScreenplayVersion.objects.get(screenplay_uid=screenplay_uid, screenplay_version_uid=screenplay_version_uid)
        except ScreenplayVersion.DoesNotExist:
            message, status = Messages.notFound.value
            return Response({'message': 'Screenplay_version_uid does not exist for the provided Screenplay_uid'}, status)
       
       # Convert 'y' to True and 'n' to False for the published field
        published_value = True if published.lower() == 'y' else False

        # Update the published status if both exist
        screenplay.published = published_value
        screenplay.modified_on = datetime.now()
        screenplay.save()
        message , status_code = Messages.success.value

        return Response({'message': message}, status=status_code)



##  It will update the Main version column in screenplay_version table based on screenplay_uid and screenplay_version_uid

    @action(detail=True, methods=["PUT"])
    def update_mainpublished_status(self, request):
        screenplay_uid = request.data.get('screenplay_uid')
        screenplay_version_uid = request.data.get('screenplay_version_uid')
        main_version_value = request.data.get('main_version', None)

        # Check if screenplay_uid exists
        try:
            screenplay = Screenplay.objects.get(screenplay_uid=screenplay_uid)
        except Screenplay.DoesNotExist:
            message, status = Messages.screenplayNotFound.value
            return Response(message, status)

        # Check if screenplay_version_uid exists for the provided screenplay_uid
        try:
            screenplay_version = ScreenplayVersion.objects.get(screenplay_uid=screenplay_uid, screenplay_version_uid=screenplay_version_uid)
        except ScreenplayVersion.DoesNotExist:
            message, status = Messages.screenplayVersionNotFound.value
            return Response(message, status)
        
        if screenplay.published == True:
            message, status = Messages.notPrivate.value
            return Response(message,status)
        else:
            # Update main_version using queryset
            ScreenplayVersion.objects.filter(screenplay_uid=screenplay_uid).update(main_version=False)
        
            # Set main_version to True for the specified screenplay_version_uid
            ScreenplayVersion.objects.filter(screenplay_uid=screenplay_uid, screenplay_version_uid=screenplay_version_uid).update(main_version=True if main_version_value.lower() == 'y' else False)
            message , status = Messages.success.value
            return Response(message, status)


##  It will fetch the data in different table based on where condition Published = True , Main version = True   by (TOP VIEW pagination)


    @action(detail=False, methods=['GET'])
    def topview_screenplays(self, request):
        # Get the values for page_size, offset, and category from the request
        # default_page_size = 10
        # default_offset = 0

        page_size = int(request.data.get('page_size', settings.DEFAULT_PAGE_SIZE))
        offset = int(request.data.get('offset', settings.DEFAULT_OFFSET))
        category = request.data.get('category', None)

        queryset = Screenplay.objects.raw("""
            SELECT
                sc.screenplay_uid, sc.title, s.scene_number AS scene_count, sc.views,sc.user_uid as writer_uid,
                CONCAT(au.first_name, ' ', au.last_name) AS writer,
                au.email AS writer_email, pr.avatar AS writer_avatar,
                sv.plot_summary, sv.genre, sc.avatar as screenplay_image, sc.created_on AS timestamp,
                sc.file_path
            FROM screenplay AS sc
            LEFT JOIN screenplay_version AS sv
            ON sc.screenplay_uid = sv.screenplay_uid
            LEFT JOIN scene AS s
            ON s.screenplay_version_uid = sv.screenplay_version_uid
            LEFT JOIN auth_user AS au
            ON au.id = sc.user_uid
            LEFT JOIN profile AS pr
            ON pr.user_uid = au.id
            WHERE sc.published = True and sv.main_version = True
            ORDER BY sc.views DESC
            LIMIT %s OFFSET %s
        """, [page_size, offset])

        serializer = ScreenplaySerializers(queryset, many=True)
        message, status = Messages.success.value
        return Response({'result': serializer.data}, status)
    

    
##  It will fetch the data in different table based on where condition Published = True , Main version = True   by (pagination).
##  Public screenplays.


    @action(detail=False, methods=['GET'])
    def get_published_screenplays(self, request):
        # Get the values for page_size, offset, and category from the request
        # default_page_size = 10
        # default_offset = 0

        page_size = int(request.data.get('page_size', settings.DEFAULT_PAGE_SIZE))
        offset = int(request.data.get('offset', settings.DEFAULT_OFFSET))

        queryset = Screenplay.objects.raw("""
            SELECT
                sc.screenplay_uid, sc.title, count(s.scene_number) AS scene_count, sc.views,sc.user_uid as writer_uid,
                CONCAT(au.first_name, ' ', au.last_name) AS writer,
                au.email AS writer_email, pr.avatar AS writer_avatar,
                sv.plot_summary, sv.genre, sc.avatar as screenplay_image, sc.modified_on AS timestamp,
                sc.file_path
            FROM screenplay AS sc
            LEFT JOIN screenplay_version AS sv
            ON sc.screenplay_uid = sv.screenplay_uid
            LEFT JOIN scene AS s
            ON s.screenplay_version_uid = sv.screenplay_version_uid
            LEFT JOIN auth_user AS au
            ON au.id = sc.user_uid
            LEFT JOIN profile AS pr
            ON pr.user_uid = au.id
            WHERE sc.published = True and sv.main_version = True
            group by sc.screenplay_uid, sc.title, sc.views, writer, writer_email, writer_avatar,
                sv.plot_summary, sv.genre, screenplay_image, timestamp   
            order by sc.modified_on desc                      
            LIMIT %s OFFSET %s
        """, [page_size, offset])

        serializer = ScreenplaySerializers(queryset, many=True)
        message, status = Messages.success.value
        return Response({'result': serializer.data}, status)



################### It will retireve the data based on writer_uid ########################################

    @action(detail=False, methods=['GET'])
    def author_screenplay(self, request):
        # Get the values for page_size, offset, and writer_uid from the request
        page_size = int(self.request.query_params.get('page_size', settings.DEFAULT_PAGE_SIZE))
        offset = int(self.request.query_params.get('offset', settings.DEFAULT_OFFSET))
        writer_uid = self.request.query_params.get("writer_uid",None)

        if writer_uid is None:
            message, status = Messages.writeridNotFound.value
            return Response( message, status)
        queryset = Screenplay.objects.raw("""
            SELECT
                sc.screenplay_uid, sc.title, count(s.scene_number) AS scene_count, sc.views,sc.user_uid as writer_uid,
                CONCAT(au.first_name, ' ', au.last_name) AS writer,
                au.email AS writer_email, pr.avatar AS writer_avatar,
                sv.plot_summary, sv.genre, sc.avatar as screenplay_image, sc.modified_on AS timestamp
            FROM screenplay AS sc
            LEFT JOIN screenplay_version AS sv
            ON sc.screenplay_uid = sv.screenplay_uid 
            LEFT JOIN scene AS s
            ON s.screenplay_version_uid = sv.screenplay_version_uid
            LEFT JOIN auth_user AS au
            ON au.id = sc.user_uid
            LEFT JOIN profile AS pr
            ON pr.user_uid = au.id
            WHERE sc.published = True and sv.main_version = True and sc.user_uid = %s
            group by sc.screenplay_uid, sc.title, sc.views, writer, writer_email, writer_avatar,
                sv.plot_summary, sv.genre, screenplay_image, timestamp
            order by sc.modified_on desc
            LIMIT %s OFFSET %s
        """, [writer_uid, page_size, offset])

        if not queryset:
            # If no results are found, return a "not found" message
            message, status = Messages.authorNotFound.value
            return Response(message, status)

        serializer = ScreenplaySerializers(queryset, many=True)
        message, status = Messages.success.value
        return Response(serializer.data, status)


## It will create a new row in the screenplay_version table and copy & paste the scenes based on provided screenplay_version_uid in scene table 


    @action(detail=False, methods=['POST'])
    def create_screenplay_version(self, request):
        data = request.data
        
        session = Session(request)
        user_id = session.get_user_id()

        # Validate that screenplay_uid is provided
        screenplay_uid = data.get('screenplay_uid')
        if not screenplay_uid:
            message, status = Messages.screenplayuidNotFound.value
            return Response(message , status)

        try:
            screenplay = Screenplay.objects.get(screenplay_uid=screenplay_uid)
        except Screenplay.DoesNotExist:
            message, status = Messages.screenplayNotFound.value
            return Response(message, status)

        screenplay_version_uid = data.get('screenplay_version_uid')
        if not screenplay_version_uid:
            message, status = Messages.screenplayversionuidNotFound.value
            return Response(message , status)

        
        # Check if screenplay_version_uid exists for the provided screenplay_uid
        try:
            screenplay_version = ScreenplayVersion.objects.get(screenplay_uid=screenplay_uid, screenplay_version_uid=screenplay_version_uid)
        except ScreenplayVersion.DoesNotExist:
            message, status = Messages.screenplayVersionNotFound.value
            return Response(message, status)
    
        if screenplay_version_uid:
            # Check if the provided screenplay_version_uid exists for the given screenplay_uid

            data['plot_summary'] = screenplay_version.plot_summary
            data['language_uid'] = screenplay_version.language_uid
            data['genre'] = screenplay_version.genre

            # Get the max version_id for the given screenplay_uid and increment by 1
            max_version_id = ScreenplayVersion.objects.filter(screenplay_uid=screenplay_uid).aggregate(max_version=models.Max('version_id'))['max_version']
            version_id = max_version_id + 1 if max_version_id is not None else 1


            try:
                with transaction.atomic(DbSchema.screenwriting.value):
                    # Create a new screenplay version
                    data['version_id'] = version_id  
                    data['main_version'] = False
                    data['created_on'] = datetime.now()
                    data['modified_on'] = datetime.now()
                    data['created_by'] = user_id  
                    data['modified_by'] = user_id  
                    data['process_time'] = None  # Set to null
                    data['failure_reason'] = None  # Set to null
                    data['status'] = None  # Set to null

                    serializer = CreateScreenplayVersionSerializer(data=data)
                    if serializer.is_valid():
                        # Save the new screenplay version only if scenes are found
                        new_screenplay_version = serializer.save()
                        # Copy records from original_scenes to new scenes with the new screenplay_version_uid
                        original_scenes = Scene.objects.filter(screenplay_version_uid=screenplay_version.screenplay_version_uid)

                        if original_scenes.exists():                        
                            # ii=0                            
                            for original_scene in original_scenes:
                                # ii+=1
                                # if ii>3:
                                #     # a = 1/0
                                #     raise Exception ('simulating error')


                                # Create a new copy of the scene
                                new_scene = Scene.objects.create(
                                    screenplay_version_uid=new_screenplay_version.screenplay_version_uid,
                                    scenetype_uid=original_scene.scenetype_uid,
                                    count_action=original_scene.count_action,
                                    count_dialogues=original_scene.count_dialogues,
                                    generated_scene_text=original_scene.generated_scene_text,
                                    scene_number=original_scene.scene_number,
                                    count_words_action=original_scene.count_words_action,
                                    count_words_dialogues=original_scene.count_words_dialogues,
                                    prompt_time_of_day=original_scene.prompt_time_of_day,
                                    prompt_location=original_scene.prompt_location,
                                    created_on=datetime.now(),
                                    created_by=user_id,
                                    modified_on=datetime.now(),
                                    modified_by=user_id,
                                    generation_time=original_scene.generation_time,
                                    prompt_action=original_scene.prompt_action,
                                    prompt_props=original_scene.prompt_props,
                                    prompt_mode=original_scene.prompt_mode,
                                    prompt_plot_details=original_scene.prompt_plot_details,
                                    image=original_scene.image,
                                )

                    else:
                        message, status = Messages.sqlerror.value
                        logger.error(f"Duplication of scenes failed for screenplay version: {screenplay_version_uid}; error: {serializer.errors}")
                        return Response(serializer.errors, status)

            except Exception as e:

                message, status = Messages.sqlerror.value
                logger.error(f"SQL error during creation of new version for screenplay; {screenplay_uid}: error is {e}")
                return Response( str(e), status)

            message, status = Messages.screenplayVersionCreated.value
            return Response({"message": message, "data":serializer.data}, status)




####################################################    CHARACTER API's   ############################################################################



class CharactersViewSet(viewsets.ViewSet):


##  It will fecth all the data from a characters table

    @action(detail=True, methods=["GET"])
    def list(self, request):
        # You can keep the queryset and serializer as it is
        queryset = Characters.objects.all()
        serializer = CharactersSerializer(queryset, many=True)

        try:
            data = serializer.data
            message, status = Messages.success.value
        except Characters.DoesNotExist:
            message, status = Messages.charactersNotFound.value
            data = message

        return Response({"data": data}, status)


##  It will create a character in a charater table

    @action(detail=False, methods=["POST"])
    def create(self, request):
        session = Session(request)
        user_id = session.get_user_id()

        data = request.data
        data['created_by'] = user_id
        data['modified_by'] = user_id

        serializer = CharactersCreateSerializer(data=data)

        if serializer.is_valid():
            serializer.save()
            message, status = Messages.insertSuccess.value
            response_data = {"data": serializer.data}
        else:
            message, status = Messages.unexpectedError.value
            logger.error(f"Error in creating character: {serializer.errors }")
            response_data = message
        return Response(response_data, status)



##  It will update the character

    @action(detail=True, methods=["PUT"])
    def update(self, request):
        character_uid = request.data.get('character_uid', None)
        if character_uid is None:
            message, status = Messages.sqlerror.value
            return Response({"message": "character_uid is required in the request body"}, status)

        try:
            character = Characters.objects.get(character_uid=character_uid)
        except Characters.DoesNotExist:
            message, status = Messages.notFound.value
            return Response({"message": "Character not found"}, status)

        session = Session(request)
        user_id = session.get_user_id()

        # Fetch the modified_by field from the session
        modified_by = user_id

        # Exclude created_by from the request data
        request.data.pop('created_by', None)

        # Set the modified_by field
        request.data['modified_by'] = modified_by

        # serializer = CharactersUpdateSerializer(character, data=request.data)
        serializer = CharactersSerializer(character, data=request.data)


        if serializer.is_valid():
            serializer.save()
            message, status = Messages.success.value
            return Response(serializer.data,status)
        # return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST) 



##  it will delete the character from a characters table

    @action(detail=True, methods=["DELETE"])
    def destroy(self, request):
        character_uid = request.data.get('character_uid', None)
        if character_uid is None:
            message, status = Messages.sqlerror.value
            return Response({"message": "character_uid is required in the request body"}, status)

        try:
            character = Characters.objects.get(character_uid=character_uid)
        except Characters.DoesNotExist:
            message, status = Messages.notFound.value
            return Response({"message": "Character not found"}, status)

        character.delete()
        message, status = Messages.characterDeleted.value
        return Response({"message": message},status)



##  It will fetch the data based on character_uid in a character table
    
    @action(detail=True, methods=["GET"])
    def character_action(self, request):
        if request.method == 'GET':
            character_uid = self.request.query_params.get("character_uid",None)

            if character_uid is None:
                message, status = Messages.characteruidNotFound.value
                return Response(message, status)

            try:
                character = Characters.objects.get(character_uid=character_uid)
                serializer = CharactersSerializer(character)
                message, status = Messages.success.value
                return Response(serializer.data,status)
            except Characters.DoesNotExist:
                message, status = Messages.charactersNotFound.value
                return Response(message, status)




##  It will fetch the data based on screenplay_version_uid in a character table

    @action(detail=True, methods=["GET"])
    def characterlist(self, request):
        if request.method == 'GET':
            screenplay_version_uid = self.request.query_params.get("screenplay_version_uid",None)
            
            if screenplay_version_uid is None:
                message, status = Messages.screenplayversionuidNotFound.value
                return Response(message, status)

            characters = Characters.objects.filter(screenplay_version_uid=screenplay_version_uid)

            if characters.exists():
                serializer = CharactersSerializer(characters, many=True)
                message, status = Messages.success.value
                return Response(serializer.data,status)
            else:
                message, status = Messages.charactersNotFound.value
                return Response(message, status)










##################################################   Scene   API's   ######################################################################


class SceneViewSet(viewsets.ViewSet):

## It will fetch the data in a scene table based on scene_uid


    @action(detail=True, methods=["GET"])
    def retrieve_scene(self, request):
        if request.method == 'GET':
            scene_uid = self.request.query_params.get("scene_uid",None)
            
            if scene_uid is None:
                message, status = Messages.sceneuidNotFound.value
                return Response(message, status)

            try:
                scene = Scene.objects.get(scene_uid=scene_uid)
                serializer = SceneSerializer(scene)
                message, status = Messages.success.value
                return Response(serializer.data,status)
            except Scene.DoesNotExist:
                message, status = Messages.sceneNotFound.value

                return Response(message, status)



##  It will fetch all the data in a scene table based on screenplay_version_uid

    @action(detail=True, methods=["GET"])
    def retrieve_scenes_list(self, request):
        if request.method == 'GET':
            screenplay_version_uid = self.request.query_params.get("screenplay_version_uid",None)

            if screenplay_version_uid is None:
                message, status = Messages.screenplayversionuidNotFound.value
                return Response(message, status)

            # try:
            scenes = Scene.objects.filter(screenplay_version_uid=screenplay_version_uid)
            if scenes.exists():
                serializer = SceneSerializer(scenes, many=True)
                message, status = Messages.success.value
                return Response(serializer.data, status)
            else:
                message, status = Messages.sceneNoNotFound.value
                return Response({"data":message}, status)

##  It will edit the generated text in a scene table

    @action(detail=True, methods=["PUT"])
    def update_scene_text(self, request):
        scene_uid = request.data.get('scene_uid', None)
        generated_scene_text = request.data.get('generated_scene_text', None)

        if scene_uid is None:
            message, status = Messages.sqlerror.value
            return Response({"message": "scene_uid is required in the request body"}, status)
        elif generated_scene_text is None:
            message, status = Messages.sqlerror.value
            return Response({"message": "generated_scene_text is required in the request body"}, status)


        try:
            scene = Scene.objects.get(scene_uid=scene_uid)
        except Scene.DoesNotExist:
            message, status = Messages.notFound.value
            return Response({"message": "Scene not found"}, status)

        session = Session(request)
        user_id = session.get_user_id()

        # Fetch the modified_by field from the session
        modified_by = user_id

        # Update the scene's generated_scene_text field
        scene.generated_scene_text = generated_scene_text

        # Set the modified_by field
        scene.modified_on = datetime.now()
        scene.modified_by = modified_by

        # Save the changes to the scene
        scene.save()

        serializer = SceneupdateSerializer(scene)
        message, status = Messages.updateSuccess.value

        return Response(serializer.data,status)


## It will delete the data in a scene table based on scene_uid


    @action(detail=True, methods=["DELETE"])
    def destroy_scene(self, request):
        scene_uid = request.data.get('scene_uid', None)
        if scene_uid is None:
            message, status = Messages.sqlerror.value
            return Response({"message": "scene_uid is required in the request body"}, status)

        try:
            scene = Scene.objects.get(scene_uid=scene_uid)
        except Scene.DoesNotExist:
            message, status = Messages.notFound.value
            return Response({"message": "scene not found"}, status)

        scene.delete()
        message, status = Messages.sceneDeleted.value
        return Response({"message": message},status)



class Screenplayupdate(viewsets.ViewSet):
########################  It will update  the attributes based on the screenplay_uid and screenplay_version_uid  ##################

    @action(detail=True, methods=["PUT"])
    def update_screenplay_attributes(self, request):
        screenplay_uid = request.data.get('screenplay_uid', None)
        screenplay_version_uid = request.data.get('screenplay_version_uid', None)
        attributes = request.data.get('attributes', None)

        if not screenplay_uid:
            message, status = Messages.screenplayuidNotFound.value
            return Response(message, status)
        elif not screenplay_version_uid:
            message, status = Messages.screenplayversionuidNotFound.value
            return Response(message, status)
        elif not attributes:
            message, status = Messages.attributesNotFound.value
            return Response(message, status)

        try:
            screenplay = Screenplay.objects.get(screenplay_uid=screenplay_uid)
        except Screenplay.DoesNotExist:
            message, status = Messages.screenplayNotFound.value
            return Response(message, status)

        try:
            screenplay_version = ScreenplayVersion.objects.get(screenplay_version_uid=screenplay_version_uid, screenplay_uid=screenplay_uid)
        except ScreenplayVersion.DoesNotExist:
            message, status = Messages.screenplayVersionNotFound.value
            return Response(message, status)
        


        update_screenplay = False
        update_screenplay_version = False

        for attrib in attributes:
            attrib_type = attrib.get('attrib_type', None)
            attrib_value = attrib.get('attrib_value', None)

            if attrib_type == 'title':
                screenplay.title = attrib_value
                update_screenplay = True
            elif attrib_type == 'avatar':
                try:
                    avatar_bytea = base64.b64decode(attrib_value)
                    screenplay.avatar = avatar_bytea
                    update_screenplay = True
                except Exception as e:
                    logger.error(f"Attribute update error in screenplay: {e}")
                    message, status = Messages.BaseException.value
                    return Response(message, status)
                

            elif attrib_type == 'genre':
                screenplay_version.genre = attrib_value
                update_screenplay_version = True

            else:
                message, status = Messages.attributesNotFound.value
                return Response(message, status)

        session = Session(request)
        user_id = session.get_user_id()
            

        if update_screenplay:
            # Update modified_on and modified_by for screenplay
            screenplay.modified_on = datetime.now()
            screenplay.modified_by = user_id
            screenplay.save()

        if update_screenplay_version:
            # Update modified_on and modified_by for screenplay_version
            screenplay_version.modified_on = datetime.now()
            screenplay_version.modified_by = user_id
            screenplay_version.save()

        

        message, status = Messages.updateSuccess.value
        return Response(message, status)