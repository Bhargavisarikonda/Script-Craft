from django.urls import path
from django.conf.urls import include
#from .views import sceneApi
from . import views
from rest_framework.decorators import permission_classes, authentication_classes
from rest_framework.permissions import AllowAny
from rest_framework.routers import DefaultRouter
from .views import ScreenplayViewSet, CharactersViewSet, GetSecondSchema, SceneViewSet, Screenplayupdate
from . import explore
from .genaiscripts.scriptGenerator import SceneGeneratorViewSet
from .search.search import SearchViewSet

router = DefaultRouter(trailing_slash=False)
endpoint_prefix = 'screenwriting/'


urlpatterns = [
    path('secondschema/test', authentication_classes([])(permission_classes([AllowAny])(views.GetSecondSchema)).as_view({'get':'getTest'}), name='getsecondschemafortest'),
    path('secondschema/screenplay', authentication_classes([])(permission_classes([AllowAny])(views.GetSecondSchema)).as_view({'get':'getScreenplay'}), name='getScreenplay'),
    

    path(endpoint_prefix + 'screenplaylist', ScreenplayViewSet.as_view({'get':'get_screenplay_by_user'}) , name='get_screenplay_by_user'),
    path(endpoint_prefix + 'screenplay', ScreenplayViewSet.as_view({'delete':'delete_screenplay','get':'get_screenplay_uid'}) , name='screenplay operations'),
    path(endpoint_prefix + 'screenplayversion', ScreenplayViewSet.as_view({'delete':'destroy_screenplay_version'}) , name='deletescreenplayversion'),
    path(endpoint_prefix + 'screenplaycreate', ScreenplayViewSet.as_view({'post':'create_screenplay'}) , name='create_screenplay'),
    path(endpoint_prefix + 'makepublic', ScreenplayViewSet.as_view({'put':'update_published_status'}) , name='Update published'),
    path(endpoint_prefix + 'makemain', ScreenplayViewSet.as_view({'put':'update_mainpublished_status'}) , name='Update main'),


    path(endpoint_prefix + 'topviewscreenplay', ScreenplayViewSet.as_view({'get':'topview_screenplays'}) , name='get_topview_screenplays'),
    path(endpoint_prefix + 'publishedscreenplays', ScreenplayViewSet.as_view({'get':'get_published_screenplays'}) , name='get_published_screenplays'),
    path(endpoint_prefix + 'createversion', ScreenplayViewSet.as_view({'post':'create_screenplay_version'}) , name='create_screenplay_version'),
    path(endpoint_prefix + 'authorscreenplay', ScreenplayViewSet.as_view({'get':'author_screenplay'}) , name='get_author_screenplays'),


    path(endpoint_prefix + 'character', CharactersViewSet.as_view({'post':'create','get':'character_action','put':'update','delete': 'destroy'}) , name='character operations'),
    path(endpoint_prefix + 'characterlistall', CharactersViewSet.as_view({'get':'list'}) , name='get all characters'),
    path(endpoint_prefix + 'characterlistscreenplay',  CharactersViewSet.as_view({'get':'characterlist'}) , name='get characters for screenplay'),

    path(endpoint_prefix + 'screenplayattribs', Screenplayupdate.as_view({'put': 'update_screenplay_attributes'}), name='update_attribs'),



    path(endpoint_prefix + 'scene', SceneViewSet.as_view({'put':'update_scene_text', 'get':'retrieve_scene', 'delete':'destroy_scene'}) , name='updatescene'),
    path(endpoint_prefix + 'scenes', SceneViewSet.as_view({'get':'retrieve_scenes_list'}) , name='getallscenes'),

    # path(endpoint_prefix + 'publishedscreenplays', authentication_classes([])(permission_classes([AllowAny])(ScreenplayViewSet)).as_view({'get':'list'}) , name='screenplay-data-list'),

    # path(endpoint_prefix + 'publishedscreenplays', authentication_classes([])(permission_classes([AllowAny])(ScreenplayViewSet)).as_view({'get':'list'}) , name='screenplay-data-list'),
    # path(endpoint_prefix + 'character', authentication_classes([])(permission_classes([AllowAny])(CharactersViewSet)).as_view({'post':'create','get':'character_action','put':'update','delete': 'destroy'}) , name='save_character'),
    # path(endpoint_prefix + 'characterlistall', authentication_classes([])(permission_classes([AllowAny])( CharactersViewSet)).as_view({'get':'list'}) , name='getcharacters'),
    # path(endpoint_prefix + 'characterlistscreenplay', authentication_classes([])(permission_classes([AllowAny])( CharactersViewSet)).as_view({'get':'characterlist'}) , name='getcharacters'),
    path(endpoint_prefix + 'explore', authentication_classes([])(permission_classes([AllowAny])(explore.Explore)).as_view({'post': 'add_rows'}), name='explore'),
    path(endpoint_prefix + 'generatescene', SceneGeneratorViewSet.as_view({'post': 'generate'}),name='script'),
    path(endpoint_prefix + 'search', SearchViewSet.as_view({'get': 'search_fields'}),name='search'),
    ]
