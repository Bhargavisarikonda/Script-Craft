from django.db import models
from django.contrib.postgres.fields import ArrayField

# Create your models here.

class Test(models.Model):
    test_uid = models.AutoField(primary_key=True)
    data = models.TextField()

    class Meta:
        managed = False
        db_table = 'test'
        #app_label = 'screenwriting'


#class Screenplay(models.Model):
#    screenplay_uid = models.BigAutoField(primary_key=True)
#    title = models.TextField()
#    success_percentage = models.FloatField()
#    ip_address = models.TextField()
#    geo_location = models.TextField()
#    status = models.TextField()
#    file_path = models.TextField()
#    file_size = models.IntegerField()
#    user_uid = models.BigIntegerField()
#    created_on = models.DateTimeField(auto_now_add=True)
#    modified_on = models.DateTimeField(auto_now_add=True)
#    created_by = models.BigIntegerField()
#    modified_by = models.BigIntegerField()
#    language_uid = models.SmallIntegerField()
#    #tenant_uid = models.ForeignKey(Tenant, on_delete=models.RESTRICT, to_field='tenant_uid', db_column='tenant_uid')
#    process_time = models.BigIntegerField()
#   failure_reason = models.TextField()
#
#    class Meta:
#       managed = False
#       db_table = 'screenplay'
  

class Screenplay(models.Model):
    screenplay_uid = models.BigAutoField(primary_key=True)
    title = models.TextField()
    # success_percentage = models.FloatField()
    ip_address = models.TextField()
    geo_location = models.TextField()
    # status = models.CharField()
    file_path = models.TextField()
    file_size = models.IntegerField()
    user_uid = models.BigIntegerField()
    created_on = models.DateTimeField(auto_now_add=True)
    modified_on = models.DateTimeField(auto_now=True)
    created_by = models.BigIntegerField()
    modified_by = models.BigIntegerField()
    # language_uid = models.SmallIntegerField()
    # tenant_uid = models.ForeignKey(Tenant, on_delete=models.RESTRICT, to_field='tenant_uid', db_column='tenant_uid')
    tenant_uid = models.IntegerField()
    # process_time = models.BigIntegerField()
    # failure_reason = models.CharField()
    published = models.BooleanField()
    avatar = models.BinaryField()
    paid = models.BooleanField()
    price = models.FloatField()
    views = models.IntegerField()
    
    

    class Meta:
        managed = False
        db_table = 'screenplay'


class ScreenplayVersion(models.Model):
    screenplay_version_uid = models.BigAutoField(primary_key=True)
    screenplay_uid = models.ForeignKey(Screenplay, on_delete=models.RESTRICT, to_field='screenplay_uid', db_column='screenplay_uid')
    version_id = models.BigIntegerField()
    plot_summary = models.TextField()
    main_version = models.BooleanField()
    status = models.TextField()
    failure_reason = models.TextField()
    language_uid = models.IntegerField()
    process_time = models.BigIntegerField()
    created_on = models.DateTimeField()
    created_by = models.BigIntegerField()
    modified_on = models.DateTimeField()
    modified_by = models.BigIntegerField()
    # genre = models.TextField()
    genre = ArrayField(models.TextField())    

    class Meta:
        managed = False
        db_table = 'screenplay_version'


class Scene(models.Model):
    scene_uid = models.BigAutoField(primary_key=True)
    scenetype_uid = models.SmallIntegerField()
    screenplay_version_uid = models.IntegerField()
    # ForeignKey(ScreenplayVersion, on_delete=models.RESTRICT, to_field='screenplay_version_uid', db_column='screenplay_version_uid')
    count_action = models.SmallIntegerField()
    count_dialogues = models.SmallIntegerField()
    generated_scene_text = models.TextField()
    scene_number = models.SmallIntegerField()
    count_words_action = models.SmallIntegerField() 
    count_words_dialogues = models.SmallIntegerField()
    prompt_time_of_day = models.TextField()
    prompt_location = models.TextField()
    created_on = models.DateTimeField()
    created_by = models.IntegerField()
    modified_on = models.DateTimeField()
    modified_by = models.IntegerField()
    generation_time = models.BigIntegerField()
    prompt_props = models.TextField()
    prompt_mode  = models.TextField()
    prompt_plot_details = models.TextField()
    prompt_action = models.TextField()
    image = models.BinaryField()

    class Meta:
        managed = False
        db_table = 'scene'
        





class Scene_Character(models.Model):
    scene_character_uid = models.BigIntegerField()
    scene_uid  = models.BigIntegerField()
    character_uid = models.BigIntegerField()
    created_on = models.DateTimeField()
    created_by = models.IntegerField()
    modified_on = models.DateTimeField()
    modified_by = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'scene_character'




class Characters(models.Model):
    character_uid = models.BigAutoField(primary_key=True)
    name = models.TextField()
    gender = models.TextField()
    age = models.SmallIntegerField()
    screenplay_version_uid = models.BigIntegerField()
    created_on = models.DateTimeField(auto_now_add=True)
    created_by = models.TextField()
    modified_on = models.DateTimeField(auto_now=True)
    modified_by = models.TextField()
    prompt_role = models.TextField()
    prompt_traits = models.TextField()
    prompt_appearance = models.TextField()
    prompt_background = models.TextField()
    prompt_goals = models.TextField()
    prompt_dialogue_slang = models.TextField()
    
    class Meta:
        managed = False
        db_table = 'characters'

class GeneratedScene(models.Model):
    scene_uid = models.AutoField(primary_key=True)
    screenplay_version_uid = models.IntegerField()
    scenetype_uid = models.IntegerField()
    count_action= models.IntegerField()
    count_dialogues = models.IntegerField()
    generated_scene_text = models.TextField()
    scene_number = models.IntegerField()
    count_words_action = models.IntegerField()
    count_words_dialogues = models.IntegerField()
    prompt_time_of_day = models.TextField()
    prompt_location = models.TextField()
    created_on = models.DateTimeField()
    created_by = models.IntegerField()
    modified_on = models.DateTimeField()
    modified_by= models.IntegerField()
    generation_time = models.IntegerField()
    prompt_action = models.TextField(blank=True, null=True)
    prompt_props = models.TextField() 
    prompt_mode = models.TextField()
    prompt_plot_details = models.TextField()
    

    class Meta:
        managed = False
        db_table = 'scene'

