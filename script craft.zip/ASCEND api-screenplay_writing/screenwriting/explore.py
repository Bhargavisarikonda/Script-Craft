from typing import OrderedDict
from rest_framework.viewsets import ModelViewSet, ViewSet
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework import status
from django.db.models import Max,Min,Count, Sum
import logging
from django.db.models import F
import json
from batch.models import MetricCharacter, Scene, Tenant, ClientUser, Client, Subscription
from batch.Models.Misc import Feedback
from scripts.messages import Messages
import pandas as pd
from django.contrib.auth.models import User
from django.contrib.auth import login, hashers
from services.src.utils import get_global_sentiments
from scripts.enums import CompanyType
from django.db import transaction
from .models import Test, Screenplay,ScreenplayVersion,Scene,Characters
import datetime
from scripts.enums import DbSchema


logger = logging.getLogger("scripts_logger")


class Explore(ViewSet):
    #@transaction.atomic
    @action(detail=False, methods=['POST'])
    def add_rows(self, request):
        
        #logger.info(f"auto commit? {transaction.get_autocommit()}")
        #transaction.set_autocommit(autocommit=False)
        #logger.info(f"auto commit again? {transaction.get_autocommit()}")

      
        #with transaction.set_autocommit(False):
        #with transaction.mark_for_rollback_on_error():

        with transaction.atomic(DbSchema.screenwriting.value):
            #try:

            """             screenplay = Screenplay(title="Avatar",
                                    created_on = datetime.datetime.now(),
                                    created_by = 1)

            screenplay.save() """

            screenplay = Screenplay.objects.create(
                                        title = "Avatar",   
                                        created_on = datetime.datetime.now(),
                                        created_by = 1
                                    )
            max_screenplay_uid = Screenplay.objects.all().aggregate(Max('screenplay_uid'))['screenplay_uid__max']

            logger.debug(f"screenplay uid {max_screenplay_uid}")
            #screenplay = Screenplay.objects.filter(screenplay_uid = max_screenplay_uid)
            #transaction.rollback()
            #raise Exception("Forced exit")
            
            screenplay_version = ScreenplayVersion(screenplay_uid = screenplay,
                                                    version_id = 1,
                                                    main_version = False,
                                                    language_uid = 1,
                                                    created_on = datetime.datetime.now(),
                                                    created_by = 1)
            screenplay_version.save()

            logger.debug(f"screenplay version uid {screenplay_version.screenplay_version_uid}")
            #transaction.commit()
        #except Exception as e:
        #    logger.error(f"sever error : {e}")
        #    transaction.rollback()


        #transaction.set_autocommit(autocommit=True)

        message, status = Messages.success.value

        return Response(message, status)

