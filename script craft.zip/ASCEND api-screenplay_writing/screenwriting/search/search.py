from django.shortcuts import render
from rest_framework import viewsets,status
from rest_framework.decorators import action
from rest_framework.response import Response
from scripts.messages import Messages
from django.db import connections, transaction
from rest_framework.views import APIView
from rest_framework.response import Response
from ..models import Test, Screenplay,ScreenplayVersion,Scene,Characters
from services.src.session import Session
from django.http import HttpResponseForbidden
from datetime import datetime
from ..serializers import CharactersCreateSerializer,CharactersSerializer,SceneSerializer,SceneupdateSerializer,ScreenplaySerializer,ScreenplaySerializers

from rest_framework.permissions import IsAuthenticated
from rest_framework.exceptions import AuthenticationFailed
from django.conf import settings
import base64
import logging
from scripts.enums import DbSchema, SearchCategory

logger = logging.getLogger("scripts_logger")


##  It will delete the data in a screenplay_version table based on screenplay_version_uid. If its the last screenplay version,
##  then delete screenplay as well.
class SearchViewSet(viewsets.ViewSet):

    @action(detail=True, methods=["GET"])
    def search_fields(self, request):
        page_size = int(request.query_params.get('page_size', settings.DEFAULT_PAGE_SIZE))
        offset = int(request.query_params.get('offset', settings.DEFAULT_OFFSET))
        category = request.query_params.get('category', None)
        field = request.query_params.get('field', None)

        if field is None:
            message, status = Messages.noStringFound.value
            return Response(message, status)
        
        q1 = """
                SELECT
                sc.screenplay_uid, sc.title, count(s.scene_number) AS scene_count, sc.views, sc.user_uid as writer_uid,
                CONCAT(au.first_name, ' ', au.last_name) AS writer,
                au.email AS writer_email, pr.avatar AS writer_avatar,
                sv.plot_summary, sv.genre, sc.avatar as screenplay_image, sc.modified_on AS timestamp,
                sc.file_path
                FROM screenplay AS sc
                LEFT JOIN screenplay_version AS sv
                ON sc.screenplay_uid = sv.screenplay_uid
                LEFT JOIN scene AS s
                ON s.screenplay_version_uid = sv.screenplay_version_uid
                LEFT JOIN auth_user AS au
                ON au.id = sc.user_uid
                LEFT JOIN profile AS pr
                ON pr.user_uid = au.id
                WHERE sc.published = True and sv.main_version = True
            """
        q3 = """
                group by sc.screenplay_uid, sc.title, sc.views, writer, writer_email, writer_avatar,
                sv.plot_summary, sv.genre, screenplay_image, timestamp   
                order by sc.modified_on desc                      
                LIMIT %s OFFSET %s
            """
        try:
            if category == SearchCategory.title.name:
                q2 = """and lower(sc.title) like %s"""
            elif category == SearchCategory.plot_summary.name:
                q2 = """and lower(sv.plot_summary) like %s"""           
            elif category == SearchCategory.genre.name:
                q2 = """and  lower(ARRAY_TO_STRING(sv.genre , ',') ) like %s"""
            elif category == SearchCategory.writer.name:
                q2 = """and lower(CONCAT(au.first_name, ' ', au.last_name)) like %s"""            
            else:
                message, status = Messages.invalidSearchCategory.value
                return Response(message, status)

            query = q1 + q2 + q3
            logger.debug(f"query: {query}")
            queryset = Screenplay.objects.raw(
                        query
                        , [ '%'+field.lower()+'%', page_size, offset])
        except Exception as e:
            message, status = Messages.unexpectedError.value
            logger.error(f"Error in search: {e}")
            return Response(message, status)

        logger.debug(f"queryset: {queryset}")
        serializer = ScreenplaySerializers(queryset, many=True)
        message, status = Messages.success.value
        return Response({'data': serializer.data}, status)



