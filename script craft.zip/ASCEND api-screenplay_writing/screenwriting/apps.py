from django.apps import AppConfig


class ScreenwritingConfig(AppConfig):
    name = 'screenwriting'
