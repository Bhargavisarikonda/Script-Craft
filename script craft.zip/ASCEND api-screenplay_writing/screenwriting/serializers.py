from rest_framework import serializers
import base64
from .models import Characters,Scene,Screenplay,ScreenplayVersion



class ScreenplaySerializers(serializers.Serializer):
    screenplay_uid = serializers.IntegerField()
    title = serializers.CharField()
    scene_count = serializers.IntegerField()
    views = serializers.IntegerField()
    writer_uid = serializers.IntegerField()
    writer_avatar = serializers.CharField()
    writer = serializers.CharField()
    writer_email = serializers.EmailField()
    plot_summary = serializers.CharField(allow_blank=True)
    genre = serializers.CharField()
    # screenplay_image = serializers.ImageField()
    avatar = serializers.SerializerMethodField()
    timestamp = serializers.DateTimeField(format = '%Y-%m-%d %H:%M:%S.%f')

      
    def get_avatar(self, obj):  # Change from get_image to get_avatar
        if obj.avatar is not None:
            return base64.b64encode(obj.avatar).decode('utf-8')
        return None


class CharactersSerializer(serializers.ModelSerializer):
    name = serializers.CharField()
    gender = serializers.CharField()
    age = serializers.IntegerField()
    screenplay_version_uid = serializers.IntegerField()
    created_on = serializers.DateTimeField(format='%Y-%m-%d %H:%M:%S', required = False)
    created_by = serializers.CharField(required = False)
    modified_on = serializers.DateTimeField(format='%Y-%m-%d %H:%M:%S.%f', required= False)
    modified_by = serializers.CharField()
    prompt_role = serializers.CharField()
    prompt_traits = serializers.CharField()
    prompt_appearance = serializers.CharField()
    prompt_background = serializers.CharField()
    prompt_goals = serializers.CharField()
    prompt_dialogue_slang = serializers.CharField()
      

    class Meta:
        model = Characters
        fields = '__all__'


class ScreenplayVersionSerializer(serializers.Serializer):
    screenplay_version_uid = serializers.IntegerField()
    version_id = serializers.IntegerField()
    main = serializers.BooleanField()
    image = serializers.SerializerMethodField()  # Use SerializerMethodField for custom handling
    title = serializers.CharField()
    created_on = serializers.DateTimeField()

    def get_image(self, obj):
        if 'image' in obj and obj['image'] is not None:
            return base64.b64encode(obj['image']).decode('utf-8')
        return None
    

class ScreenplaySerializer(serializers.Serializer):
    screenplay_uid = serializers.IntegerField()
    public = serializers.BooleanField()
    versions = ScreenplayVersionSerializer(many=True)




class CharactersCreateSerializer(serializers.ModelSerializer):
    name = serializers.CharField()
    gender = serializers.CharField()
    age = serializers.IntegerField()
    screenplay_version_uid = serializers.IntegerField()
    created_on = serializers.DateTimeField(format='%Y-%m-%d %H:%M:%S', required = False)
    # created_by = serializers.CharField()
    modified_on = serializers.DateTimeField(format='%Y-%m-%d %H:%M:%S.%f', required = False)
    # modified_by = serializers.CharField()
    prompt_role = serializers.CharField()
    prompt_traits = serializers.CharField(allow_blank=True)
    prompt_appearance = serializers.CharField(allow_blank=True)
    prompt_background = serializers.CharField(allow_blank=True)
    prompt_goals = serializers.CharField(allow_blank=True)
    prompt_dialogue_slang = serializers.CharField(allow_blank=True)


    class Meta:
        model = Characters
        fields = '__all__'



class SceneSerializer(serializers.ModelSerializer):
    scene_uid = serializers.IntegerField()
    scenetype_uid = serializers.IntegerField()
    screenplay_version_uid = serializers.IntegerField()
    count_action =  serializers.IntegerField()
    count_dialogues = serializers.IntegerField()
    generated_scene_text = serializers.CharField()
    scene_number = serializers.IntegerField()
    count_words_action = serializers.IntegerField()
    count_words_dialogues = serializers.IntegerField()
    prompt_time_of_day = serializers.CharField()
    prompt_location = serializers.CharField()
    created_on = serializers.DateTimeField(format='%Y-%m-%d %H:%M:%S', required = False)
    created_by = serializers.IntegerField()
    modified_on = serializers.DateTimeField(format='%Y-%m-%d %H:%M:%S', required = False)
    modified_by = serializers.IntegerField()
    generation_time = serializers.IntegerField()
    prompt_action = serializers.CharField()
    prompt_props = serializers.CharField()
    prompt_mode = serializers.CharField()
    prompt_plot_details = serializers.CharField()
    image = serializers.SerializerMethodField()

  
        
    def get_image(self, obj):
        if obj.image is not None:
            return base64.b64encode(obj.image).decode('utf-8')
        return None

        
    class Meta:
        model = Scene
        fields = '__all__'





class SceneupdateSerializer(serializers.ModelSerializer):
    scene_uid = serializers.IntegerField()
    screenplay_version_uid = serializers.IntegerField()
    generated_scene_text = serializers.CharField()
    image = serializers.SerializerMethodField()

        
    def get_image(self, obj):
        if obj.image is not None:
            return base64.b64encode(obj.image).decode('utf-8')
        return None

        
    class Meta:
        model = Scene
        fields = ['scene_uid', 'screenplay_version_uid', 'image', 'generated_scene_text']



class CreateScreenplayVersionSerializer(serializers.ModelSerializer):
    status = serializers.CharField(allow_null=True, default='')
    failure_reason = serializers.CharField(allow_null=True, default='')
    process_time = serializers.IntegerField(allow_null=True, default=None)
    created_on = serializers.DateTimeField(format='%Y-%m-%d %H:%M:%S')
    modified_on = serializers.DateTimeField(format='%Y-%m-%d %H:%M:%S.%f')
    plot_summary = serializers.CharField(allow_blank=True)
    genre = serializers.CharField(allow_null=True, default='')


    class Meta:
        model = ScreenplayVersion
        fields = '__all__'
