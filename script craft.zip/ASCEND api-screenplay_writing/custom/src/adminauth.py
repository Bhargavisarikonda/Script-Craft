

from django.conf import settings
from django.http import HttpResponseForbidden
import logging

logger = logging.getLogger("scripts_logger")

def restrict_admin_access(get_response):
    def middleware(request):
        if request.path.startswith('/kurkan/admin') and request.META['REMOTE_ADDR'] not in settings.ALLOWED_ADMIN_IPS:
            logger.error(f"Middleware - admin access failed for ip: {request.META['REMOTE_ADDR']} ")
            return HttpResponseForbidden()
        
        return get_response(request)

    return middleware