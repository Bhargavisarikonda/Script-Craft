from django.conf import settings as s1
#from scripts import settings as s2
import jwt
import logging
import traceback
from django.http import HttpResponse, HttpResponseServerError
from rest_framework.response import Response

logger = logging.getLogger("scripts_logger")


class CreateSession(object):

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):

        logger.debug("Custom middleware invoked")
        # Code that is executed in each request before the view is called
        #print('Before view is called ? ', request.user)
        response = self.get_response(request)

        # Code that is executed in each request after the view is called
        #print('After view is called ?')

        return response

    def process_exception(self, request, exception):
        # This code is executed if an exception is raised

        #print('S1 ', s1.DEBUG)
        #print('S2 ', s2.DEBUG)

        #if s2.DEBUG:
        logger.error(f'Middleware - Exception class: {exception.__class__.__name__} ')
        logger.error(f'Middleware - Exception mesg: {exception} ')

        if exception:
            # Format your message here
            message = "**{url}**\n\n{error}\n\n````{tb}````".format(
                url=request.build_absolute_uri(),
                error=repr(exception),
                tb=traceback.format_exc()
            )
            logger.error(f"Middleware - error from url: {message} ")
            # Do now whatever with this message
            # e.g. requests.post(<slack channel/teams channel>, data=message)
                
            return HttpResponseServerError(exception)

        return None

    #def get_response(self, request):
    #    return "Testing get_response "

    def process_view(self, request, view_func, view_args, view_kwargs):
        # This code is executed just before the view is called

        try:
            token = request.META.get('HTTP_AUTHORIZATION', " ").split(' ')[1]

            decoded_token = jwt.decode(jwt=token,
                                key=s1.SECRET_KEY,
                                algorithms=["HS256"])
            #print('MIDDLEWARE 2 ', decoded_token)
        except Exception as e:
            # This will be hit when there is no AUTHORIZATION token, that is, when user has not logged in. No need to log.
            #logger.info(f'Custom MIDDLEWARE warning; invalid or no token: {e} ')
            decoded_token = None

        #print('MIDDLEWARE 1 ', self.get_response(request))

        # Set session variable here for decoded token
        request.session['decoded_token'] = decoded_token
        


    def process_template_response(self, request, response):
        # This code is executed if the response contains a render() method
        return response

